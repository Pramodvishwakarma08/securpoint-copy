/*
import 'package:create/screen/onboardone.dart';
import 'package:create/screen/onbordthree.dart';
import 'package:create/screen/ontwo.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class OnBoard extends StatefulWidget {
  const OnBoard({super.key});

  @override
  State<OnBoard> createState() => _OnBoardState();
}

class _OnBoardState extends State<OnBoard> {
  OnBoardViewModel onBoardViewModel = OnBoardViewModel();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          SizedBox(height: 91),
          PageView(
            controller: onBoardViewModel.pageController,
            children: const [
              OnBoardFirst(),
              OnBoardSecond(),
              OnBoardThird(),

            ],
          ),
         SizedBox(height: 30,),
          Padding(
            padding:  EdgeInsets.symmetric(horizontal: 55),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                SmoothPageIndicator(
                  controller:
                  onBoardViewModel.pageController, // PageController
                  count: 3,
                  effect:  WormEffect(
                    activeDotColor: Color(0xff32CD30),
                    dotHeight: 6.5,
                    dotWidth: 6.5,
                  ), // your preferred effect
                  onDotClicked: (index) {},
                ),

                SizedBox(height: 30),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                       // Navigator.push(context,MaterialPageRoute(builder: (context) => SignupScreen()));
                      },
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Color(0xff32CD30),
                          minimumSize: Size(117, 44),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(11),
                          )),
                      child: Text("Next")


                    ),

                    Spacer(),

                    InkWell(
                      onTap: () {
                       // Navigator.push(context, MaterialPageRoute(builder: (context) => SignupScreen()));
                      },
                      child: Text('Skip', style:TextStyle(
                        color: Colors.black,fontSize:14,fontFamily: 'Adobe Garamond Pro',
                        fontWeight: FontWeight.w700,letterSpacing: 4.2,
                      )),
                    )
                  ],
                ),

              ],
            ),
          ),
          SizedBox(height: 50)
        ],
      ),
    );
  }
}

*/



import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:securepoint/screen/onboardone.dart';
import 'package:securepoint/screen/onbordthree.dart';
import 'package:securepoint/screen/ontwo.dart';
import 'package:securepoint/screen/signupscreen/signupscreen.dart';
import 'package:securepoint/screen/size.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:velocity_x/velocity_x.dart';


class OnBoard extends StatefulWidget {
  const OnBoard({super.key});

  @override
  State<OnBoard> createState() => _OnBoardState();
}

class _OnBoardState extends State<OnBoard> {
 // PageController _pageController = PageController(initialPage: 0);

  int _currentPageIndex = 0;
  void _changeToNextPage() {

    if(_currentPageIndex < 2){
      print("asdfghj${_currentPageIndex}");
      _pageController.nextPage(
        duration: Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
      setState(() {
      });
    }else{
      onTapSkip();
    }

  }

  onTapSkip() async {
   // SharedPreferences prefs = await SharedPreferences.getInstance();
   // await prefs.setBool('isOnboarding', true);
    Navigator.push(context, MaterialPageRoute(builder: (context) => SignupScreen()));

    // Get.toNamed(
    //   AppRoutes.loginScreen,
    // );
  }


  final PageController _pageController =PageController();

 // OnBoardViewModel onBoardViewModel = OnBoardViewModel();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          SizedBox(height: 91.ah,),
          PageView(
            controller: _pageController,
            onPageChanged: (value) {
              _currentPageIndex =value;
              print("object$value");
            },
            children: const [
              OnBoardFirst(),
              OnBoardSecond(),
              OnBoardThird(),
            ],
          ).expand(),
          30.heightBox,
          Padding(
            padding:  EdgeInsets.symmetric(horizontal: 55.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                SmoothPageIndicator(
                  controller: _pageController, // PageController

                  count: 3,
                  effect:  WormEffect(
                    activeDotColor: Color(0xff32CD30),
                    dotHeight: 6.5.ah,
                    dotWidth: 6.5.aw,
                  ), // your preferred effect
                  onDotClicked: (index) {},
                ),

                SizedBox(height: 30.ah),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        _changeToNextPage();
                        // Navigator.push(context,MaterialPageRoute(builder: (context) => SignupScreen()));
                      },
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Color(0xff32CD30),
                          minimumSize: Size(117, 44),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(11),
                          )),
                      child: "Next".
                      text.size(14)
                          .fontWeight(FontWeight.w600).color(Colors.white)
                          .make(),
                    ),

                    Spacer(),

                    InkWell(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => SignupScreen()));
                      },
                      child: Text('Skip', style:TextStyle(
                        color: Colors.black,fontSize:14.fSize,fontFamily: 'Roboto',
                        fontWeight: FontWeight.bold,letterSpacing: 1,
                      )),
                    )
                  ],
                ),

              ],
            ),
          ),
          50.heightBox,
        ],
      ),
    );
  }
}
class OnBoardViewModel {
  final PageController pageController = PageController();
}