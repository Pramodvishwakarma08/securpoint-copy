import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:securepoint/screen/size.dart';

import '../const_iteam/const_textfile.dart';
import '../const_iteam/custom_button.dart';
import '../loginscreen.dart';
import '../signup_withphone/signupwithphone.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  //SignupController signupController = Get.put(SignupController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [

          Stack(
            alignment: Alignment.centerLeft,
            children: [
              // Container(
              //   height:50.ah,
              //   width: MediaQuery.of(context).size.width,
              //   color: Color(0xFF32CD30),
              // ),
              // SizedBox(height: 20.ah,),
              Container(
                height: 185.ah,
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                  //color: Color(0xFF32CD30),
                  //borderRadius: BorderRadius.only(bottomRight: Radius.circular(151))
                    image: DecorationImage(
                        fit: BoxFit.fill,
                        image: AssetImage('assets/image/Rectangle 4.png',)
                    )
                ),
              ),

              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(width:20.aw),
                  Image.asset('assets/image/secur icon.png',height:53.ah,width: 40.aw,),
                  SizedBox(width:20.aw),
                  // Text('SecurPoint', style:TextStyle(
                  //   color: Colors.white,fontSize: 35.7.fSize,fontFamily: 'Adobe Garamond Pro',
                  //   fontWeight: FontWeight.w700,letterSpacing: 4.2,
                  // ))
                  Text('SecurPoint', style:TextStyle(
                    color: Colors.white,fontSize: 35.7.fSize,fontFamily: 'Times New Roman',
                    fontWeight: FontWeight.w700,letterSpacing: 1,
                  ))
                ],
              )
            ],
          ),

          Padding(
            padding:  EdgeInsets.only(left: 20.h,right: 20.h),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 20.ah),
                Text('Sign up',
                  style: TextStyle(
                      color: Colors.black,fontWeight: FontWeight.w600,fontSize: 36.fSize
                  ),
                ),
                SizedBox(height:30.ah),
                Text('Please enter your email to verify your account',
                  style: TextStyle(
                      color: Colors.grey,fontWeight: FontWeight.w600,fontSize:14.fSize
                  ),
                ),

                SizedBox(height:30.ah),

                primaryTextfield(hintText: 'Enter Email', controller: null),

                SizedBox(height:30.ah),
                InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) =>SignupWith_PhoneNumber() ));
                  },
                  child: Container(
                    //alignment: Alignment.topRight,
                    color: Colors.white,
                    height: 30.ah,width:231.aw,
                    child: RichText(
                      text: TextSpan(
                          text: 'Don’t have an email?',
                          style: TextStyle(
                            fontSize: 14.fSize,fontWeight: FontWeight.w500,color: Colors.black,
                          ),
                          // style: GoogleFonts.roboto(
                          //   fontSize: 14.fSize,fontWeight: FontWeight.w500,color: Colors.black,
                          // ),
                          children: [
                            TextSpan(
                                text: ' Use phone no.',
                                style: TextStyle(
                                  fontSize: 14.fSize,fontWeight: FontWeight.w500,color:Color(0xFF32CD30),
                                ),
                                recognizer: TapGestureRecognizer()..onTap=(){
                                  Navigator.push(context, MaterialPageRoute(builder: (context) =>SignupWith_PhoneNumber() ));
                                }
                            )
                          ]
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),




          //SizedBox(height:30.ah),
          Spacer(),
          CustomPrimaryBtn(
            title: 'Send OTP', isLoading: false,
            onTap: () {
              //Get.to(LoginScreen());
              Navigator.push(context, MaterialPageRoute(builder: (context) => LoginScreen()));
            },),
          SizedBox(height:80.ah),

        ],
      ),
    );
  }
}
