import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:securepoint/screen/size.dart';

class Fillterd_assets extends StatefulWidget {
  const Fillterd_assets({super.key});

  @override
  State<Fillterd_assets> createState() => _Fillterd_assetsState();
}

class _Fillterd_assetsState extends State<Fillterd_assets> {
  final List<String> _options = ['Mobile 1', 'Mobile 2', 'Mobile 3'];
  final List<String> _options1 = ['Subcategories 1', 'Subcategories 2', 'Subcategories 3'];
  String? _selectedOption;
  String? _selectedOption1;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(Icons.arrow_back_outlined,color: Color(0xFF6A6A6A))),
        title: Text('Filtered Assets',
          style: TextStyle(fontFamily: 'Inter',
              color: Colors.black,fontWeight: FontWeight.w600,fontSize:20
          ),
        ),
        centerTitle: true,

        backgroundColor: Colors.white,surfaceTintColor: Colors.white,shadowColor: Colors.black26,
        elevation: 3,
      ),

      body: Padding(
        padding:  EdgeInsets.only(left: 20.h,right: 20.h),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [

              SizedBox(height: 30),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: DropdownButtonFormField<String>(

                      value: _selectedOption,
                      hint: Text('Mobile Devices',
                        style: TextStyle(fontFamily: 'Roboto',
                            color: Colors.black,fontWeight: FontWeight.w500,fontSize:13
                        ),
                      ),
                      items: _options.map((String option) {
                        return DropdownMenuItem<String>(
                          value: option,
                          child: Text(option),
                        );
                      }).toList(),
                      onChanged: (String? value) {
                        setState(() {
                          _selectedOption = value;
                        });
                      },
                      decoration: InputDecoration(
                        isDense: true,
                        fillColor: Color(0xffF2F2F2),
                        filled: true,
                        contentPadding: EdgeInsets.all(12),
                        // labelText: 'Select an option',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(11.h),
                          borderSide: BorderSide(
                            color: Color(0xFFB5B5B5),
                            width: 1,
                          ),
                        ),
                        errorStyle: TextStyle(color: Colors.red),
                        errorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(11.h),
                          borderSide: BorderSide(
                            color: Colors.red,
                            width: 1,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(11.h),
                          borderSide: BorderSide(
                            color: Colors.grey, width: 1,),),
                      ),
                    ),
                  ),

                  SizedBox(width: 10.aw,),
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      hint:  Text('All Subcategories',
                        style: TextStyle(fontFamily: 'Roboto',
                            color: Colors.black,fontWeight: FontWeight.w500,fontSize:13
                        ),
                      ),
                      value: _selectedOption1,
                      items: _options1.map((String option) {
                        return DropdownMenuItem<String>(
                          value: option,
                          child: Text(option),
                        );
                      }).toList(),
                      onChanged: (String? value) {
                        setState(() {
                          _selectedOption1 = value;
                        });
                      },
                      decoration: InputDecoration(
                        isDense: true,
                        fillColor: Color(0xffF2F2F2),
                        filled: true,
                        contentPadding: EdgeInsets.all(12),
                        // labelText: 'Select an option',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(11.h),
                          borderSide: BorderSide(
                            color: Color(0xFFB5B5B5),
                            width: 1,
                          ),
                        ),
                        errorStyle: TextStyle(color: Colors.red),
                        errorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(11.h),
                          borderSide: BorderSide(
                            color: Colors.red,
                            width: 1,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(11.h),
                          borderSide: BorderSide(
                            color: Colors.grey, width: 1,),),
                      ),
                    ),
                  ),

                ],
              ),

              SizedBox(height: 20),

              Text('17 Iteam',
                style: TextStyle(fontFamily: 'Roboto',
                    color: Colors.black,fontWeight: FontWeight.w500,fontSize:13
                ),
              ),

              SizedBox(height: 20),
              //Iteam()
              Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Card(
                        color: Colors.white,
                        surfaceTintColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(),
                        child: InkWell(
                          onTap: () {
                            //Navigator.push(context, MaterialPageRoute(builder: (context) => AssetsScreen()));
                          },
                          child: Container(
                            color: Colors.white,
                            height: 248.ah,width: 156.aw,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                /*Stack(
                                  alignment: Alignment.bottomCenter,
                                 children: [
                                  Container(
                                 height: 115,width: MediaQuery.of(context).size.width,

                            // decoration: BoxDecoration(
                            //   color: Colors.red,
                            //   borderRadius: BorderRadius.circular(15)
                                decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                image: DecorationImage(
                                  image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                                  fit: BoxFit.fill,
                                )
                            ),
                            // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                            //   width: MediaQuery.of(context).size.width,
                            //   fit: BoxFit.fill,
                            //
                            // ),
                          ),

                                   Image.asset('assets/image/Frame 427320937.png'),
                                   SizedBox(height: 20.ah)
                            ]),*/
                                Image.asset('assets/image/image_2024_03_19T08_10_31_939Z.png',height: 113.ah,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.fill,
                                ),

                                SizedBox(height: 10.ah),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                    SizedBox(width: 10.aw),
                                    Text('iPhone 15',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                      ),
                                    ),
                                  ],
                                ),

                                Text('UIC: 6568520',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                  ),
                                ),

                                Text('This property is not available\nfor sale. Kindly...',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                  ),
                                ),

                                SizedBox(height:10.ah),
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      width: 96.aw,height: 27.ah,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(40),
                                        color: Color(0xFF32CD30),
                                      ),
                                      child:  Center(
                                        child: Text('View Asset',
                                          style: TextStyle(fontFamily: 'Roboto',
                                              color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(width:30.aw),
                                    Icon(Icons.location_on,size: 25,)
                                  ],
                                ),

                                // Align(
                                //   alignment: Alignment.topRight,
                                //   child: Container(
                                //     height: 40.ah,width: 40.aw,
                                //     decoration: BoxDecoration(
                                //         color: Colors.white,
                                //         shape: BoxShape.circle
                                //       //borderRadius: BorderRadius.circular(20)
                                //     ),
                                //   ),
                                // ),

                              ],
                            ),

                          ),
                        )

                    ),
                    Card(
                        color: Colors.white,
                        surfaceTintColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(),
                        child: InkWell(
                          onTap: () {
                            // Navigator.push(context, MaterialPageRoute(builder: (context) => AssetsScreen()));
                          },
                          child: Container(
                            color: Colors.white,
                            height: 248.ah,width: 156.aw,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                /*Stack(
                                  alignment: Alignment.bottomCenter,
                                 children: [
                                  Container(
                                 height: 115,width: MediaQuery.of(context).size.width,

                            // decoration: BoxDecoration(
                            //   color: Colors.red,
                            //   borderRadius: BorderRadius.circular(15)
                                decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                image: DecorationImage(
                                  image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                                  fit: BoxFit.fill,
                                )
                            ),
                            // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                            //   width: MediaQuery.of(context).size.width,
                            //   fit: BoxFit.fill,
                            //
                            // ),
                          ),

                                   Image.asset('assets/image/Frame 427320937.png'),
                                   SizedBox(height: 20.ah)
                            ]),*/
                                Image.asset('assets/image/image_2024_03_19T08_10_31_939Z.png',height: 113.ah,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.fill,
                                ),

                                SizedBox(height: 10.ah),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                    SizedBox(width: 10.aw),
                                    Text('iPhone 15',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                      ),
                                    ),
                                  ],
                                ),

                                Text('UIC: 6568520',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                  ),
                                ),

                                Text('This property is not available\nfor sale. Kindly...',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                  ),
                                ),

                                SizedBox(height:10.ah),
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      width: 96.aw,height: 27.ah,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(40),
                                        color: Color(0xFF32CD30),
                                      ),
                                      child:  Center(
                                        child: Text('View Asset',
                                          style: TextStyle(fontFamily: 'Roboto',
                                              color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(width:30.aw),
                                    Icon(Icons.location_on,size: 25,)
                                  ],
                                ),

                                // Align(
                                //   alignment: Alignment.topRight,
                                //   child: Container(
                                //     height: 40.ah,width: 40.aw,
                                //     decoration: BoxDecoration(
                                //         color: Colors.white,
                                //         shape: BoxShape.circle
                                //       //borderRadius: BorderRadius.circular(20)
                                //     ),
                                //   ),
                                // ),

                              ],
                            ),

                          ),
                        )

                    )
                  ],
                ),
              ),
              Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Card(
                        color: Colors.white,
                        surfaceTintColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(),
                        child: InkWell(
                          onTap: () {
                            //Navigator.push(context, MaterialPageRoute(builder: (context) => AssetsScreen()));
                          },
                          child: Container(
                            color: Colors.white,
                            height: 248.ah,width: 156.aw,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                /*Stack(
                                  alignment: Alignment.bottomCenter,
                                 children: [
                                  Container(
                                 height: 115,width: MediaQuery.of(context).size.width,

                            // decoration: BoxDecoration(
                            //   color: Colors.red,
                            //   borderRadius: BorderRadius.circular(15)
                                decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                image: DecorationImage(
                                  image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                                  fit: BoxFit.fill,
                                )
                            ),
                            // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                            //   width: MediaQuery.of(context).size.width,
                            //   fit: BoxFit.fill,
                            //
                            // ),
                          ),

                                   Image.asset('assets/image/Frame 427320937.png'),
                                   SizedBox(height: 20.ah)
                            ]),*/
                                Image.asset('assets/image/image_2024_03_19T08_10_31_939Z.png',height: 113.ah,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.fill,
                                ),

                                SizedBox(height: 10.ah),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                    SizedBox(width: 10.aw),
                                    Text('iPhone 15',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                      ),
                                    ),
                                  ],
                                ),

                                Text('UIC: 6568520',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                  ),
                                ),

                                Text('This property is not available\nfor sale. Kindly...',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                  ),
                                ),

                                SizedBox(height:10.ah),
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      width: 96.aw,height: 27.ah,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(40),
                                        color: Color(0xFF32CD30),
                                      ),
                                      child:  Center(
                                        child: Text('View Asset',
                                          style: TextStyle(fontFamily: 'Roboto',
                                              color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(width:30.aw),
                                    Icon(Icons.location_on,size: 25,)
                                  ],
                                ),

                                // Align(
                                //   alignment: Alignment.topRight,
                                //   child: Container(
                                //     height: 40.ah,width: 40.aw,
                                //     decoration: BoxDecoration(
                                //         color: Colors.white,
                                //         shape: BoxShape.circle
                                //       //borderRadius: BorderRadius.circular(20)
                                //     ),
                                //   ),
                                // ),

                              ],
                            ),

                          ),
                        )

                    ),
                    Card(
                        color: Colors.white,
                        surfaceTintColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(),
                        child: InkWell(
                          onTap: () {
                            // Navigator.push(context, MaterialPageRoute(builder: (context) => AssetsScreen()));
                          },
                          child: Container(
                            color: Colors.white,
                            height: 248.ah,width: 156.aw,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                /*Stack(
                                  alignment: Alignment.bottomCenter,
                                 children: [
                                  Container(
                                 height: 115,width: MediaQuery.of(context).size.width,

                            // decoration: BoxDecoration(
                            //   color: Colors.red,
                            //   borderRadius: BorderRadius.circular(15)
                                decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                image: DecorationImage(
                                  image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                                  fit: BoxFit.fill,
                                )
                            ),
                            // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                            //   width: MediaQuery.of(context).size.width,
                            //   fit: BoxFit.fill,
                            //
                            // ),
                          ),

                                   Image.asset('assets/image/Frame 427320937.png'),
                                   SizedBox(height: 20.ah)
                            ]),*/
                                Image.asset('assets/image/image_2024_03_19T08_10_31_939Z.png',height: 113.ah,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.fill,
                                ),

                                SizedBox(height: 10.ah),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                    SizedBox(width: 10.aw),
                                    Text('iPhone 15',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                      ),
                                    ),
                                  ],
                                ),

                                Text('UIC: 6568520',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                  ),
                                ),

                                Text('This property is not available\nfor sale. Kindly...',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                  ),
                                ),

                                SizedBox(height:10.ah),
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      width: 96.aw,height: 27.ah,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(40),
                                        color: Color(0xFF32CD30),
                                      ),
                                      child:  Center(
                                        child: Text('View Asset',
                                          style: TextStyle(fontFamily: 'Roboto',
                                              color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(width:30.aw),
                                    Icon(Icons.location_on,size: 25,)
                                  ],
                                ),

                                // Align(
                                //   alignment: Alignment.topRight,
                                //   child: Container(
                                //     height: 40.ah,width: 40.aw,
                                //     decoration: BoxDecoration(
                                //         color: Colors.white,
                                //         shape: BoxShape.circle
                                //       //borderRadius: BorderRadius.circular(20)
                                //     ),
                                //   ),
                                // ),

                              ],
                            ),

                          ),
                        )

                    )
                  ],
                ),
              ),
              Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Card(
                        color: Colors.white,
                        surfaceTintColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(),
                        child: InkWell(
                          onTap: () {
                            //Navigator.push(context, MaterialPageRoute(builder: (context) => AssetsScreen()));
                          },
                          child: Container(
                            color: Colors.white,
                            height: 248.ah,width: 156.aw,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                /*Stack(
                                  alignment: Alignment.bottomCenter,
                                 children: [
                                  Container(
                                 height: 115,width: MediaQuery.of(context).size.width,

                            // decoration: BoxDecoration(
                            //   color: Colors.red,
                            //   borderRadius: BorderRadius.circular(15)
                                decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                image: DecorationImage(
                                  image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                                  fit: BoxFit.fill,
                                )
                            ),
                            // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                            //   width: MediaQuery.of(context).size.width,
                            //   fit: BoxFit.fill,
                            //
                            // ),
                          ),

                                   Image.asset('assets/image/Frame 427320937.png'),
                                   SizedBox(height: 20.ah)
                            ]),*/
                                Image.asset('assets/image/image_2024_03_19T08_10_31_939Z.png',height: 113.ah,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.fill,
                                ),

                                SizedBox(height: 10.ah),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                    SizedBox(width: 10.aw),
                                    Text('iPhone 15',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                      ),
                                    ),
                                  ],
                                ),

                                Text('UIC: 6568520',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                  ),
                                ),

                                Text('This property is not available\nfor sale. Kindly...',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                  ),
                                ),

                                SizedBox(height:10.ah),
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      width: 96.aw,height: 27.ah,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(40),
                                        color: Color(0xFF32CD30),
                                      ),
                                      child:  Center(
                                        child: Text('View Asset',
                                          style: TextStyle(fontFamily: 'Roboto',
                                              color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(width:30.aw),
                                    Icon(Icons.location_on,size: 25,)
                                  ],
                                ),

                                // Align(
                                //   alignment: Alignment.topRight,
                                //   child: Container(
                                //     height: 40.ah,width: 40.aw,
                                //     decoration: BoxDecoration(
                                //         color: Colors.white,
                                //         shape: BoxShape.circle
                                //       //borderRadius: BorderRadius.circular(20)
                                //     ),
                                //   ),
                                // ),

                              ],
                            ),

                          ),
                        )

                    ),
                    Card(
                        color: Colors.white,
                        surfaceTintColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(),
                        child: InkWell(
                          onTap: () {
                            // Navigator.push(context, MaterialPageRoute(builder: (context) => AssetsScreen()));
                          },
                          child: Container(
                            color: Colors.white,
                            height: 248.ah,width: 156.aw,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                /*Stack(
                                  alignment: Alignment.bottomCenter,
                                 children: [
                                  Container(
                                 height: 115,width: MediaQuery.of(context).size.width,

                            // decoration: BoxDecoration(
                            //   color: Colors.red,
                            //   borderRadius: BorderRadius.circular(15)
                                decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                image: DecorationImage(
                                  image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                                  fit: BoxFit.fill,
                                )
                            ),
                            // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                            //   width: MediaQuery.of(context).size.width,
                            //   fit: BoxFit.fill,
                            //
                            // ),
                          ),

                                   Image.asset('assets/image/Frame 427320937.png'),
                                   SizedBox(height: 20.ah)
                            ]),*/
                                Image.asset('assets/image/image_2024_03_19T08_10_31_939Z.png',height: 113.ah,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.fill,
                                ),

                                SizedBox(height: 10.ah),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                    SizedBox(width: 10.aw),
                                    Text('iPhone 15',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                      ),
                                    ),
                                  ],
                                ),

                                Text('UIC: 6568520',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                  ),
                                ),

                                Text('This property is not available\nfor sale. Kindly...',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                  ),
                                ),

                                SizedBox(height:10.ah),
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      width: 96.aw,height: 27.ah,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(40),
                                        color: Color(0xFF32CD30),
                                      ),
                                      child:  Center(
                                        child: Text('View Asset',
                                          style: TextStyle(fontFamily: 'Roboto',
                                              color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(width:30.aw),
                                    Icon(Icons.location_on,size: 25,)
                                  ],
                                ),

                                // Align(
                                //   alignment: Alignment.topRight,
                                //   child: Container(
                                //     height: 40.ah,width: 40.aw,
                                //     decoration: BoxDecoration(
                                //         color: Colors.white,
                                //         shape: BoxShape.circle
                                //       //borderRadius: BorderRadius.circular(20)
                                //     ),
                                //   ),
                                // ),

                              ],
                            ),

                          ),
                        )

                    )
                  ],
                ),
              ),

              SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}

class Iteam extends StatelessWidget {
  const Iteam({super.key});

  @override
  Widget build(BuildContext context) {
    return  GridView.builder(
        shrinkWrap: true,
        itemCount: 6,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,mainAxisExtent:248,
            mainAxisSpacing:15,crossAxisSpacing: 9
        ),
        itemBuilder: (context, index) {
          return  Container(
            color: Colors.white,
            height: 248.ah,width: MediaQuery.of(context).size.width,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [

                Container(
                  width: MediaQuery.of(context).size.width,
                  height: 113.ah,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                          fit: BoxFit.fill,
                          image:AssetImage('assets/image/unlock.png')
                      )
                  ),
                ),
                // Image.asset('assets/image/image_2024_03_19T08_10_10_398Z.png',height: 113.ah,
                //   width: MediaQuery.of(context).size.width,
                //   fit: BoxFit.fill,
                // ),

                SizedBox(height: 10.ah),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                    // SizedBox(width: 10.aw),
                    Text('Peter Villa',
                      style: TextStyle(fontFamily: 'Roboto',
                          color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                      ),
                    ),
                  ],
                ),

                Text('UIC: 6568520',
                  style: TextStyle(fontFamily: 'Roboto',
                      color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                  ),
                ),

                Text('This property is not available\nfor sale. Kindly...',
                  style: TextStyle(fontFamily: 'Roboto',
                      color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:10.fSize
                  ),
                ),

                SizedBox(height:10.ah),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      width: 96.aw,height: 27.ah,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(40),
                        color: Color(0xFF32CD30),
                      ),
                      child:  Center(
                        child: Text('View Asset',
                          style: TextStyle(fontFamily: 'Roboto',
                              color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width:30.aw),
                    Icon(Icons.location_on,size: 25,)
                  ],
                ),



              ],
            ),

          );
        });
  }
}
