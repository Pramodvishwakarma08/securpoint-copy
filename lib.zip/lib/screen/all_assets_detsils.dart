import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:securepoint/screen/my_profile_screen.dart';
import 'package:securepoint/screen/my_user_profile.dart';
import 'package:securepoint/screen/size.dart';
import 'const_iteam/const_textfile.dart';
import 'const_iteam/custom_button.dart';
import 'deshbord_screen.dart';

class All_Assets_Details extends StatefulWidget {
  const All_Assets_Details({super.key});

  @override
  State<All_Assets_Details> createState() => _All_Assets_DetailsState();
}

class _All_Assets_DetailsState extends State<All_Assets_Details> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: InkWell(
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => Demo_deshboardPage()));
            },
            child: Icon(Icons.arrow_back_outlined,color: Color(0xFF6A6A6A))),
        title: Text('Asset Details',
          style: TextStyle(fontFamily: 'Inter',
              color: Color(0xFF6A6A6A),fontWeight: FontWeight.w600,fontSize:15
          ),
        ),
        centerTitle: true,
        actions: [
          SvgPicture.asset('assets/image/Saved Assets.svg',height: 19.ah,width: 14.aw,fit: BoxFit.fill,),
          SizedBox(width: 10.aw),
          Icon(Icons.share,size:20,color: Color(0xFF6A6A6A)),
          SizedBox(width: 20.aw),
        ],
        backgroundColor: Colors.white,surfaceTintColor: Colors.white,shadowColor: Colors.black26,
        elevation: 3,
      ),
      body: Padding(
        padding:  EdgeInsets.only(left: 20.h,right: 20.h),
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          physics: AlwaysScrollableScrollPhysics(),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [

              SizedBox(height: 10.ah),
              Image.asset('assets/image/image_2024_03_19T08_10_10_398Z.png',
                height: 161.ah,
                width: MediaQuery.of(context).size.width,
                fit: BoxFit.fill,
              ),
              // Container(
              //   height: 161.ah,
              //   width: ,
              // ),
              SizedBox(height:20.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('Report this asset',
                    style: TextStyle(fontFamily: 'Roboto',
                        color: Color(0xFF4F4F4F),fontWeight: FontWeight.w400,fontSize:11
                    ),
                  ),
                  SizedBox(width:5.aw),
                  InkWell(
                      onTap: () {
                        showModalBottomSheet(
                            context: context,
                            backgroundColor: Colors.white,
                            builder: (context) {
                              return Padding(
                                padding: EdgeInsets.only(left: 10,right: 10),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    SizedBox(height: 15.ah),
                                    ListTile(
                                      title: Text('  Report reason ',
                                        style: TextStyle(
                                            color: Colors.black,fontWeight: FontWeight.w600,fontSize:16
                                        ),),
                                      onTap: () {
                                        Navigator.pop(context);
                                      },
                                    ),

                                    /*Container(
                                      height: 45.ah,
                                      width: 342.aw,
                                      decoration: BoxDecoration(
                                          border: Border.all(
                                            color: Colors.black,
                                            width: 1,
                                          ),
                                          borderRadius: BorderRadius.circular(12)
                                      ),
                                      child:Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Text('Lorem ipsum',
                                          style: TextStyle(
                                              color: Colors.black,fontWeight: FontWeight.w600,fontSize:16
                                          ),),
                                      ),
                                    ),*/

                                    Padding(
                                      padding: EdgeInsets.only(left: 15,right: 15),
                                      child: primaryTextfield5(
                                          hintText: 'Lorem ipsum', controller: null

                                      ),
                                    ),


                                    SizedBox(height:20.ah),
                                    Center(
                                      child: CustomPrimaryBtn2(
                                        title: 'Report this asset',
                                        isLoading: false,
                                        onTap: () {
                                          // Navigator.push(context, MaterialPageRoute(builder: (context) => SignUp_Screen()));
                                        },
                                      ),
                                    ),
                                    SizedBox(height:30.ah),
                                  ],
                                ),
                              );
                            }
                        );
                      },
                      child: SvgPicture.asset('assets/icon/ic_report_24px.svg',width: 15.aw,height: 15.ah,fit: BoxFit.fill,))
                ],
              ),

              Text("Jona's White House in up Town",
                style: TextStyle(fontFamily: 'Roboto',
                    color: Color(0xFF4F4F4F),fontWeight: FontWeight.w500,fontSize:18
                ),
              ),
              Text('05 JAN AT 22:01',
                style: TextStyle(fontFamily: 'Roboto',
                    color: Color(0xFF4F4F4F),fontWeight: FontWeight.w400,fontSize:10
                ),
              ),

              SizedBox(height: 50.ah),
              Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  InkWell(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => UserProfileScreen()));
                    },
                    child: Container(
                      width: 96.aw,height: 27.ah,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(40),
                        color: Color(0xFF32CD30),
                      ),
                      child:  Center(
                        child: Text('Contact Owner',
                          style: TextStyle(fontFamily: 'Roboto',
                              color: Colors.white,fontWeight: FontWeight.w600,fontSize:12.fSize
                          ),
                        ),
                      ),
                    ),
                  ),

                  SizedBox(width:120.aw),

                  Text('UIC: 123456',
                    style: TextStyle(fontFamily: 'Roboto',
                        color: Color(0xFF32CD30),fontWeight: FontWeight.w500,fontSize:21.fSize
                    ),
                  ),
                ],
              ),

              SizedBox(height: 20.ah),
              Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        SvgPicture.asset('assets/icon/icon _warning_.svg',height: 15.ah,width: 16.aw,fit: BoxFit.fill,),
                        Text('This asset is not available!',
                          style: TextStyle(fontFamily: 'Roboto',
                              color: Color(0xFFBD3124),fontWeight: FontWeight.w400,fontSize:11.fSize
                          ),
                        ),
                      ]
                  ),
                  SizedBox(width:120.aw),

                  Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Icon(Icons.location_on,size: 35,color: Color(0xFF6C6C6C)),
                      Text('View on map',
                        style: TextStyle(fontFamily: 'Roboto',
                            color: Color(0xFF6C6C6C),fontWeight: FontWeight.w400,fontSize:11.fSize
                        ),
                      ),
                    ],
                  )
                ],
              ),

              SizedBox(height: 20.ah),
              Text("Asset Information",
                style: TextStyle(fontFamily: 'Roboto',
                    color: Color(0xFF5E605E),fontWeight: FontWeight.w600,fontSize:14
                ),
              ),

              SizedBox(height: 20.ah),
              RichText(
                text: TextSpan(
                    text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqu ullamco laboris nisi...',
                    style: TextStyle(
                      fontSize: 13.fSize,fontWeight: FontWeight.w400,color: Colors.black45,
                    ),
                    children: [
                      TextSpan(
                        text: ' See More',
                        style: TextStyle(decoration: TextDecoration.underline,
                          fontSize: 13.fSize,fontWeight: FontWeight.w400,color:Color(0xFF32CD30),
                        ),)]),),

              SizedBox(height: 20.ah),
              Row(
                // mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Related Items',
                    style: TextStyle(
                        color: Colors.black,fontWeight: FontWeight.w500,fontSize:14
                    ),
                  ),

                  InkWell(
                    onTap: () {
                      // Navigator.push(context, MaterialPageRoute(builder: (context) => Populars_Allcity()));
                    },
                    child: Text('View all',
                      style: TextStyle(
                          color: Colors.black,fontWeight: FontWeight.w400,fontSize:13.fSize
                      ),
                    ),
                  ),
                ],
              ),

              SizedBox(height: 20.ah),
              //Related_Iteam()

              Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Card(
                        color: Colors.white,
                        surfaceTintColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(),
                        child: InkWell(
                          onTap: () {
                            //Navigator.push(context, MaterialPageRoute(builder: (context) => All_Assets_Details()));
                          },
                          child: Container(
                            color: Colors.white,
                            height: 248.ah,width: 156.aw,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                /*Stack(
                                  alignment: Alignment.bottomCenter,
                                 children: [
                                  Container(
                                 height: 115,width: MediaQuery.of(context).size.width,

                            // decoration: BoxDecoration(
                            //   color: Colors.red,
                            //   borderRadius: BorderRadius.circular(15)
                                decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                image: DecorationImage(
                                  image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                                  fit: BoxFit.fill,
                                )
                            ),
                            // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                            //   width: MediaQuery.of(context).size.width,
                            //   fit: BoxFit.fill,
                            //
                            // ),
                          ),

                                   Image.asset('assets/image/Frame 427320937.png'),
                                   SizedBox(height: 20.ah)
                            ]),*/
                                Image.asset('assets/image/image_2024_03_19T08_10_31_939Z.png',height: 113.ah,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.fill,
                                ),

                                SizedBox(height: 10.ah),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                    SizedBox(width: 10.aw),
                                    Text('iPhone 15',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                      ),
                                    ),
                                  ],
                                ),

                                Text('UIC: 6568520',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                  ),
                                ),

                                Text('This property is not available\nfor sale. Kindly...',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                  ),
                                ),

                                SizedBox(height:10.ah),
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      width: 96.aw,height: 27.ah,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(40),
                                        color: Color(0xFF32CD30),
                                      ),
                                      child:  Center(
                                        child: Text('View Asset',
                                          style: TextStyle(fontFamily: 'Roboto',
                                              color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(width:30.aw),
                                    Icon(Icons.location_on,size: 25,)
                                  ],
                                ),

                                // Align(
                                //   alignment: Alignment.topRight,
                                //   child: Container(
                                //     height: 40.ah,width: 40.aw,
                                //     decoration: BoxDecoration(
                                //         color: Colors.white,
                                //         shape: BoxShape.circle
                                //       //borderRadius: BorderRadius.circular(20)
                                //     ),
                                //   ),
                                // ),

                              ],
                            ),

                          ),
                        )

                    ),
                    Card(
                        color: Colors.white,
                        surfaceTintColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(),
                        child: InkWell(
                          onTap: () {
                          //  Navigator.push(context, MaterialPageRoute(builder: (context) => All_Assets_Details()));
                          },
                          child: Container(
                            color: Colors.white,
                            height: 248.ah,width: 156.aw,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                /*Stack(
                                  alignment: Alignment.bottomCenter,
                                 children: [
                                  Container(
                                 height: 115,width: MediaQuery.of(context).size.width,

                            // decoration: BoxDecoration(
                            //   color: Colors.red,
                            //   borderRadius: BorderRadius.circular(15)
                                decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                image: DecorationImage(
                                  image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                                  fit: BoxFit.fill,
                                )
                            ),
                            // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                            //   width: MediaQuery.of(context).size.width,
                            //   fit: BoxFit.fill,
                            //
                            // ),
                          ),

                                   Image.asset('assets/image/Frame 427320937.png'),
                                   SizedBox(height: 20.ah)
                            ]),*/
                                Image.asset('assets/image/image_2024_03_19T08_10_31_939Z.png',height: 113.ah,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.fill,
                                ),

                                SizedBox(height: 10.ah),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                    SizedBox(width: 10.aw),
                                    Text('iPhone 15',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                      ),
                                    ),
                                  ],
                                ),

                                Text('UIC: 6568520',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                  ),
                                ),

                                Text('This property is not available\nfor sale. Kindly...',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                  ),
                                ),

                                SizedBox(height:10.ah),
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      width: 96.aw,height: 27.ah,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(40),
                                        color: Color(0xFF32CD30),
                                      ),
                                      child:  Center(
                                        child: Text('View Asset',
                                          style: TextStyle(fontFamily: 'Roboto',
                                              color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(width:30.aw),
                                    Icon(Icons.location_on,size: 25,)
                                  ],
                                ),

                                // Align(
                                //   alignment: Alignment.topRight,
                                //   child: Container(
                                //     height: 40.ah,width: 40.aw,
                                //     decoration: BoxDecoration(
                                //         color: Colors.white,
                                //         shape: BoxShape.circle
                                //       //borderRadius: BorderRadius.circular(20)
                                //     ),
                                //   ),
                                // ),

                              ],
                            ),

                          ),
                        )

                    )
                  ],
                ),
              ),

              Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Card(
                        color: Colors.white,
                        surfaceTintColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(),
                        child: InkWell(
                          onTap: () {
                            //Navigator.push(context, MaterialPageRoute(builder: (context) => All_Assets_Details()));
                          },
                          child: Container(
                            color: Colors.white,
                            height: 248.ah,width: 156.aw,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                /*Stack(
                                  alignment: Alignment.bottomCenter,
                                 children: [
                                  Container(
                                 height: 115,width: MediaQuery.of(context).size.width,

                            // decoration: BoxDecoration(
                            //   color: Colors.red,
                            //   borderRadius: BorderRadius.circular(15)
                                decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                image: DecorationImage(
                                  image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                                  fit: BoxFit.fill,
                                )
                            ),
                            // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                            //   width: MediaQuery.of(context).size.width,
                            //   fit: BoxFit.fill,
                            //
                            // ),
                          ),

                                   Image.asset('assets/image/Frame 427320937.png'),
                                   SizedBox(height: 20.ah)
                            ]),*/
                                Image.asset('assets/image/image_2024_03_19T08_10_31_939Z.png',height: 113.ah,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.fill,
                                ),

                                SizedBox(height: 10.ah),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                    SizedBox(width: 10.aw),
                                    Text('iPhone 15',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                      ),
                                    ),
                                  ],
                                ),

                                Text('UIC: 6568520',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                  ),
                                ),

                                Text('This property is not available\nfor sale. Kindly...',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                  ),
                                ),

                                SizedBox(height:10.ah),
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      width: 96.aw,height: 27.ah,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(40),
                                        color: Color(0xFF32CD30),
                                      ),
                                      child:  Center(
                                        child: Text('View Asset',
                                          style: TextStyle(fontFamily: 'Roboto',
                                              color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(width:30.aw),
                                    Icon(Icons.location_on,size: 25,)
                                  ],
                                ),

                                // Align(
                                //   alignment: Alignment.topRight,
                                //   child: Container(
                                //     height: 40.ah,width: 40.aw,
                                //     decoration: BoxDecoration(
                                //         color: Colors.white,
                                //         shape: BoxShape.circle
                                //       //borderRadius: BorderRadius.circular(20)
                                //     ),
                                //   ),
                                // ),

                              ],
                            ),

                          ),
                        )

                    ),
                    Card(
                        color: Colors.white,
                        surfaceTintColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(),
                        child: InkWell(
                          onTap: () {
                            //Navigator.push(context, MaterialPageRoute(builder: (context) => All_Assets_Details()));
                          },
                          child: Container(
                            color: Colors.white,
                            height: 248.ah,width: 156.aw,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                /*Stack(
                                  alignment: Alignment.bottomCenter,
                                 children: [
                                  Container(
                                 height: 115,width: MediaQuery.of(context).size.width,

                            // decoration: BoxDecoration(
                            //   color: Colors.red,
                            //   borderRadius: BorderRadius.circular(15)
                                decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                image: DecorationImage(
                                  image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                                  fit: BoxFit.fill,
                                )
                            ),
                            // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                            //   width: MediaQuery.of(context).size.width,
                            //   fit: BoxFit.fill,
                            //
                            // ),
                          ),

                                   Image.asset('assets/image/Frame 427320937.png'),
                                   SizedBox(height: 20.ah)
                            ]),*/
                                Image.asset('assets/image/image_2024_03_19T08_10_31_939Z.png',height: 113.ah,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.fill,
                                ),

                                SizedBox(height: 10.ah),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                    SizedBox(width: 10.aw),
                                    Text('iPhone 15',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                      ),
                                    ),
                                  ],
                                ),

                                Text('UIC: 6568520',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                  ),
                                ),

                                Text('This property is not available\nfor sale. Kindly...',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                  ),
                                ),

                                SizedBox(height:10.ah),
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      width: 96.aw,height: 27.ah,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(40),
                                        color: Color(0xFF32CD30),
                                      ),
                                      child:  Center(
                                        child: Text('View Asset',
                                          style: TextStyle(fontFamily: 'Roboto',
                                              color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(width:30.aw),
                                    Icon(Icons.location_on,size: 25,)
                                  ],
                                ),

                                // Align(
                                //   alignment: Alignment.topRight,
                                //   child: Container(
                                //     height: 40.ah,width: 40.aw,
                                //     decoration: BoxDecoration(
                                //         color: Colors.white,
                                //         shape: BoxShape.circle
                                //       //borderRadius: BorderRadius.circular(20)
                                //     ),
                                //   ),
                                // ),

                              ],
                            ),

                          ),
                        )

                    )
                  ],
                ),
              ),

              SizedBox(height: 20.ah),
            ],
          ),
        ),
      ),
    );
  }
}

class Related_Iteam extends StatelessWidget {
  const Related_Iteam({super.key});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        shrinkWrap: true,
        itemCount: 6,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,mainAxisExtent:248,
            mainAxisSpacing:15,crossAxisSpacing: 9
        ),
        itemBuilder: (context, index) {
          return  Card(
              color: Colors.white,
              surfaceTintColor: Colors.white,
              elevation: 0,
              shape: RoundedRectangleBorder(),
              child: Container(
                color: Colors.white,
                height: 248.ah,width: 156.aw,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [

                    /*Stack(
                              alignment: Alignment.bottomCenter,
                             children: [
                              Container(
                             height: 115,width: MediaQuery.of(context).size.width,

                        // decoration: BoxDecoration(
                        //   color: Colors.red,
                        //   borderRadius: BorderRadius.circular(15)
                            decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(15),
                            image: DecorationImage(
                              image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                              fit: BoxFit.fill,
                            )
                        ),
                        // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                        //   width: MediaQuery.of(context).size.width,
                        //   fit: BoxFit.fill,
                        //
                        // ),
                      ),

                               Image.asset('assets/image/Frame 427320937.png'),
                               SizedBox(height: 20.ah)
                        ]),*/
                    Image.asset('assets/image/image_2024_03_19T08_10_31_939Z.png',height: 113.ah,
                      width: MediaQuery.of(context).size.width,
                      fit: BoxFit.fill,
                    ),

                    SizedBox(height: 10.ah),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                        SizedBox(width: 10.aw),
                        Text('iPhone 15',
                          style: TextStyle(fontFamily: 'Roboto',
                              color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                          ),
                        ),
                      ],
                    ),

                    Text('UIC: 6568520',
                      style: TextStyle(fontFamily: 'Roboto',
                          color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                      ),
                    ),

                    Text('This property is not available\nfor sale. Kindly...',
                      style: TextStyle(fontFamily: 'Roboto',
                          color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                      ),
                    ),

                    SizedBox(height:10.ah),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          width: 96.aw,height: 27.ah,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(40),
                            color: Color(0xFF32CD30),
                          ),
                          child:  Center(
                            child: Text('View Asset',
                              style: TextStyle(fontFamily: 'Roboto',
                                  color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                              ),
                            ),
                          ),
                        ),
                        SizedBox(width:30.aw),
                        Icon(Icons.location_on,size: 25,)
                      ],
                    ),

                    // Align(
                    //   alignment: Alignment.topRight,
                    //   child: Container(
                    //     height: 40.ah,width: 40.aw,
                    //     decoration: BoxDecoration(
                    //         color: Colors.white,
                    //         shape: BoxShape.circle
                    //       //borderRadius: BorderRadius.circular(20)
                    //     ),
                    //   ),
                    // ),

                  ],
                ),

              )

          );
        });
  }
}


