import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:securepoint/screen/chat_screen.dart';
import 'package:securepoint/screen/size.dart';
import 'const_iteam/const_textfile.dart';
import 'const_iteam/custom_button.dart';
import 'notification_screen.dart';

class UserProfileScreen extends StatefulWidget {
  const UserProfileScreen({super.key});

  @override
  State<UserProfileScreen> createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(Icons.arrow_back_outlined,color: Color(0xFF6A6A6A))),
        title: Text('Profile',
          style: TextStyle(fontFamily: 'Inter',
              color: Color(0xFF6A6A6A),fontWeight: FontWeight.w600,fontSize:15
          ),
        ),
        centerTitle: true,
        actions: [
          InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => Notification_Screen()));
              },
              child: SvgPicture.asset('assets/icon/Icon.svg',height: 22.ah,width:22.aw,)),
          SizedBox(width: 30.aw),
          SvgPicture.asset('assets/icon/Union (1).svg',height: 22.ah,width:22.aw,),
          SizedBox(width: 20.aw),
        ],
        backgroundColor: Colors.white,surfaceTintColor: Colors.white,shadowColor: Colors.black26,
        elevation: 3,
      ),

      body: Padding(
        padding:  EdgeInsets.only(left: 20.h,right: 20.h),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [

            SizedBox(height: 20.ah),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  height: 65.ah,
                  width: 65.aw,
                  decoration: BoxDecoration(
                    // borderRadius: BorderRadius.all(Radius.circular(35)),
                      color: Color(0x305B5B5B),
                      shape: BoxShape.circle,
                      image: DecorationImage(
                        fit: BoxFit.fill,
                        image: AssetImage('assets/image/75dc930fedff8c0a89c101576ace5fce.png'),
                      )),
                  // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                ),
                SizedBox(width: 10.aw),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('E*******a',
                      style: TextStyle(
                          color: Color(0xFF6A6A6A),fontWeight: FontWeight.w500,fontSize:14
                      ),
                    ),

                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SvgPicture.asset('assets/icon/Vector (5).svg',height: 12.ah,width:12.aw,),
                        SizedBox(width: 10.aw),
                        Text('SecurPoint user since February 2024',
                          style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w400,fontSize:12
                          ),
                        ),
                      ],
                    ),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        RichText(
                          text: TextSpan(
                              text: '201+',
                              style: TextStyle(
                                fontSize: 14.fSize,fontWeight: FontWeight.w500,color:Color(0xFF32CD30),
                              ),
                              children: [
                                TextSpan(
                                  text: ' Active listings',
                                  style: TextStyle(
                                    fontSize: 13.fSize,fontWeight: FontWeight.w400,color:Colors.black,
                                  ),)]),),

                        SizedBox(width: 10.aw),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text('Report this profile',
                              style: TextStyle(fontFamily: 'Roboto',
                                  color: Color(0xFF4F4F4F),fontWeight: FontWeight.w400,fontSize:11
                              ),
                            ),
                            SizedBox(width:5.aw),
                            InkWell(
                                onTap: () {
                                  showModalBottomSheet(
                                      context: context,
                                      backgroundColor: Colors.white,
                                      builder: (context) {
                                        return Column(
                                          mainAxisSize: MainAxisSize.min,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children: <Widget>[
                                            SizedBox(height: 15.ah),
                                            ListTile(
                                              title: Text('  Report reason ',
                                                style: TextStyle(
                                                    color: Colors.black,fontWeight: FontWeight.w600,fontSize:16
                                                ),),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),

                                            Padding(
                                              padding: EdgeInsets.only(left: 15,right: 15),
                                              child: primaryTextfield5(
                                                  hintText: 'Lorem ipsum', controller: null),
                                            ),


                                            SizedBox(height:20.ah),
                                            Center(
                                              child: CustomPrimaryBtn2(
                                                title: 'Report this profile',
                                                isLoading: false,
                                                onTap: () {
                                                  // Navigator.push(context, MaterialPageRoute(builder: (context) => SignUp_Screen()));
                                                },
                                              ),
                                            ),
                                            SizedBox(height:30.ah),
                                          ],
                                        );
                                      }
                                  );
                                },
                                child: SvgPicture.asset('assets/icon/ic_report_24px.svg',width:16.aw,height:16.ah,fit: BoxFit.fill,))
                          ],
                        ),
                      ],
                    ),


                  ],
                ),

              ],
            ),

            SizedBox(height: 10.ah),
            InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => ChatScreen()));
              },
              child: Center(
                child: Container(
                  width:216.aw,height:43.ah,
                  decoration: BoxDecoration(
                    color: Color(0xFF32CD30),
                    borderRadius: BorderRadius.circular(40),
                  ),
                  child:  Center(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SvgPicture.asset('assets/icon/Subtract.svg',width: 20.aw,height:20.ah,fit: BoxFit.fill,color: Colors.white,),
                        SizedBox(width: 10.aw),
                        Text('Message User',
                          style: TextStyle(fontFamily: 'Roboto',
                              color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),


            SizedBox(height: 20.ah),
            SizedBox(height: 20.ah),
            Text("Owner’s Note",
              style: TextStyle(fontFamily: 'Roboto',
                  color: Color(0xFF5E605E),fontWeight: FontWeight.w600,fontSize:14
              ),
            ),

            SizedBox(height: 5.ah),
            RichText(
              text: TextSpan(
                  text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqu ullamco laboris nisi...',
                  style: TextStyle(
                    fontSize: 13.fSize,fontWeight: FontWeight.w400,color: Colors.black45,
                  ),
                  children: [
                    TextSpan(
                      text: ' See More',
                      style: TextStyle(decoration: TextDecoration.underline,
                        fontSize: 13.fSize,fontWeight: FontWeight.w400,color:Color(0xFF32CD30),
                      ),)]),),

            SizedBox(height: 20.ah),
            Row(
              // mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('This User’s Assets',
                  style: TextStyle(
                      color: Colors.black,fontWeight: FontWeight.w500,fontSize:14
                  ),
                ),

                InkWell(
                  onTap: () {
                    // Navigator.push(context, MaterialPageRoute(builder: (context) => Populars_Allcity()));
                  },
                  child: Row(
                    children: [
                      Text('Share',
                        style: TextStyle(
                            color: Colors.black,fontWeight: FontWeight.w400,fontSize:13.fSize
                        ),
                      ),
                      SizedBox(width: 10.aw),
                      Icon(Icons.share,color: HexColor('#5E605E'),size: 15,)
                    ],
                  ),
                ),
              ],
            ),

            SizedBox(height: 20.ah),
            /*Card(
              color: Colors.white70,
              shadowColor: Colors.black,
              surfaceTintColor: Colors.white70,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(43),
                  side: BorderSide(
                      color: Colors.black12,width: 1
                  )
              ),
              elevation: 10,
              child: Container(
                // width: 293,
                width: MediaQuery.of(context).size.width,
                height:45,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Colors.white70,
                  borderRadius: BorderRadius.circular(43),

                ),
                child: TextField(
                  cursorColor: Color(0xFF000000),
                  style: TextStyle(color: Colors.black),
                  decoration: InputDecoration(
                      prefixIcon: //Image.asset('assets/images/seearch.png',),
                      Icon(Icons.search, color: Colors.grey,),
                      hintText:"Search Assets",
                      hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),
                      border: InputBorder.none),

                ),
              ),
            ),*/

            /*TextField(
              cursorColor: Color(0xFF000000),
              style: TextStyle(color: Colors.black),
              decoration: InputDecoration(
                isDense: true,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(43.h),
                  borderSide: BorderSide(
                    color: Color(0xFFB5B5B5),
                    width: 1,
                  ),
                ),
                errorStyle: TextStyle(color: Colors.red),
                errorBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(43.h),
                  borderSide: BorderSide(
                    color: Colors.red,
                    width: 1,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(43.h),
                  borderSide: BorderSide(
                    color: Color(0xFF32CD30), width: 1,),),
                prefixIcon: //Image.asset('assets/images/seearch.png',),
                InkWell(
                    onTap: () {
                     // Navigator.push(context, MaterialPageRoute(builder: (context) => SearcScreen()));
                    },
                    child: Icon(Icons.search, color: Colors.grey,size:30)),
                hintText:"Search Assets",
                hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),

              ),

            ),*/
            Card(
              color: Colors.white70,
              shadowColor: Colors.black,
              surfaceTintColor: Colors.white70,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(43),
                  side: BorderSide(
                      color: Colors.black12,width: 1
                  )
              ),
              elevation: 10,
              child: Container(
                // width: 293,
                width: MediaQuery.of(context).size.width,
                height:52,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Colors.white70,
                  borderRadius: BorderRadius.circular(43),

                ),
                child: TextField(
                  cursorColor: Color(0xFF000000),
                  style: TextStyle(color: Colors.black),
                  decoration: InputDecoration(
                      prefixIcon: //Image.asset('assets/images/seearch.png',),
                      Icon(Icons.search, color: Colors.grey,),
                      hintText:"Search Assets",
                      hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),
                      border: InputBorder.none),

                ),
              ),
            ),


            SizedBox(height: 30.ah),
            Text("View all",
              style: TextStyle(fontFamily: 'Roboto',
                  decoration: TextDecoration.underline,
                  color: Color(0xFF5E605E),fontWeight: FontWeight.w600,fontSize:14
              ),
            ),

            SizedBox(height: 10.ah),

            Row(
              // mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Card(
                    color: Colors.white,
                    surfaceTintColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(),
                    child: Container(
                      color: Colors.white,
                      height: 248.ah,width: 156.aw,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [

                          /*Stack(
                              alignment: Alignment.bottomCenter,
                             children: [
                              Container(
                             height: 115,width: MediaQuery.of(context).size.width,

                        // decoration: BoxDecoration(
                        //   color: Colors.red,
                        //   borderRadius: BorderRadius.circular(15)
                            decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(15),
                            image: DecorationImage(
                              image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                              fit: BoxFit.fill,
                            )
                        ),
                        // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                        //   width: MediaQuery.of(context).size.width,
                        //   fit: BoxFit.fill,
                        //
                        // ),
                      ),

                               Image.asset('assets/image/Frame 427320937.png'),
                               SizedBox(height: 20.ah)
                        ]),*/
                          Image.asset('assets/image/image_2024_03_19T08_10_31_939Z.png',height: 113.ah,
                            width: MediaQuery.of(context).size.width,
                            fit: BoxFit.fill,
                          ),

                          SizedBox(height: 10.ah),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                              SizedBox(width: 10.aw),
                              Text('iPhone 15',
                                style: TextStyle(fontFamily: 'Roboto',
                                    color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                ),
                              ),
                            ],
                          ),

                          Text('UIC: 6568520',
                            style: TextStyle(fontFamily: 'Roboto',
                                color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                            ),
                          ),

                          Text('This property is not available\nfor sale. Kindly...',
                            style: TextStyle(fontFamily: 'Roboto',
                                color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                            ),
                          ),

                          SizedBox(height:10.ah),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                width: 96.aw,height: 27.ah,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(40),
                                  color: Color(0xFF32CD30),
                                ),
                                child:  Center(
                                  child: Text('View Asset',
                                    style: TextStyle(fontFamily: 'Roboto',
                                        color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(width:10.aw),
                              Icon(Icons.location_on,size: 25,)
                            ],
                          ),

                          // Align(
                          //   alignment: Alignment.topRight,
                          //   child: Container(
                          //     height: 40.ah,width: 40.aw,
                          //     decoration: BoxDecoration(
                          //         color: Colors.white,
                          //         shape: BoxShape.circle
                          //       //borderRadius: BorderRadius.circular(20)
                          //     ),
                          //   ),
                          // ),

                        ],
                      ),

                    )

                ),

                Card(
                    color: Colors.white,
                    surfaceTintColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(),
                    child: Container(
                      color: Colors.white,
                      height: 248.ah,width: 156.aw,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [

                          /*Stack(
                              alignment: Alignment.bottomCenter,
                             children: [
                              Container(
                             height: 115,width: MediaQuery.of(context).size.width,

                        // decoration: BoxDecoration(
                        //   color: Colors.red,
                        //   borderRadius: BorderRadius.circular(15)
                            decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(15),
                            image: DecorationImage(
                              image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                              fit: BoxFit.fill,
                            )
                        ),
                        // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                        //   width: MediaQuery.of(context).size.width,
                        //   fit: BoxFit.fill,
                        //
                        // ),
                      ),

                               Image.asset('assets/image/Frame 427320937.png'),
                               SizedBox(height: 20.ah)
                        ]),*/
                          Image.asset('assets/image/unlock.png',height: 113.ah,
                            width: MediaQuery.of(context).size.width,
                            fit: BoxFit.fill,
                          ),

                          SizedBox(height: 10.ah),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                              SizedBox(width: 10.aw),
                              Text('iPhone 15',
                                style: TextStyle(fontFamily: 'Roboto',
                                    color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                ),
                              ),
                            ],
                          ),

                          Text('UIC: 6568520',
                            style: TextStyle(fontFamily: 'Roboto',
                                color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                            ),
                          ),

                          Text('This property is not available\nfor sale. Kindly...',
                            style: TextStyle(fontFamily: 'Roboto',
                                color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                            ),
                          ),

                          SizedBox(height:10.ah),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                width: 96.aw,height: 27.ah,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(40),
                                  color: Color(0xFF32CD30),
                                ),
                                child:  Center(
                                  child: Text('View Asset',
                                    style: TextStyle(fontFamily: 'Roboto',
                                        color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(width:10.aw),
                              Icon(Icons.location_on,size: 25,)
                            ],
                          ),

                          // Align(
                          //   alignment: Alignment.topRight,
                          //   child: Container(
                          //     height: 40.ah,width: 40.aw,
                          //     decoration: BoxDecoration(
                          //         color: Colors.white,
                          //         shape: BoxShape.circle
                          //       //borderRadius: BorderRadius.circular(20)
                          //     ),
                          //   ),
                          // ),

                        ],
                      ),

                    )

                )
              ],
            ),

            //SizedBox(height: 10.ah),

          ],
        ),
      ),

    );
  }
}
