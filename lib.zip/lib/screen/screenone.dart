import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../onbord.dart';


class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}


class _SplashScreenState extends State<SplashScreen> {

  bool isFivescondDone = false;

  name(context) async {
   await Future.delayed(Duration(seconds:2));
    isFivescondDone=true;
    setState(() {

    });
   await Future.delayed(Duration(seconds:3));
    onTap(context);

  }
  onTap(context){
    Navigator.push(context, MaterialPageRoute(builder: (context) => OnBoard()));
  }


  @override
  void initState() {
    super.initState();
    name(context) ;
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: isFivescondDone ?Colors.white :Color(0xff32CD30),
      body: Center(
        child: Container(
          height: 180,width: 150,
          //color: Colors.white,
          child: Image.asset( isFivescondDone ? 'assets/image/ic_security_24px.png' :  'assets/image/ic_security_24px (1).png',height: 180,width: 150,
            fit: BoxFit.fill,
          ),
          //FlutterLogo(size:MediaQuery.of(context).size.height)
        ),
      ),

      // body: Center(
      //   child: Container(
      //     height: 104.ah,width:85.2.aw,
      //     color: Color(0xff32CD30),
      //     child: Image.asset('assets/image/ic_security_24px (1).png',height: 104.ah,width:85.2.aw,
      //       fit: BoxFit.fill,
      //     ),
      //     //FlutterLogo(size:MediaQuery.of(context).size.height)
      //   ),
      // ),
    );
  }
}

