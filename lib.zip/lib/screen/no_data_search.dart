import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:securepoint/screen/size.dart';
class SearchNoData_screen extends StatefulWidget {
  const SearchNoData_screen({super.key});

  @override
  State<SearchNoData_screen> createState() => _SearchNoData_screenState();
}

class _SearchNoData_screenState extends State<SearchNoData_screen> {

  final List<String> _options = ['Categories 1', 'Categories 2', 'Categories 3'];
  final List<String> _options1 = ['Subcategories 1', 'Subcategories 2', 'Subcategories 3'];
  String? _selectedOption;
  String? _selectedOption1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Icon(Icons.arrow_back_outlined,color: Color(0xFF6A6A6A))),
          title: Text('Search',
            style: TextStyle(fontFamily: 'Inter',
                color: Colors.black,fontWeight: FontWeight.w600,fontSize:20
            ),
          ),
          centerTitle: true,
          backgroundColor: Colors.white,surfaceTintColor: Colors.white,shadowColor: Colors.black26,
          elevation: 3,
        ),

        body: SingleChildScrollView(
          child: Padding(
            padding:  EdgeInsets.only(left: 20.h,right: 20.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [


                SizedBox(height: 30.ah),
                /*Card(
                color: Colors.white70,
                shadowColor: Colors.black,
                surfaceTintColor: Colors.white70,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(43),
                    side: BorderSide(
                        color: Colors.black12,width: 1
                    )
                ),
                elevation: 10,
                child: Container(
                  // width: 293,
                  width: MediaQuery.of(context).size.width,
                  height:45,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Colors.white70,
                    borderRadius: BorderRadius.circular(43),

                  ),
                  child: TextField(
                    cursorColor: Color(0xFF000000),
                    style: TextStyle(color: Colors.black),
                    decoration: InputDecoration(
                        prefixIcon: //Image.asset('assets/images/seearch.png',),
                        Icon(Icons.search, color: Colors.grey,),
                        hintText:"Search",
                        hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),
                        border: InputBorder.none),

                  ),
                ),
              ),*/

                /*TextField(
                cursorColor: Color(0xFF000000),
                style: TextStyle(color: Colors.black),
                decoration: InputDecoration(
                  isDense: true,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(43.h),
                    borderSide: BorderSide(
                      color: Color(0xFFB5B5B5),
                      width: 1,
                    ),
                  ),
                  errorStyle: TextStyle(color: Colors.red),
                  errorBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(43.h),
                    borderSide: BorderSide(
                      color: Colors.red,
                      width: 1,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(43.h),
                    borderSide: BorderSide(
                      color: Color(0xFF32CD30), width: 1,),),
                  prefixIcon: //Image.asset('assets/images/seearch.png',),
                  InkWell(
                      onTap: () {
                        //Navigator.push(context, MaterialPageRoute(builder: (context) => SearcScreen()));
                      },
                      child: Icon(Icons.search, color: Colors.grey,size:30)),
                  hintText:"Search Assets",
                  hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),

                ),

              ),*/

                Card(
                  color: Colors.white70,
                  shadowColor: Colors.black,
                  surfaceTintColor: Colors.white70,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(43),
                      side: BorderSide(
                          color: Colors.black12,width: 1
                      )
                  ),
                  elevation: 10,
                  child: Container(
                    // width: 293,
                    width: MediaQuery.of(context).size.width,
                    height:52,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: Colors.white70,
                      borderRadius: BorderRadius.circular(43),

                    ),
                    child: TextField(
                      cursorColor: Color(0xFF000000),
                      style: TextStyle(color: Colors.black),
                      decoration: InputDecoration(
                          prefixIcon: //Image.asset('assets/images/seearch.png',),
                          Icon(Icons.search, color: Colors.grey,),
                          hintText:"Search Assets",
                          hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),
                          border: InputBorder.none),

                    ),
                  ),
                ),



                SizedBox(height: 30),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        value: _selectedOption,
                        hint: Text('All Categories',
                          style: TextStyle(fontFamily: 'Roboto',
                              color: Colors.black,fontWeight: FontWeight.w500,fontSize:13
                          ),
                        ),
                        items: _options.map((String option) {
                          return DropdownMenuItem<String>(
                            value: option,
                            child: Text(option),
                          );
                        }).toList(),
                        onChanged: (String? value) {
                          setState(() {
                            _selectedOption = value;
                          });
                        },
                        decoration: InputDecoration(
                          isDense: true,
                          fillColor: Color(0xffF2F2F2),
                          filled: true,
                          contentPadding: EdgeInsets.all(12),
                          // labelText: 'Select an option',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(11.h),
                            borderSide: BorderSide(
                              color: Color(0xFFB5B5B5),
                              width: 1,
                            ),
                          ),
                          errorStyle: TextStyle(color: Colors.red),
                          errorBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(11.h),
                            borderSide: BorderSide(
                              color: Colors.red,
                              width: 1,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(11.h),
                            borderSide: BorderSide(
                              color: Colors.grey, width: 1,),),
                        ),
                      ),
                    ),

                    SizedBox(width: 10.aw,),
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        hint:  Text('All Subcategories',
                          style: TextStyle(fontFamily: 'Roboto',
                              color: Colors.black,fontWeight: FontWeight.w500,fontSize:13
                          ),
                        ),
                        value: _selectedOption1,
                        items: _options1.map((String option) {
                          return DropdownMenuItem<String>(
                            value: option,
                            child: Text(option),
                          );
                        }).toList(),
                        onChanged: (String? value) {
                          setState(() {
                            _selectedOption1 = value;
                          });
                        },
                        decoration: InputDecoration(
                          isDense: true,
                          fillColor: Color(0xffF2F2F2),
                          filled: true,
                          contentPadding: EdgeInsets.all(12),
                          // labelText: 'Select an option',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(11.h),
                            borderSide: BorderSide(
                              color: Color(0xFFB5B5B5),
                              width: 1,
                            ),
                          ),
                          errorStyle: TextStyle(color: Colors.red),
                          errorBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(11.h),
                            borderSide: BorderSide(
                              color: Colors.red,
                              width: 1,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(11.h),
                            borderSide: BorderSide(
                              color: Colors.grey, width: 1,),),
                        ),
                      ),
                    ),

                  ],
                ),


                SizedBox(height: 30),
                Image.asset('assets/image/no data.png',height: 368.ah,width: 368.aw,fit: BoxFit.fill,),
              ],
            ),
          ),
        ),
        floatingActionButton: InkWell(
          onTap: () {
            //Get.to(AddAssets_Screen());
          },
          child: Card(
            surfaceTintColor: Colors.black,
            color: Colors.white,
            shadowColor: Colors.black,
            shape:RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(40),
            ) ,
            elevation: 5,
            child: Container(
              height: 58.ah,width:134.aw,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(40)
              ),
              child: Row(
                // mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text('Add assets', style: TextStyle(
                      color: Color(0xff6A6A6A),fontWeight: FontWeight.w500,fontSize:13
                  ),),
                  SizedBox(width: 5.aw,),
                  Container(
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: Color(0xFF32CD30),width:3
                        )
                    ),
                    height: 48.ah,width: 48.aw,
                    child: Icon(Icons.add,color: Color(0xFF32CD30)),
                  )
                ],
              ),
            ),
          ),
        )
    );
  }
}
