import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:securepoint/screen/size.dart';
import 'const_iteam/const_textfile.dart';
import 'const_iteam/custom_button.dart';

class MYAsset_Details extends StatefulWidget {
  const MYAsset_Details({super.key});

  @override
  State<MYAsset_Details> createState() => _MYAsset_DetailsState();
}

class _MYAsset_DetailsState extends State<MYAsset_Details> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(Icons.arrow_back_outlined,color: Color(0xFF6A6A6A))),
        title: Text('My Asset Details',
          style: TextStyle(fontFamily: 'Inter',
              color: Color(0xFF6A6A6A),fontWeight: FontWeight.w600,fontSize:15
          ),
        ),
        centerTitle: true,
        actions: [
          // SvgPicture.asset('assets/image/Saved Assets.svg',height: 19.ah,width: 14.aw,fit: BoxFit.fill,),
          // SizedBox(width: 10.aw),
          Icon(Icons.share,size:20,color: Color(0xFF6A6A6A)),
          SizedBox(width: 20.aw),
        ],
        backgroundColor: Colors.white,surfaceTintColor: Colors.white,shadowColor: Colors.black26,
        elevation: 3,
      ),
      body: Padding(
        padding:  EdgeInsets.only(left: 20.h,right: 20.h),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [

            SizedBox(height: 10.ah),
            Image.asset('assets/image/image_2024_03_19T08_10_10_398Z.png',
              height: 161.ah,
              width: MediaQuery.of(context).size.width,
              fit: BoxFit.fill,
            ),
            // Container(
            //   height: 161.ah,
            //   width: ,
            // ),
            SizedBox(height:20.ah),
            Icon(Icons.edit,size: 17,color: Color(0xff5E605E),),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('Edit this asset',
                  style: TextStyle(fontFamily: 'Roboto',
                      color: Color(0xFF4F4F4F),fontWeight: FontWeight.w400,fontSize:11
                  ),
                ),
                SizedBox(width:5.aw),
                InkWell(
                    onTap: () {
                      showModalBottomSheet(
                          context: context,
                          backgroundColor: Colors.white,
                          builder: (context) {
                            return Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                SizedBox(height: 15.ah),
                                ListTile(
                                  title: Text('  Report reason ',
                                    style: TextStyle(
                                        color: Colors.black,fontWeight: FontWeight.w600,fontSize:16
                                    ),),
                                  onTap: () {
                                    Navigator.pop(context);
                                  },
                                ),

                                Padding(
                                  padding: EdgeInsets.only(left: 15,right: 15),
                                  child: primaryTextfield5(
                                      hintText: 'Lorem ipsum', controller: null

                                  ),
                                ),



                                SizedBox(height:20.ah),
                                Center(
                                  child: CustomPrimaryBtn2(
                                    title: 'Report this asset',
                                    isLoading: false,
                                    onTap: () {
                                      // Navigator.push(context, MaterialPageRoute(builder: (context) => SignUp_Screen()));
                                    },
                                  ),
                                ),
                                SizedBox(height:30.ah),
                              ],
                            );
                          }
                      );
                    },
                    child: SvgPicture.asset('assets/icon/ic_report_24px.svg',width: 15.aw,height: 15.ah,fit: BoxFit.fill,))
              ],
            ),

            Text("Jona's White House in up Town",
              style: TextStyle(fontFamily: 'Roboto',
                  color: Color(0xFF4F4F4F),fontWeight: FontWeight.w500,fontSize:18
              ),
            ),
            Text('05 JAN AT 22:01',
              style: TextStyle(fontFamily: 'Roboto',
                  color: Color(0xFF4F4F4F),fontWeight: FontWeight.w400,fontSize:10
              ),
            ),

            SizedBox(height: 20.ah),
            Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  width: 96.aw,height: 27.ah,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(40),
                    color: Color(0xFF32CD30),
                  ),
                  child:  Center(
                    child: Text('Promote Asset',
                      style: TextStyle(fontFamily: 'Roboto',
                          color: Colors.white,fontWeight: FontWeight.w600,fontSize:12.fSize
                      ),
                    ),
                  ),
                ),
                SizedBox(width:120.aw),

                Text('UIC: 123456',
                  style: TextStyle(fontFamily: 'Roboto',
                      color: Color(0xFF32CD30),fontWeight: FontWeight.w500,fontSize:21.fSize
                  ),
                ),
              ],
            ),

            SizedBox(height: 20.ah),
            Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                    //mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SvgPicture.asset('assets/icon/icon _warning_.svg',height: 15.ah,width: 16.aw,fit: BoxFit.fill,),
                      SizedBox(width:5.aw),
                      Text('This asset is not available!',
                        style: TextStyle(fontFamily: 'Roboto',
                            color: Color(0xFFBD3124),fontWeight: FontWeight.w400,fontSize:11.fSize
                        ),
                      ),
                    ]
                ),
                SizedBox(width:120.aw),

                Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Icon(Icons.location_on,size: 35,color: Color(0xFF6C6C6C)),
                    Text('View on map',
                      style: TextStyle(fontFamily: 'Roboto',
                          color: Color(0xFF6C6C6C),fontWeight: FontWeight.w400,fontSize:11.fSize
                      ),
                    ),
                  ],
                )
              ],
            ),

            SizedBox(height: 20.ah),
            Text("Asset Information",
              style: TextStyle(fontFamily: 'Roboto',
                  color: Color(0xFF5E605E),fontWeight: FontWeight.w600,fontSize:14
              ),
            ),

            SizedBox(height: 20.ah),
            RichText(
              text: TextSpan(
                  text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqu ullamco laboris nisi...',
                  style: TextStyle(
                    fontSize: 13.fSize,fontWeight: FontWeight.w400,color: Colors.black45,
                  ),
                  children: [
                    TextSpan(
                      text: ' See More',
                      style: TextStyle(
                        fontSize: 13.fSize,fontWeight: FontWeight.w400,color:Color(0xFF32CD30),
                      ),)]),),


            SizedBox(height: 50.ah),
            Center(
              child: Text('Promote Asset',style:
                TextStyle( fontFamily: 'Roboto',
                  fontSize: 13.fSize,fontWeight: FontWeight.w600,color:Color(0xFF32CD30),
                ),
              ),
            ),

            SizedBox(height: 10.ah),
            Center(
              child: Text('Lorem ipsum dolor sit amet, consectetur \n           adipiscing elit,sed do eiu',style:
              TextStyle(
                fontSize: 13.fSize,fontWeight: FontWeight.w400,color:Colors.black.withOpacity(0.50),
              ),
              ),
            ),

            SizedBox(height: 10.ah),
            Center(
              child: CustomPrimaryBtn3(
                title: 'Boost',
                isLoading: false,
                onTap: () {
                  //  Get.to(PremiumScreen());
                  //Navigator.push(context, MaterialPageRoute(builder: (context) => PremiumScreen()));

                },
              ),
            ),


            SizedBox(height: 50.ah),

          ],
        ),
      ),
    );
  }
}
