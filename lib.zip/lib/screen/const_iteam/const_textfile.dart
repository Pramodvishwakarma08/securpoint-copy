import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:securepoint/screen/size.dart';

SizedBox primaryTextfield({
  required String hintText,
  required controller,
  var validator,
  int? maxLines,
  String? suffixIconn,
  bool? obscureText,
  VoidCallback? onTap,
  TextInputType? textInputType,
  bool? enabled,
  String? initialValue,
  int? maxLength,
  List<TextInputFormatter>? inputFormatters,
}) {
  return SizedBox(
    height: 44.ah,
    child: TextFormField(
      cursorColor: Colors.black,
      enabled: enabled ?? true,
      // onTap: onTap,
      maxLength: maxLength,
      initialValue: initialValue,
      keyboardType: textInputType ?? TextInputType.text,
      style: const TextStyle(color: Colors.black),
      inputFormatters: inputFormatters ?? null, //
      // Apply the custom formatter
      maxLines: maxLines ?? 1,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      controller: controller,
      validator: validator,

      decoration: InputDecoration(
        counterText: "",
        contentPadding: const EdgeInsets.only(left: 10),
        // filled: true,
        // fillColor: Colors.grey.withOpacity(.25),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Color(0xFFB5B5B5),
            width: 1,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Color(0xFFB5B5B5),
            width: 1,
          ),
        ),
        errorStyle: TextStyle(color: Colors.red),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Colors.red,
            width: 1,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Color(0xFF32CD30), width: 1,),),

        hintText: hintText,
        hintStyle: TextStyle(
            color: Colors.black.withOpacity(.40),
            fontWeight: FontWeight.bold,
            fontSize: 12),
        suffixIcon: suffixIconn == null ? const SizedBox(height: 1, width: 1,)
            : IconButton(
          onPressed: onTap,
          icon: SvgPicture.asset(
            suffixIconn,
            fit: BoxFit.none,
            color: Colors.black54,
          ),
        ),
      ),

      obscureText: obscureText ?? false,
      // validator: validator,
    ),
  );
}


SizedBox primaryTextfield1({
  required String hintText,
  required controller,
  var validator,
  int? maxLines,
  String? suffixIconn,
  bool? obscureText,
  VoidCallback? onTap,
  TextInputType? textInputType,
  bool? enabled,
  String? initialValue,
  int? maxLength,
  List<TextInputFormatter>? inputFormatters,
}) {
  return SizedBox(
    height: 44.ah,
    child: TextFormField(
      cursorColor: Colors.black,
      enabled: enabled ?? true,
      // onTap: onTap,
      maxLength: maxLength,
      initialValue: initialValue,
      keyboardType: textInputType ?? TextInputType.phone,
      style: const TextStyle(color: Colors.black),
      inputFormatters: inputFormatters ?? null, //
      // Apply the custom formatter
      maxLines: maxLines ?? 1,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      controller: controller,
      validator: validator,

      decoration: InputDecoration(
        counterText: "",
        contentPadding: const EdgeInsets.only(left: 10),
        // filled: true,
        // fillColor: Colors.grey.withOpacity(.25),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Color(0xFFB5B5B5),
            width: 1,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Color(0xFFB5B5B5),
            width: 1,
          ),
        ),
        errorStyle: TextStyle(color: Colors.red),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Colors.red,
            width: 1,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Color(0xFF32CD30), width: 1,),),

        hintText: hintText,
        hintStyle: TextStyle(
            color: Colors.black.withOpacity(.40),
            fontWeight: FontWeight.bold,
            fontSize: 12),
        suffixIcon: suffixIconn == null ? const SizedBox(height: 1, width: 1,)
            : IconButton(
          onPressed: onTap,
          icon: SvgPicture.asset(
            suffixIconn,
            fit: BoxFit.none,
            color: Colors.black54,
          ),
        ),
      ),

      obscureText: obscureText ?? false,
      // validator: validator,
    ),
  );
}



SizedBox primaryTextfield2({
  required String hintText,
  required controller,
  var validator,
  int? maxLines,
  String? suffixIconn,
  bool? obscureText,
  VoidCallback? onTap,
  TextInputType? textInputType,
  bool? enabled,
  String? initialValue,
  int? maxLength,
  List<TextInputFormatter>? inputFormatters,
}) {
  return SizedBox(
    height: 44.ah,
    //width: 240.aw,
    child: TextFormField(
      cursorColor: Colors.black,
      enabled: enabled ?? true,
      // onTap: onTap,
      maxLength: maxLength,
      initialValue: initialValue,
      keyboardType: textInputType ?? TextInputType.text,
      style: const TextStyle(color: Colors.black),
      inputFormatters: inputFormatters ?? null, //
      // Apply the custom formatter
      maxLines: maxLines ?? 1,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      controller: controller,
      validator: validator,

      decoration: InputDecoration(
        counterText: "",
        contentPadding: const EdgeInsets.only(left: 10),
        // filled: true,
        // fillColor: Colors.grey.withOpacity(.25),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Color(0xFFB5B5B5),
            width: 1,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Color(0xFFB5B5B5),
            width: 1,
          ),
        ),
        errorStyle: TextStyle(color: Colors.red),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Colors.red,
            width: 1,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Color(0xFF32CD30), width: 1,),),

        hintText: hintText,
        hintStyle: TextStyle(
            color: Colors.black.withOpacity(.40),
            fontWeight: FontWeight.bold,
            fontSize: 12),
        suffixIcon: suffixIconn == null ? const SizedBox(height: 1, width: 1,)
            : IconButton(
          onPressed: onTap,
          icon: SvgPicture.asset(
            suffixIconn,
            fit: BoxFit.none,
            color: Colors.black54,
          ),
        ),
      ),

      obscureText: obscureText ?? false,
      // validator: validator,
    ),
  );
}


SizedBox primaryTextfield3({
  required String hintText,
  required controller,
  var validator,
  int? maxLines,
  String? suffixIconn,
  bool? obscureText,
  VoidCallback? onTap,
  TextInputType? textInputType,
  bool? enabled,
  String? initialValue,
  int? maxLength,
  List<TextInputFormatter>? inputFormatters,
}) {
  return SizedBox(
    height: 102.ah,
    //width: 240.aw,
    child: TextFormField(
      cursorColor: Colors.black,
      enabled: enabled ?? true,
      // onTap: onTap,
      maxLength: maxLength,
      initialValue: initialValue,
      keyboardType: textInputType ?? TextInputType.text,
      style: const TextStyle(color: Colors.black),
      inputFormatters: inputFormatters ?? null, //
      // Apply the custom formatter
      maxLines: maxLines ?? 5,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      controller: controller,
      validator: validator,

      decoration: InputDecoration(
        counterText: "",
        contentPadding:  EdgeInsets.only(left: 10.h,top:12),
        // filled: true,
        // fillColor: Colors.grey.withOpacity(.25),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Color(0xFFB5B5B5),
            width: 1,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Color(0xFFB5B5B5),
            width: 1,
          ),
        ),
        errorStyle: TextStyle(color: Colors.red),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Colors.red,
            width: 1,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Color(0xFF32CD30), width: 1,),),

        hintText: hintText,
        hintStyle: TextStyle(
            color: Colors.black.withOpacity(.40),
            fontWeight: FontWeight.bold,
            fontSize: 12),
        suffixIcon: suffixIconn == null ? const SizedBox(height: 1, width: 1,)
            : IconButton(
          onPressed: onTap,
          icon: SvgPicture.asset(
            suffixIconn,
            fit: BoxFit.none,
            color: Colors.black54,
          ),
        ),
      ),

      obscureText: obscureText ?? false,
      // validator: validator,
    ),
  );
}
class Dropdown extends StatefulWidget {
  const Dropdown({super.key});

  @override
  State<Dropdown> createState() => _DropdownState();
}

class _DropdownState extends State<Dropdown> {
  @override
  Widget build(BuildContext context) {
    final List<String> _options = ['Stolen 1', 'Stolen 2', 'Stolen 3'];
    String? _selectedOption;
    return DropdownButtonFormField<String>(

      value: _selectedOption,
      items: _options.map((String option) {
        return DropdownMenuItem<String>(
          value: option,
          child: Text(option),
        );
      }).toList(),
      onChanged: (String? value) {
        setState(() {
          _selectedOption = value;
        });
      },
      decoration: InputDecoration(
        contentPadding: EdgeInsets.all(12),
        // labelText: 'Select an option',
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Color(0xFFB5B5B5),
            width: 1,
          ),
        ),
        errorStyle: TextStyle(color: Colors.red),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Colors.red,
            width: 1,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Colors.grey, width: 1,),),
      ),
    );
  }
}



class CustomDropdownTextField extends StatelessWidget {
  final String? selectedItem;
  final List<DropdownMenuItem<String>> demoItems;
  final Function(String?) onSelect;

  const CustomDropdownTextField({
    Key? key,
    required this.selectedItem,
    required this.demoItems,
    required this.onSelect,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      value: selectedItem,
      onChanged: onSelect,
      items: demoItems,
      decoration: const InputDecoration(
        hintText: "Choose name",
        border: OutlineInputBorder(),
        contentPadding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
      ),
    );
  }
}


SizedBox primaryTextfield4({
  required String hintText,
  required controller,
  var validator,
  int? maxLines,
  String? suffixIconn,
  bool? obscureText,
  VoidCallback? onTap,
  TextInputType? textInputType,
  bool? enabled,
  String? initialValue,
  int? maxLength,
  List<TextInputFormatter>? inputFormatters,
}) {
  return SizedBox(
    height: 44.ah,
    child: TextFormField(
      cursorColor: Colors.black,
      enabled: enabled ?? true,
      // onTap: onTap,
      maxLength: maxLength,
      initialValue: initialValue,
      keyboardType: textInputType ?? TextInputType.text,
      style: const TextStyle(color: Colors.black),
      inputFormatters: inputFormatters ?? null, //
      // Apply the custom formatter
      maxLines: maxLines ?? 1,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      controller: controller,
      validator: validator,

      decoration: InputDecoration(
        counterText: "",
        contentPadding: const EdgeInsets.only(left: 10),
        // filled: true,
        // fillColor: Colors.grey.withOpacity(.25),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Color(0xFFB5B5B5),
            width: 1,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Color(0xFFB5B5B5),
            width: 1,
          ),
        ),
        errorStyle: TextStyle(color: Colors.red),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Colors.red,
            width: 1,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11.h),
          borderSide: BorderSide(
            color: Color(0xFF32CD30), width: 1,),),

        hintText: hintText,
        hintStyle: TextStyle(
            color: Colors.black.withOpacity(.40),
            fontWeight: FontWeight.bold,
            fontSize: 12),
        suffixIcon: suffixIconn == null ? const SizedBox(height: 1, width: 1,)
            : IconButton(
          onPressed: onTap,
          icon: SvgPicture.asset(
            suffixIconn,
            fit: BoxFit.none,
            color: Colors.black54,
          ),
        ),
      ),

      obscureText: obscureText ?? false,
      // validator: validator,
    ),
  );
}



SizedBox primaryTextfield5({
  required String hintText,
  required controller,
  var validator,
  int? maxLines,
  String? suffixIconn,
  bool? obscureText,
  VoidCallback? onTap,
  TextInputType? textInputType,
  bool? enabled,
  String? initialValue,
  int? maxLength,
  List<TextInputFormatter>? inputFormatters,
}) {
  return SizedBox(
    height: 45.ah,
    child: TextFormField(
      cursorColor: Colors.black,
      enabled: enabled ?? true,
      // onTap: onTap,
      maxLength: maxLength,
      initialValue: initialValue,
      keyboardType: textInputType ?? TextInputType.text,
      style: const TextStyle(color: Colors.black,fontWeight: FontWeight.bold,
          fontSize: 16),
      inputFormatters: inputFormatters ?? null, //
      // Apply the custom formatter
      maxLines: maxLines ?? 1,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      controller: controller,
      validator: validator,

      decoration: InputDecoration(
        counterText: "",
        contentPadding: const EdgeInsets.only(left: 10,right: 10),
        // filled: true,
        // fillColor: Colors.grey.withOpacity(.25),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.h),
          borderSide: BorderSide(
            color: Colors.black,
            width: 1,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.h),
          borderSide: BorderSide(
            color: Colors.black,
            width: 1,
          ),
        ),
        errorStyle: TextStyle(color: Colors.red),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.h),
          borderSide: BorderSide(
            color: Colors.red,
            width: 1,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.h),
          borderSide: BorderSide(
            color: Color(0xFF32CD30), width: 1,),),

        hintText: hintText,
        hintStyle: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: 16),
        suffixIcon: suffixIconn == null ? const SizedBox(height: 1, width: 1,)
            : IconButton(
          onPressed: onTap,
          icon: SvgPicture.asset(
            suffixIconn,
            fit: BoxFit.none,
            color: Colors.black54,
          ),
        ),
      ),

      obscureText: obscureText ?? false,
      // validator: validator,
    ),
  );
}