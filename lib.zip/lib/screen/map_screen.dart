import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/svg.dart';
import 'package:securepoint/screen/size.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  // static final LatLng _kMapCenter =
  // LatLng(19.018255973653343, 72.84793849278007);
  //
  // static final CameraPosition _kInitialPosition =
  // CameraPosition(target: _kMapCenter, zoom: 11.0, tilt: 0, bearing: 0);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          leading: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Icon(Icons.arrow_back_outlined,color: Color(0xFF6A6A6A))),
          backgroundColor: Colors.white,surfaceTintColor: Colors.white,shadowColor: Colors.black26,
          elevation: 1,
        ),
        body:  SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [

              Stack(
                alignment: Alignment.bottomCenter,
                children: [
                  Container(
                    height: MediaQuery.of(context).size.height,
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                        image: DecorationImage(
                            image: AssetImage('assets/image/image 1625.png')
                        )
                    ),
                  ),

                  Container(
                    height: 338.ah,
                    width: 390.aw,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(16),
                            topRight: Radius.circular(16)
                        )
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [

                        SizedBox(height: 15,),
                        Divider(
                          color: Color(0xff4A4A4F),
                          height: 1,thickness: 3,
                          indent:190.2 ,endIndent: 190.2,
                        ),

                        SizedBox(height: 35,),
                        Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text("Jona's White House in up Town",
                                style: TextStyle(fontFamily: 'Robot',
                                    color: Colors.black,fontWeight: FontWeight.bold,
                                    fontSize:15
                                ),
                              ),

                              Text('UIC: 6568520',
                                style: TextStyle(
                                    color: Color(0xff32CD30),fontWeight: FontWeight.w500,fontSize:14
                                ),
                              ),
                            ],
                          ),
                        ),

                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text('E*******a',
                                  style: TextStyle(
                                      color: Color(0xFF6A6A6A),fontWeight: FontWeight.w500,fontSize:14
                                  ),
                                ),
                                Text('SecurPoint user since February 2024',
                                  style: TextStyle(
                                      color: Colors.black,fontWeight: FontWeight.w500,fontSize:14
                                  ),
                                ),

                              ],
                            ),
                            SizedBox(width: 30.aw),
                            Container(
                              height: 65.ah,
                              width: 65.aw,
                              decoration: BoxDecoration(
                                // borderRadius: BorderRadius.all(Radius.circular(35)),
                                  color: Color(0x305B5B5B),
                                  shape: BoxShape.circle,
                                  image: DecorationImage(
                                    fit: BoxFit.fill,
                                    image: AssetImage('assets/image/75dc930fedff8c0a89c101576ace5fce.png'),
                                  )),
                              // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                            ),
                          ],
                        ),


                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            SizedBox(width:30.aw,),
                            Container(
                              width:100.aw,height:31.ah,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                    color: Color(0xFF32CD30),
                                  )
                              ),
                              child:  Center(
                                child: Text('Add Asset',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: Color(0xFF32CD30),fontWeight: FontWeight.w600,fontSize:14.fSize
                                  ),
                                ),
                              ),
                            ),

                            SizedBox(width:10.aw,),
                            Container(
                              width:100.aw,height:31.ah,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                color: Color(0xFF32CD30),
                              ),
                              child:  Center(
                                child: Text('Messages',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),


                      ],
                    ),
                  )
                ],
              ),

            ],
          ),
        ),

        floatingActionButton: InkWell(
          onTap: () {
            //   Get.to(AddAssets_Screen());
          },
          child: Card(
            surfaceTintColor: Colors.black,
            color: Colors.white,
            shadowColor: Colors.black,
            shape:RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(40),
            ) ,
            elevation: 5,
            child: Container(
              height: 58.ah,width:134.aw,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(40)
              ),
              child: Row(
                // mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text('Add assets', style: TextStyle(
                      color: Color(0xff6A6A6A),fontWeight: FontWeight.w500,fontSize:13
                  ),),
                  SizedBox(width: 5.aw,),
                  Container(
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: Color(0xFF32CD30),width:3
                        )
                    ),
                    height: 48.ah,width: 48.aw,
                    child: Icon(Icons.add,color: Color(0xFF32CD30)),
                  )
                ],
              ),
            ),
          ),
        )

    );
  }
}
