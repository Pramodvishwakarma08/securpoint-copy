import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:securepoint/screen/size.dart';
import 'const_iteam/const_textfile.dart';
import 'const_iteam/custom_button.dart';
import 'my_edit_profile.dart';
import 'my_user_profile.dart';
import 'notification_screen.dart';

class MyProfile_Screen extends StatefulWidget {
  const MyProfile_Screen({super.key});

  @override
  State<MyProfile_Screen> createState() => _MyProfile_ScreenState();
}

class _MyProfile_ScreenState extends State<MyProfile_Screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Icon(Icons.arrow_back_outlined,color: Color(0xFF6A6A6A))),
          title: Text('My Profile',
            style: TextStyle(fontFamily: 'Inter',
                color: Color(0xFF6A6A6A),fontWeight: FontWeight.w600,fontSize:15
            ),
          ),
          centerTitle: true,
          actions: [
            InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => Notification_Screen()));
                },
                child: SvgPicture.asset('assets/icon/Icon.svg',height: 22.ah,width:22.aw,)),
            SizedBox(width: 30.aw),
            SvgPicture.asset('assets/icon/Union (1).svg',height: 22.ah,width:22.aw,),
            SizedBox(width: 20.aw),
          ],
          backgroundColor: Colors.white,surfaceTintColor: Colors.white,shadowColor: Colors.black26,
          elevation: 3,
        ),

        body: Padding(
          padding:  EdgeInsets.only(left: 20.h,right: 20.h),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [

              SizedBox(height: 20.ah),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    height: 65.ah,
                    width: 65.aw,
                    decoration: BoxDecoration(
                      // borderRadius: BorderRadius.all(Radius.circular(35)),
                        color: Color(0x305B5B5B),
                        shape: BoxShape.circle,
                        image: DecorationImage(
                          fit: BoxFit.fill,
                          image: AssetImage('assets/image/75dc930fedff8c0a89c101576ace5fce.png'),
                        )),
                    // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                  ),
                  SizedBox(width: 10.aw),

                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      InkWell(
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) => EditProfile_Screen()));

                          },
                          child: Icon(Icons.edit,size:20.adaptSize,)),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text('E*******a',
                            style: TextStyle(
                                color: Color(0xFF6A6A6A),fontWeight: FontWeight.w500,fontSize:14
                            ),
                          ),
                          SizedBox(width: 15.aw),
                          Text('Unhide',
                            style: TextStyle(
                                color: Color(0xFF6A6A6A),fontWeight: FontWeight.w500,fontSize:14
                            ),
                          ),
                          SizedBox(width: 5.aw),
                          SvgPicture.asset('assets/icon/hideeeye.svg',height: 12.ah,width:12.aw,),
                        ],
                      ),

                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [SvgPicture.asset('assets/icon/Vector (5).svg',height: 12.ah,width:12.aw,),
                          SizedBox(width: 10.aw),

                          Text('SecurPoint user since February 2024',
                            style: TextStyle(
                                color: Colors.black,fontWeight: FontWeight.w400,fontSize:12
                            ),
                          ),
                        ],
                      ),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          RichText(
                            text: TextSpan(
                                text: '201+',
                                style: TextStyle(
                                  fontSize: 14.fSize,fontWeight: FontWeight.w500,color:Color(0xFF32CD30),
                                ),
                                children: [
                                  TextSpan(
                                    text: ' Active listings',
                                    style: TextStyle(
                                      fontSize: 13.fSize,fontWeight: FontWeight.w400,color:Colors.black,
                                    ),)]),),

                        ],
                      ),
                    ],
                  ),

                ],
              ),

              SizedBox(height: 10.ah),
              Center(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    InkWell(
                      onTap:(){},
                      child: Container(
                        width:100.aw,height:31.ah,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color: Color(0xFF32CD30),
                            )
                        ),
                        child:  Center(
                          child: Text('Add Asset',
                            style: TextStyle(fontFamily: 'Roboto',
                                color: Color(0xFF32CD30),fontWeight: FontWeight.w600,fontSize:14.fSize
                            ),
                          ),
                        ),
                      ),
                    ),

                    SizedBox(width:10.aw,),
                    InkWell(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => UserProfileScreen()));

                      },
                      child: Container(
                        width:100.aw,height:31.ah,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          color: Color(0xFF32CD30),
                        ),
                        child:  Center(
                          child: Text('Messages',
                            style: TextStyle(fontFamily: 'Roboto',
                                color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),


              SizedBox(height: 20.ah),
              SizedBox(height: 20.ah),
              Row(
                children: [
                  Text("Owner’s Note",
                    style: TextStyle(fontFamily: 'Roboto',
                        color: Color(0xFF5E605E),fontWeight: FontWeight.w600,fontSize:14
                    ),
                  ),
                  SizedBox(width: 5.aw,),
                  Icon(Icons.edit)
                ],
              ),

              SizedBox(height: 5.ah),
              RichText(
                text: TextSpan(
                    text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqu ullamco laboris nisi...',
                    style:TextStyle(
                      fontSize: 13.fSize,fontWeight: FontWeight.w400,color: Colors.black45,
                    ),
                    children: [
                      TextSpan(
                        text: ' See More',
                        style: TextStyle(decoration: TextDecoration.underline,
                          fontSize: 13.fSize,fontWeight: FontWeight.w400,color:Color(0xFF32CD30),
                        ),)]),),

              SizedBox(height: 20.ah),
              Row(
                // mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('My Assets',
                    style: TextStyle(
                        color: Color(0xff5E605E),fontWeight: FontWeight.w500,fontSize:14
                    ),
                  ),

                  InkWell(
                    onTap: () {
                      // Navigator.push(context, MaterialPageRoute(builder: (context) => Populars_Allcity()));
                    },
                    child: Row(
                      children: [
                        Text('Share',
                          style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w400,fontSize:13.fSize
                          ),
                        ),
                        SizedBox(width: 10.aw),

                        Icon(Icons.share,color: HexColor('#5E605E'),size: 15,)
                      ],
                    ),
                  ),
                ],
              ),

              SizedBox(height: 20.ah),
              /*Card(
              color: Colors.white70,
              shadowColor: Colors.black,
              surfaceTintColor: Colors.white70,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(43),
                  side: BorderSide(
                      color: Colors.black12,width: 1
                  )
              ),
              elevation: 10,
              child: Container(
                // width: 293,
                width: MediaQuery.of(context).size.width,
                height:45,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Colors.white70,
                  borderRadius: BorderRadius.circular(43),

                ),
                child: TextField(
                  cursorColor: Color(0xFF000000),
                  style: TextStyle(color: Colors.black),
                  decoration: InputDecoration(
                      prefixIcon: //Image.asset('assets/images/seearch.png',),
                      Icon(Icons.search, color: Colors.grey,),
                      hintText:"Search Assets",
                      hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),
                      border: InputBorder.none),

                ),
              ),
            ),*/

              /* TextField(
              cursorColor: Color(0xFF000000),
              style: TextStyle(color: Colors.black),
              decoration: InputDecoration(
                isDense: true,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(43.h),
                  borderSide: BorderSide(
                    color: Color(0xFFB5B5B5),
                    width: 1,
                  ),
                ),
                errorStyle: TextStyle(color: Colors.red),
                errorBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(43.h),
                  borderSide: BorderSide(
                    color: Colors.red,
                    width: 1,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(43.h),
                  borderSide: BorderSide(
                    color: Color(0xFF32CD30), width: 1,),),
                prefixIcon: //Image.asset('assets/images/seearch.png',),
                InkWell(
                    onTap: () {
                     // Navigator.push(context, MaterialPageRoute(builder: (context) => SearcScreen()));
                    },
                    child: Icon(Icons.search, color: Colors.grey,size:30)),
                hintText:"Search Assets",
                hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),

              ),

            ),*/

              /*Padding(
              padding:  EdgeInsets.only(left: 2.aw,right: 2.aw),
              child: Expanded(
                child: Card(
                  child: Container(
                    // width: 293,
                    width: MediaQuery.of(context).size.width,
                    height:45,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(color: Color(0xFFe9eaec),
                        borderRadius: BorderRadius.circular(14)),
                    child: TextField(
                      cursorColor: Color(0xFF000000),
                      style: TextStyle(color: Colors.black),
                      decoration: InputDecoration(
                          prefixIcon:
                          //Image.asset('assets/images/seearch.png',),
                          Icon(Icons.search, color: Colors.grey),
                          hintText: "Search for profiles,topics,reviews, etc”",
                          hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),
                          border: InputBorder.none),
                    ),
                  ),
                ),
              ),
            ),*/
              Card(
                color: Colors.white70,
                shadowColor: Colors.black,
                surfaceTintColor: Colors.white70,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(43),
                    side: BorderSide(
                        color: Colors.black12,width: 1
                    )
                ),
                elevation: 10,
                child: Container(
                  // width: 293,
                  width: MediaQuery.of(context).size.width,
                  height:52,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Colors.white70,
                    borderRadius: BorderRadius.circular(43),

                  ),
                  child: TextField(
                    cursorColor: Color(0xFF000000),
                    style: TextStyle(color: Colors.black),
                    decoration: InputDecoration(
                        prefixIcon: //Image.asset('assets/images/seearch.png',),
                        Icon(Icons.search, color: Colors.grey,),
                        hintText:"Search Assets",
                        hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),
                        border: InputBorder.none),

                  ),
                ),
              ),


              SizedBox(height: 30.ah),
              Text("View all",
                style: TextStyle(fontFamily: 'Roboto',
                    decoration: TextDecoration.underline,
                    color: Color(0xFF5E605E),fontWeight: FontWeight.w600,fontSize:14
                ),
              ),

              SizedBox(height: 10.ah),

              Row(
                // mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Card(
                      color: Colors.white,
                      surfaceTintColor: Colors.white,
                      elevation: 0,
                      shape: RoundedRectangleBorder(),
                      child: Container(
                        color: Colors.white,
                        height: 248.ah,width: 156.aw,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [

                            /*Stack(
                              alignment: Alignment.bottomCenter,
                             children: [
                              Container(
                             height: 115,width: MediaQuery.of(context).size.width,

                        // decoration: BoxDecoration(
                        //   color: Colors.red,
                        //   borderRadius: BorderRadius.circular(15)
                            decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(15),
                            image: DecorationImage(
                              image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                              fit: BoxFit.fill,
                            )
                        ),
                        // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                        //   width: MediaQuery.of(context).size.width,
                        //   fit: BoxFit.fill,
                        //
                        // ),
                      ),

                               Image.asset('assets/image/Frame 427320937.png'),
                               SizedBox(height: 20.ah)
                        ]),*/
                            Image.asset('assets/image/image_2024_03_19T08_10_31_939Z.png',height: 113.ah,
                              width: MediaQuery.of(context).size.width,
                              fit: BoxFit.fill,
                            ),

                            SizedBox(height: 10.ah),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                SizedBox(width: 10.aw),
                                Text('iPhone 15',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                  ),
                                ),
                              ],
                            ),

                            Text('UIC: 6568520',
                              style: TextStyle(fontFamily: 'Roboto',
                                  color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                              ),
                            ),

                            Text('This property is not available\nfor sale. Kindly...',
                              style: TextStyle(fontFamily: 'Roboto',
                                  color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                              ),
                            ),

                            SizedBox(height:10.ah),
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Icon(Icons.lock),
                                SizedBox(width: 5.aw),
                                Icon(Icons.remove_red_eye),
                                SizedBox(width: 5.aw),
                                Icon(Icons.edit),
                                SizedBox(width: 5.aw),
                                Icon(Icons.delete),
                              ],
                            ),

                          ],
                        ),

                      )

                  ),

                  Card(
                      color: Colors.white,
                      surfaceTintColor: Colors.white,
                      elevation: 0,
                      shape: RoundedRectangleBorder(),
                      child: Container(
                        color: Colors.white,
                        height: 248.ah,width: 156.aw,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [

                            /*Stack(
                              alignment: Alignment.bottomCenter,
                             children: [
                              Container(
                             height: 115,width: MediaQuery.of(context).size.width,

                        // decoration: BoxDecoration(
                        //   color: Colors.red,
                        //   borderRadius: BorderRadius.circular(15)
                            decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(15),
                            image: DecorationImage(
                              image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                              fit: BoxFit.fill,
                            )
                        ),
                        // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                        //   width: MediaQuery.of(context).size.width,
                        //   fit: BoxFit.fill,
                        //
                        // ),
                      ),

                               Image.asset('assets/image/Frame 427320937.png'),
                               SizedBox(height: 20.ah)
                        ]),*/
                            Image.asset('assets/image/unlock.png',height: 113.ah,
                              width: MediaQuery.of(context).size.width,
                              fit: BoxFit.fill,
                            ),

                            SizedBox(height: 10.ah),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                SizedBox(width: 10.aw),
                                Text('iPhone 15',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                  ),
                                ),
                              ],
                            ),

                            Text('UIC: 6568520',
                              style: TextStyle(fontFamily: 'Roboto',
                                  color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                              ),
                            ),

                            Text('This property is not available\nfor sale. Kindly...',
                              style: TextStyle(fontFamily: 'Roboto',
                                  color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                              ),
                            ),

                            SizedBox(height:10.ah),
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Icon(Icons.lock),
                                SizedBox(width: 5.aw),
                                Icon(Icons.remove_red_eye),
                                SizedBox(width: 5.aw),
                                Icon(Icons.edit),
                                SizedBox(width: 5.aw),
                                Icon(Icons.delete),
                              ],
                            ),

                          ],
                        ),

                      )

                  )
                ],
              ),

              SizedBox(height: 10.ah),
            ],
          ),
        ),
        floatingActionButton: InkWell(
          onTap: () {
            // Get.to(AddAssets_Screen());
          },
          child: Card(
            surfaceTintColor: Colors.black,
            color: Colors.white,
            shadowColor: Colors.black,
            shape:RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(40),
            ) ,
            elevation: 5,
            child: Container(
              height: 58.ah,width:134.aw,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(40)
              ),
              child: Row(
                // mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text('Add assets', style: TextStyle(
                      color: Color(0xff6A6A6A),fontWeight: FontWeight.w500,fontSize:13
                  ),),
                  SizedBox(width: 5.aw,),
                  Container(
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: Color(0xFF32CD30),width:3
                        )
                    ),
                    height: 48.ah,width: 48.aw,
                    child: Icon(Icons.add,color: Color(0xFF32CD30)),
                  )
                ],
              ),
            ),
          ),
        )
    );
  }
}
