
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:flutter_svg/svg.dart';
import 'package:hexcolor/hexcolor.dart';

import 'package:securepoint/screen/size.dart';

import 'homescreen.dart';
import 'message_Screen.dart';
import 'my_assets.dart';


class Demo_deshboardPage extends StatefulWidget {
  @override
  _Demo_deshboardPageState createState() => _Demo_deshboardPageState();
}

class _Demo_deshboardPageState extends State<Demo_deshboardPage> {
  // int _selectedIndex = 0;

  // PageController controller = PageController();
  int _selectedIndex = 0;

  static  List<Widget> _widgetOptions = [

    My_Home(),

    Main_Assets(),

    Messages_Screen()

  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  Widget build(BuildContext context) {

    final colorScheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        iconSize:25,
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex,
        backgroundColor: Colors.white,
        selectedItemColor:Color(0XFF333333),
        unselectedItemColor: Colors.black.withOpacity(.60),
        selectedLabelStyle: textTheme.caption,
        unselectedLabelStyle: textTheme.caption,
        onTap: _onItemTapped,
        elevation: 20,
        items: [
          BottomNavigationBarItem(
              label: 'Home',
              icon: Padding(
                  padding: const EdgeInsets.only(top : 8.0,bottom: 4),
                  child:
                  Image.asset('assets/image/Union (3).png',
                    // color:_selectedIndex==0? HexColor('#333333'):Colors.black,
                    height:20.ah,width:20.aw,)

                // SvgPicture.asset('assets/icon/Union.svg',color:_selectedIndex==0? HexColor('#333333'):Colors.black))
              )),

          BottomNavigationBarItem(
              label: 'Assets',
              icon: Padding(
                  padding: const EdgeInsets.only(top : 8.0,bottom: 4),
                  child:
                  Image.asset('assets/image/Your Assets.png',
                    //color:_selectedIndex==1? HexColor('#333333'):Colors.black,
                    height:20.ah,width:20.aw,
                  )

                // SvgPicture.asset('assets/icon/Union.svg',color:_selectedIndex==0? HexColor('#333333'):Colors.black))
              )),

          BottomNavigationBarItem(
              label: 'Messages',
              icon: Padding(
                  padding: const EdgeInsets.only(top : 8.0,bottom: 4),
                  child:
                  Image.asset('assets/image/Subtract.png',
                    //color:_selectedIndex==2? HexColor('#333333'):Colors.black,
                    height:20.ah,width:20.aw,
                  )

                // SvgPicture.asset('assets/icon/Union.svg',color:_selectedIndex==0? HexColor('#333333'):Colors.black))
              )),

          /*BottomNavigationBarItem(
            label:'PRODUCT',
            icon: Padding(
                padding: const EdgeInsets.only(top : 8.0,bottom: 4),
                child:                   Image.asset('assets/image/Union (3).png',color:_selectedIndex==0? HexColor('#333333'):Colors.black,height:20.ah,width:20.aw,)

              //SvgPicture.asset('assets/icon/Your Assets.svg',color:_selectedIndex==1? HexColor('#756BFF'):Colors.black)),
            )),

          BottomNavigationBarItem(
            label:'COMMUNITY',
            icon: Padding(
                padding: const EdgeInsets.only(top : 8.0,bottom: 4),
                child: SvgPicture.asset('assets/icon/Subtract.svg',color:_selectedIndex==2? HexColor('#756BFF'):Colors.black)),
          ),*/


        ],
      ),

      body: Center(child: _widgetOptions.elementAt(_selectedIndex,),),
    );

    /* Scaffold(
      body: Center(child: _items[_selectedIndex]),

      bottomNavigationBar: Container(
        height: 61.ah,
        color: Colors.white,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[


            IconButton(
              icon: Icon(Icons.home,color: Color(0XFF333333),),
              onPressed: () => _onItemTapped(0),
            ),
            // This is necessary to create space in the center
            IconButton(
              icon:Image.asset('assets/image/Your Assets.png',height:17.ah,width:16.aw,),
              // Icon(Icons.notifications),
              onPressed: () => _onItemTapped(1),
            ),

            IconButton(
              icon:Container(
                height:43.ah,
                width: 43.aw,
                decoration: BoxDecoration(
                  //borderRadius: BorderRadius.all(Radius.zero),
                  color:Colors.white,
                  shape: BoxShape.circle,
                ),
                child:Center(child: Image.asset('assets/image/Subtract.png',height: 19.ah,width: 19.aw,)),
              ),
              // Image.asset('assets/image/plus.png'),
              onPressed: () => _onItemTapped(2),
            ),

            // Image.asset('assets/image/Vector.png',height: 21.ah,width: 21.aw,color: Colors.white,)
          ],
        ),
      ),

    );*/

  }
}
