
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/svg.dart';
import 'package:securepoint/screen/premium_screen.dart';
import 'package:securepoint/screen/save_assets.dart';
import 'package:securepoint/screen/signupscreen/signupscreen.dart';
import 'package:securepoint/screen/size.dart';
import 'about_screen.dart';
import 'add_assets.dart';
import 'confirm_delete_screen.dart';
import 'deshbord_screen.dart';
import 'faq_screen.dart';
import 'map_screen.dart';
import 'my_asset_details.dart';
import 'my_profile_screen.dart';
import 'no_data_search.dart';
import 'notification_preffrence.dart';

class NavigationScreen extends StatefulWidget {
  const NavigationScreen({super.key});

  @override
  State<NavigationScreen> createState() => _NavigationScreenState();
}

class _NavigationScreenState extends State<NavigationScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: InkWell(
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => Demo_deshboardPage()));
            },
            child: Icon(Icons.arrow_back_outlined,color: Color(0xFF6A6A6A))),
        backgroundColor: Colors.white,surfaceTintColor: Colors.white,shadowColor: Colors.black26,
        elevation: 3,
      ),

      body: Padding(
        padding:  EdgeInsets.only(left:15.h,right:15.h),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [

              SizedBox(height: 30.ah),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('E*******a',
                        style: TextStyle(
                            color: Color(0xFF6A6A6A),fontWeight: FontWeight.w500,fontSize:14
                        ),
                      ),

                      Text('SecurPoint user since February 2024',
                        style: TextStyle(
                            color: Colors.black,fontWeight: FontWeight.w500,fontSize:14
                        ),
                      ),
                    ],
                  ),

                  InkWell(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => MyProfile_Screen()));
                    },
                    child: Container(
                      height: 59.ah,
                      width: 59.aw,
                      decoration: BoxDecoration(
                        // borderRadius: BorderRadius.all(Radius.circular(35)),
                          color: Color(0x305B5B5B),
                          shape: BoxShape.circle,
                          image: DecorationImage(
                            fit: BoxFit.fill,
                            image: AssetImage('assets/image/75dc930fedff8c0a89c101576ace5fce.png'),
                          )),
                      // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                    ),
                  ),
                ],
              ),

              SizedBox(height: 20.ah),
              RichText(
                text: TextSpan(
                    text: 'Get SecurPoint',
                    style: TextStyle(
                      fontSize: 13.fSize,fontWeight: FontWeight.w500,color: Colors.black,
                    ),
                    children: [
                      TextSpan(
                        text: ' +',
                        style: TextStyle(
                          fontSize: 14.fSize,fontWeight: FontWeight.w500,color:Color(0xFF32CD30),
                        ),)]),),

              SizedBox(height: 20.ah),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                //mainAxisSize: MainAxisSize.min,
                children: [
                  //SizedBox(width: 20.aw),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SvgPicture.asset('assets/icon/Vector.svg'),
                      SizedBox(height: 10.ah),
                      Text('Lorem ipsum dolor sit\namet, consectetur',
                        style: TextStyle(
                            color: Colors.black,fontWeight: FontWeight.w400,fontSize:9
                        ),
                      ),
                    ],
                  ),

                  //SizedBox(width: 20.aw),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SvgPicture.asset('assets/icon/Vector (1).svg'),
                      SizedBox(height: 10.ah),
                      Text('Lorem ipsum dolor sit\namet, consectetur',
                        style: TextStyle(
                            color: Colors.black,fontWeight: FontWeight.w400,fontSize:9
                        ),
                      ),
                    ],
                  ),

                  //SizedBox(width:20.aw),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SvgPicture.asset('assets/icon/Star 1.svg'),
                      SizedBox(height: 10.ah),
                      Text('Lorem ipsum dolor sit\namet, consectetur',
                        style: TextStyle(
                            color: Colors.black,fontWeight: FontWeight.w400,fontSize:9
                        ),
                      ),
                    ],
                  ),


                ],
              ),

              SizedBox(height:30.ah),
              Container(
                width: MediaQuery.of(context).size.width,
                height: 94.ah,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: Color(0xFF32CD30),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text('Get your premium plan today!',
                        style: TextStyle(
                            color: Colors.white,fontWeight: FontWeight.w500,
                            fontSize:13
                        ),
                      ),

                      Text("It's optional for you.",
                        style: TextStyle(
                            color: Colors.white,fontWeight: FontWeight.w500,fontSize:10
                        ),
                      ),
                      SizedBox(height:5.ah),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            width:142.aw,height:34.ah,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(40),
                                color: Colors.white
                            ),
                            child:  Center(
                              child: Text('Access more for less',
                                style: TextStyle(fontFamily: 'Roboto',
                                    color: Color(0xFF32CD30),fontWeight: FontWeight.w400,fontSize:13.fSize
                                ),
                              ),
                            ),
                          ),

                          Align(
                            alignment: Alignment.bottomRight,
                            child: Text("SecurPoint*",
                              style: TextStyle(
                                  color: Colors.white,fontWeight: FontWeight.w400,fontSize:16
                              ),
                            ),
                          ),
                        ],
                      ),

                    ],
                  ),
                ),
              ),

              SizedBox(height:30.ah),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  SvgPicture.asset('assets/icon/Group 2247.svg',height: 18.ah,width: 18.aw,),
                  SizedBox(width: 20.aw),
                  InkWell(
                    onTap: () {
                     Navigator.push(context, MaterialPageRoute(builder: (context) => AddAssets_Screen()));
                    },
                    child: Text('Add Assets',
                      style: TextStyle( fontFamily: 'Roboto',
                          color: Colors.black,fontWeight: FontWeight.w400,fontSize:12.fSize
                      ),
                    ),
                  ),
                ],
              ),

              SizedBox(height:20.ah),
              InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => MYAsset_Details()));
                },
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SvgPicture.asset('assets/icon/Your Assets.svg',height: 18.ah,width: 18.aw,),
                    SizedBox(width: 20.aw),
                    InkWell(

                      child: Text('Your Assets',
                        style: TextStyle( fontFamily: 'Roboto',
                            color: Colors.black,fontWeight: FontWeight.w400,fontSize:12.fSize
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(height:20.ah),
              InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => SavedAssets()));

                },
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SvgPicture.asset('assets/icon/Group 2247 (1).svg',height: 18.ah,width: 18.aw,),
                    SizedBox(width: 20.aw),
                    InkWell(

                      child: Text('Saved Assets',
                        style: TextStyle( fontFamily: 'Roboto',
                            color: Colors.black,fontWeight: FontWeight.w400,fontSize:12.fSize
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(height:20.ah),
              Divider(
                height: 1,color: Color(0xffCECECE),thickness: 1,
              ),

              SizedBox(height:30.ah),
              InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => SearchNoData_screen()));
                },
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SvgPicture.asset('assets/icon/Group 2247 (2).svg',height: 18.ah,width: 18.aw,),
                    SizedBox(width: 20.aw),
                    InkWell(

                      child: Text('Account Settings',
                        style: TextStyle( fontFamily: 'Roboto',
                            color: Colors.black,fontWeight: FontWeight.w400,fontSize:12.fSize
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(height:20.ah),
              InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => PremiumScreen()));

                },
                child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  SvgPicture.asset('assets/icon/ic_security_24px (2).svg',height:18.ah,width:18.aw,fit: BoxFit.fill,),
                  SizedBox(width: 20.aw),
                  Text('Get SecurPoint+',
                      style: TextStyle( fontFamily: 'Roboto',
                          color: Colors.black,fontWeight: FontWeight.w400,fontSize:12.fSize
                      ),
                    ),
                ],
                )
              ),

              SizedBox(height:20.ah),
              InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => DeleteAccount_Screen()));
                },
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    //SvgPicture.asset('assets/icon/Group 2247 (1).svg',height: 18.ah,width: 18.aw,),
                    SvgPicture.asset('assets/icon/Group 2247 (3).svg',height:18.ah,width:18.aw,fit: BoxFit.fill,),
                    SizedBox(width: 20.aw),
                    InkWell(

                      child:Text('Delete Account',
                        style: TextStyle( fontFamily: 'Roboto',
                            color: Colors.black,fontWeight: FontWeight.w400,fontSize:12.fSize
                        ),
                      ),
                    )
                  ],
                ),
              ),

              SizedBox(height:20.ah),
              InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => Notification_Preference()));
                },
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    //SvgPicture.asset('assets/icon/Group 2247 (1).svg',height: 18.ah,width: 18.aw,),
                    SvgPicture.asset('assets/icon/Icon.svg',height:18.ah,width:18.aw,fit: BoxFit.fill,color: Colors.black,),
                    SizedBox(width: 20.aw),
                    InkWell(

                      child:Text('Notification Settings',
                        style: TextStyle( fontFamily: 'Roboto',
                            color: Colors.black,fontWeight: FontWeight.w400,fontSize:12.fSize
                        ),
                      ),
                    )
                  ],
                ),
              ),


              SizedBox(height:20.ah),
              Divider(
                height: 1,color: Color(0xffCECECE),thickness: 1,
              ),

              SizedBox(height:30.ah),

              Text('Support',
                style: TextStyle( fontFamily: 'Roboto',
                    color: Colors.black,fontWeight: FontWeight.w400,fontSize:12.fSize
                ),
              ),
              SizedBox(height:30.ah),
              InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => FAQ()));
                },
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SvgPicture.asset('assets/icon/ic_live_help_24px.svg',height: 18.ah,width: 18.aw,),
                    SizedBox(width: 20.aw),
                    InkWell(

                      child:Text('FAQs & Help Centre',
                        style: TextStyle( fontFamily: 'Roboto',
                            color: Colors.black,fontWeight: FontWeight.w400,fontSize:12.fSize
                        ),
                      ),
                    )
                  ],
                ),
              ),

              SizedBox(height:20.ah),

              InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => AboutScreen()));
                },
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SvgPicture.asset('assets/icon/ic_error_24px.svg',height: 18.ah,width: 18.aw,),
                    SizedBox(width: 20.aw),
                    InkWell(

                      child:Text('About this app',
                        style: TextStyle( fontFamily: 'Roboto',
                            color: Colors.black,fontWeight: FontWeight.w400,fontSize:12.fSize
                        ),
                      ),
                    )
                  ],
                ),
              ),

              SizedBox(height:20.ah),
              Divider(
                height: 1,color: Color(0xffCECECE),thickness: 1,
              ),

              SizedBox(height:20.ah),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.share),
                  SizedBox(width: 20.aw),
                  Text('Share SecurPoint with your friends',
                    style: TextStyle( fontFamily: 'Roboto',
                        color: Colors.black,fontWeight: FontWeight.w400,fontSize:12.fSize
                    ),
                  ),
                ],
              ),

              SizedBox(height:20.ah),
              InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => SignupScreen()));
                },
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SvgPicture.asset('assets/icon/logout (1).svg',height: 18.ah,width: 18.aw,),
                    SizedBox(width: 20.aw),
                    InkWell(

                      child: Text('Log out',
                        style: TextStyle( fontFamily: 'Roboto',
                            color: Colors.black,fontWeight: FontWeight.w400,fontSize:12.fSize
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(height: 50.ah),
            ],
          ),
        ),
      ),
    );
  }
}
