import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:securepoint/screen/size.dart';
import 'const_iteam/const_textfile.dart';
import 'const_iteam/custom_button.dart';
import 'map_screen.dart';
import 'notification_screen.dart';

class EditAssets extends StatefulWidget {
  const EditAssets({super.key});

  @override
  State<EditAssets> createState() => _EditAssetsState();
}

class _EditAssetsState extends State<EditAssets> {
  String selectedGender = '';
  final List<String> _options = ['Category 1', 'Category 2', 'Category 3'];
  final List<String> _options1 = ['Subcategory 1', 'Subcategory 2', 'Subcategory 3'];
  final List<String> _options2 = ['Status 1', 'Status 2', 'Status 3'];
  String? _selectedOption;
  String? _selectedOption1;
  String? _selectedOption2;

  int _selectedValue = 1;

  int _selectedValuetwo = 2;

  bool valuefirst = false;

  bool valuesecond = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(Icons.arrow_back_outlined,color: Color(0xFF6A6A6A))),
        title: Text('Edit Assets',
          style: TextStyle(fontFamily: 'Inter',
              color: Colors.black,fontWeight: FontWeight.w600,fontSize:20
          ),
        ),
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 25),
            child: InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => Notification_Screen()));
                },
                child: SvgPicture.asset('assets/icon/Icon.svg',height: 22.ah,width:22.aw,)),
          )
        ],
        backgroundColor: Colors.white,surfaceTintColor: Colors.white,shadowColor: Colors.black26,
        elevation: 3,
      ),

      body: Padding(
        padding:  EdgeInsets.only(left:15.h,right: 15.h),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [

              SizedBox(height: 30.ah),
              Center(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Image.asset('assets/image/Frame 427320892.png',
                      height: 113.ah,
                      width: 113.aw,
                      fit: BoxFit.fill,
                    ),
                    SizedBox(width: 20.aw),
                    DottedBorder(
                      borderType: BorderType.RRect,
                      radius: Radius.circular(6),
                      strokeWidth:1,
                      padding: EdgeInsets.all(6),
                      color: Color(0xff7F7F7F),
                      borderPadding: EdgeInsets.all(6),
                      child: ClipRRect(
                        borderRadius: BorderRadius.all(Radius.circular(6)),
                        child: Container(
                          height: 113.ah,
                          width: 113.aw,
                          child: Center(child: Icon(Icons.add)),
                        ),
                      ),
                    ),

                  ],

                ),
              ),
              SizedBox(height:10.ah),
              Text('Upload asset images. Max size: 1mb, 100px 100px.',
                style: TextStyle(fontFamily: 'Roboto',
                    color: HexColor('#5E605E'),fontWeight: FontWeight.w500,fontSize:10.fSize
                ),
              ),

              SizedBox(height: 30.ah),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('Asset Name',
                    style: TextStyle(fontFamily: 'Roboto',
                        color: Colors.black,fontWeight: FontWeight.w400,fontSize:12.fSize
                    ),
                  ),
                  SizedBox(width:32.aw),
                  Expanded(
                      child: primaryTextfield2(hintText: '', controller: null))
                ],
              ),


              SizedBox(height: 30.ah),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('Asset Details',
                    style: TextStyle(fontFamily: 'Roboto',
                        color: Colors.black,fontWeight: FontWeight.w400,fontSize:12.fSize
                    ),
                  ),
                  SizedBox(width:25.aw),
                  Expanded(
                      child: primaryTextfield3(hintText: 'Describe your asset here', controller: null))
                ],
              ),

              SizedBox(height: 30.ah),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('Asset Identifier',
                    style: TextStyle(fontFamily: 'Roboto',
                        color: Colors.black,fontWeight: FontWeight.w400,fontSize:12.fSize
                    ),
                  ),
                  SizedBox(width:15.aw),
                  Expanded(
                      child: primaryTextfield3(hintText: 'E.g. Asset Serial no. IMEI, VIN, etc.', controller: null))
                ],
              ),

              SizedBox(height: 30.ah),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('Category',
                    style: TextStyle(fontFamily: 'Roboto',
                        color: Colors.black,fontWeight: FontWeight.w400,fontSize:12.fSize
                    ),
                  ),
                  SizedBox(width:45.aw),
                  Expanded(
                    child: DropdownButtonFormField<String>(

                      value: _selectedOption,
                      items: _options.map((String option) {
                        return DropdownMenuItem<String>(
                          value: option,
                          child: Text(option),
                        );
                      }).toList(),
                      onChanged: (String? value) {
                        setState(() {
                          _selectedOption = value;
                        });
                      },
                      decoration: InputDecoration(
                        contentPadding: EdgeInsets.all(12),
                        // labelText: 'Select an option',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(11.h),
                          borderSide: BorderSide(
                            color: Color(0xFFB5B5B5),
                            width: 1,
                          ),
                        ),
                        errorStyle: TextStyle(color: Colors.red),
                        errorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(11.h),
                          borderSide: BorderSide(
                            color: Colors.red,
                            width: 1,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(11.h),
                          borderSide: BorderSide(
                            color: Colors.grey, width: 1,),),
                      ),
                    ),
                  ),
                ],
              ),

              SizedBox(height: 30.ah),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('Subcategory',
                    style: TextStyle(fontFamily: 'Roboto',
                        color: Colors.black,fontWeight: FontWeight.w400,fontSize:12.fSize
                    ),
                  ),
                  SizedBox(width:25.aw),
                  Expanded(
                    child: DropdownButtonFormField<String>(

                      value: _selectedOption1,
                      items: _options1.map((String option) {
                        return DropdownMenuItem<String>(
                          value: option,
                          child: Text(option),
                        );
                      }).toList(),
                      onChanged: (String? value) {
                        setState(() {
                          _selectedOption1 = value;
                        });
                      },
                      decoration: InputDecoration(
                        contentPadding: EdgeInsets.all(12),
                        // labelText: 'Select an option',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(11.h),
                          borderSide: BorderSide(
                            color: Color(0xFFB5B5B5),
                            width: 1,
                          ),
                        ),
                        errorStyle: TextStyle(color: Colors.red),
                        errorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(11.h),
                          borderSide: BorderSide(
                            color: Colors.red,
                            width: 1,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(11.h),
                          borderSide: BorderSide(
                            color: Colors.grey, width: 1,),),
                      ),
                    ),
                  ),
                ],
              ),

              SizedBox(height: 30.ah),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('Status',
                    style: TextStyle(fontFamily: 'Roboto',
                        color: Colors.black,fontWeight: FontWeight.w400,fontSize:12.fSize
                    ),
                  ),
                  SizedBox(width:55.aw),
                  /*Expanded(
                      child: primaryTextfield2(hintText: 'E.g. Asset Serial no. IMEI, VIN, etc.', controller: null))*/
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: _selectedOption2,
                      items: _options2.map((String option) {
                        return DropdownMenuItem<String>(
                          value: option,
                          child: Text(option),
                        );
                      }).toList(),
                      onChanged: (String? value) {
                        setState(() {
                          _selectedOption2 = value;
                        });
                      },
                      decoration: InputDecoration(
                        contentPadding: EdgeInsets.all(12),
                        // labelText: 'Select an option',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(11.h),
                          borderSide: BorderSide(
                            color: Color(0xFFB5B5B5),
                            width: 1,
                          ),
                        ),
                        errorStyle: TextStyle(color: Colors.red),
                        errorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(11.h),
                          borderSide: BorderSide(
                            color: Colors.red,
                            width: 1,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(11.h),
                          borderSide: BorderSide(
                            color: Colors.grey, width: 1,),),
                      ),
                    ),
                  ),
                ],
              ),


              SizedBox(height: 30.ah),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Radio(
                        activeColor: Color(0xFF32CD30),
                        value: 'Lock',

                        groupValue: selectedGender,
                        onChanged: (value) {
                          setState(() {
                            selectedGender = value.toString();
                          });
                        },
                      ),
                      Text('Lock',
                        style: TextStyle(fontFamily: 'Roboto',
                            color: Color(0xFF000000),fontWeight: FontWeight.w500,fontSize:12.fSize
                        ),
                      ),

                      SizedBox(width: 20.aw),
                      Radio(
                        value: 'Unlock',
                        activeColor: Color(0xFF32CD30),
                        groupValue: selectedGender,
                        onChanged: (value) {
                          setState(() {
                            selectedGender = value.toString();
                          });
                        },
                      ),
                      Text('Unlock',
                        style: TextStyle(fontFamily: 'Roboto',
                            color: Color(0xFF000000),fontWeight: FontWeight.w500,fontSize:12.fSize
                        ),
                      ),
                    ],
                  ),

                  SizedBox(width:65.ah),

                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Checkbox(
                        activeColor: Colors.green,
                        //checkColor: Colors.black,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(3.5),
                          side: BorderSide(
                            color:Color(0xFF32CD30),
                          ),
                        ),

                        value: valuesecond,
                        onChanged: ( value) {
                          setState(() {
                            this.valuesecond = value!;
                          });
                        },
                      ),
                      Text('Promote',
                        style: TextStyle(fontFamily: 'Roboto',
                            color: Color(0xFF000000),fontWeight: FontWeight.w500,fontSize:12.fSize
                        ),
                      ),
                    ],
                  ),

                ],

                // mainAxisSize: MainAxisSize.min,
                // children: [
                //   // Expanded(
                //   //   child: RadioListTile(
                //   //     contentPadding:EdgeInsets.only(right: 20) ,
                //   //     activeColor: Color(0xFF32CD30),
                //   //     title: Text('Lock',
                //   //       style: TextStyle(fontFamily: 'Roboto',
                //   //           color: Colors.black,fontWeight: FontWeight.w500,fontSize:12.fSize
                //   //       ),
                //   //     ), // Display the title for option 1
                //   //     value: 1, // Assign a value of 1 to this option
                //   //     groupValue:
                //   //   _selectedValue, // Use _selectedValue to track the selected option
                //   //     onChanged: (value) {
                //   //       setState(() {
                //   //         _selectedValue =
                //   //         value!; // Update _selectedValue when option 1 is selected
                //   //       });
                //   //     },
                //   //   ),
                //   // ),
                //
                //   // Expanded(
                //   //   child: RadioListTile(
                //   //     contentPadding:EdgeInsets.only(right: 20) ,
                //   //     activeColor: Color(0xFF32CD30),
                //   //     title: Text('Unlock',
                //   //       style: TextStyle(fontFamily: 'Roboto',
                //   //           color: Colors.black,fontWeight: FontWeight.w500,fontSize:12.fSize
                //   //       ),
                //   //     ), // Display the title for option 1
                //   //     value: 2, // Assign a value of 1 to this option
                //   //     groupValue:
                //   //     _selectedValue, // Use _selectedValue to track the selected option
                //   //     onChanged: (value) {
                //   //       setState(() {
                //   //         _selectedValue = value!; // Update _selectedValue when option 1 is selected
                //   //       });
                //   //     },
                //   //   ),
                //   // ),
                //
                //   Container(
                //     height: 52.ah,width:105.aw,
                //     decoration: BoxDecoration(
                //       color: Color(0xFFD5FFD4),
                //       borderRadius: BorderRadius.circular(6)
                //     ),
                //     child: Center(
                //       child: CheckboxListTile(
                //         contentPadding:EdgeInsets.only(right: 5.h,) ,
                //         controlAffinity: ListTileControlAffinity.leading,
                //         activeColor: Color(0xFF32CD30),
                //         title: Text('Promote',
                //           style: TextStyle(fontFamily: 'Roboto',
                //               color: Colors.black,fontWeight: FontWeight.w500,fontSize:12.fSize
                //           ),
                //         ),
                //         value: this.valuesecond,
                //         onChanged: (bool ?value) {
                //           setState(() {
                //             this.valuesecond = value!;
                //           });
                //         },
                //       ),
                //     ),
                //   ),
                //
                //
                // ],
              ),

              SizedBox(height: 20.ah),
              valuesecond==true ?   Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                // mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    height: 52.ah,width:350.aw,
                    decoration: BoxDecoration(
                        color: Color(0xFFD5FFD4),
                        borderRadius: BorderRadius.circular(6)
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [

                        Radio(
                          activeColor: Color(0xFF32CD30),
                          value: '1 Weeks',
                          groupValue: selectedGender,
                          onChanged: (value) {
                            setState(() {
                              selectedGender = value.toString();
                            });
                          },
                        ),
                        Text('1 Weeks',
                          style: TextStyle(fontFamily: 'Roboto',
                              color: Colors.black,fontWeight: FontWeight.w500,fontSize:12.fSize
                          ),
                        ),


                        Radio(
                          value: '2 Weeks',
                          activeColor: Color(0xFF32CD30),
                          groupValue: selectedGender,
                          onChanged: (value) {
                            setState(() {
                              selectedGender = value.toString();
                            });
                          },
                        ),
                        Text('2 Weeks',
                          style: TextStyle(fontFamily: 'Roboto',
                              color: Colors.black,fontWeight: FontWeight.w500,fontSize:12.fSize
                          ),
                        ),

                        Radio(
                          activeColor: Color(0xFF32CD30),
                          value: '3 Weeks',
                          groupValue: selectedGender,
                          onChanged: (value) {
                            setState(() {
                              selectedGender = value.toString();
                            });
                          },
                        ),
                        Text('3 Weeks',
                          style: TextStyle(fontFamily: 'Roboto',
                              color: Colors.black,fontWeight: FontWeight.w500,fontSize:12.fSize
                          ),
                        ),


                      ],
                    ),
                  ),

                ],
              ) : Container() ,




              SizedBox(height: 20.ah),
              Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  InkWell(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => MapScreen()));

                      },
                      child: Icon(Icons.location_on,size: 35,color: Color(0xFF32CD30))),

                  Text('Tap here to add map view',
                    style: TextStyle(fontFamily: 'Roboto',
                        color: Color(0xFF6C6C6C),fontWeight: FontWeight.w400,fontSize:11.fSize
                    ),
                  ),
                ],
              ),

              SizedBox(height: 30.ah),
              Center(
                child: CustomPrimaryBtn1(
                  title: 'Pay & Update',
                  isLoading: false, onTap: () {

                },),
              ),
              SizedBox(height: 30.ah)
            ],
          ),
        ),
      ),
    );
  }
}
