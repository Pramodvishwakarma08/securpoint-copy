import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:securepoint/screen/size.dart';

import 'add_assets.dart';
import 'edit_assets.dart';
import 'my_asset_details.dart';


class Main_Assets extends StatefulWidget {
  const Main_Assets({super.key});

  @override
  State<Main_Assets> createState() => _Main_AssetsState();
}

class _Main_AssetsState extends State<Main_Assets> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          //leading: Icon(Icons.arrow_back_outlined,color: Color(0xFF6A6A6A)),
          title: Text('My Assets',
            style: TextStyle(fontFamily: 'Inter',
                color: Colors.black,fontWeight: FontWeight.w600,fontSize:20
            ),
          ),
          centerTitle: true,

          backgroundColor: Colors.white,surfaceTintColor: Colors.white,shadowColor: Colors.black26,
          elevation: 3,
        ),

        body: SingleChildScrollView(
          child: Padding(
            padding:  EdgeInsets.only(left: 20.h,right: 20.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                SizedBox(height: 20.ah),


                /*Card(
                color: Colors.white70,
                shadowColor: Colors.black,
                surfaceTintColor: Colors.white70,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(43),
                    side: BorderSide(
                        color: Colors.black12,width: 1
                    )
                ),
                elevation: 10,
                child: Container(
                  // width: 293,
                  width: MediaQuery.of(context).size.width,
                  height:45,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Colors.white70,
                    borderRadius: BorderRadius.circular(43),

                  ),
                  child: TextField(
                    cursorColor: Color(0xFF000000),
                    style: TextStyle(color: Colors.black),
                    decoration: InputDecoration(
                        prefixIcon: //Image.asset('assets/images/seearch.png',),
                        Icon(Icons.search, color: Colors.grey,),
                        hintText:"Search Assets",
                        hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),
                        border: InputBorder.none),

                  ),
                ),
              ),*/

                /*TextField(
                cursorColor: Color(0xFF000000),
                style: TextStyle(color: Colors.black),
                decoration: InputDecoration(
                  isDense: true,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(43.h),
                    borderSide: BorderSide(
                      color: Color(0xFFB5B5B5),
                      width: 1,
                    ),
                  ),
                  errorStyle: TextStyle(color: Colors.red),
                  errorBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(43.h),
                    borderSide: BorderSide(
                      color: Colors.red,
                      width: 1,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(43.h),
                    borderSide: BorderSide(
                      color: Color(0xFF32CD30), width: 1,),),
                  prefixIcon: //Image.asset('assets/images/seearch.png',),
                  InkWell(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => SearcScreen()));
                      },
                      child: Icon(Icons.search, color: Colors.grey,size:30)),
                  hintText:"Search Assets",
                  hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),

                ),

              ),*/

                Card(
                  color: Colors.white70,
                  shadowColor: Colors.black,
                  surfaceTintColor: Colors.white70,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(43),
                      side: BorderSide(
                          color: Colors.black12,width: 1
                      )
                  ),
                  elevation: 10,
                  child: Container(
                    // width: 293,
                    width: MediaQuery.of(context).size.width,
                    height:52,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: Colors.white70,
                      borderRadius: BorderRadius.circular(43),

                    ),
                    child: TextField(
                      cursorColor: Color(0xFF000000),
                      style: TextStyle(color: Colors.black),
                      decoration: InputDecoration(
                          prefixIcon: //Image.asset('assets/images/seearch.png',),
                          Icon(Icons.search, color: Colors.grey,),
                          hintText:"Search Assets",
                          hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),
                          border: InputBorder.none),

                    ),
                  ),
                ),


                SizedBox(height: 20.ah),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      // mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('156 items',
                          style: TextStyle(
                            decoration: TextDecoration.underline,
                              color: HexColor('#AAAAAA'),fontWeight: FontWeight.w500,fontSize:14
                          ),
                        ),

                        // InkWell(
                        //   onTap: () {
                        //   //  Navigator.push(context, MaterialPageRoute(builder: (context) => AssetsScreen()));
                        //
                        //   },
                        //   child: Text('View less',
                        //     style: TextStyle(
                        //         color: HexColor('#AAAAAA'),fontWeight: FontWeight.w400,fontSize:13.fSize
                        //     ),
                        //   ),
                        // ),
                      ],
                    ),

                    SizedBox(height: 10.ah),

                    Row(
                      // mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Card(
                            color: Colors.white,
                            surfaceTintColor: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(),
                            child: Container(
                              color: Colors.white,
                              height: 248.ah,width: 156.aw,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [

                                  InkWell(
                                    onTap: () {
                                      //Navigator.push(context, MaterialPageRoute(builder: (context) => Myy_Assets_Details()));
                                      Navigator.push(context, MaterialPageRoute(builder: (context) => MYAsset_Details()));
                                    },
                                    child:  Image.asset('assets/image/image_2024_03_19T08_10_31_939Z.png',height: 113.ah,
                                      width: MediaQuery.of(context).size.width,
                                      fit: BoxFit.fill,
                                    ),
                                  ),


                                  SizedBox(height: 10.ah),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                      SizedBox(width: 10.aw),
                                      Text('iPhone 15',
                                        style: TextStyle(fontFamily: 'Roboto',
                                            color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                        ),
                                      ),
                                    ],
                                  ),

                                  Text('UIC: 6568520',
                                    style: TextStyle(fontFamily: 'Roboto',
                                        color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                    ),
                                  ),

                                  Text('This property is not available\nfor sale. Kindly...',
                                    style: TextStyle(fontFamily: 'Roboto',
                                        color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                    ),
                                  ),

                                  SizedBox(height:10.ah),
                                  Row(
                                    mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Icon(Icons.lock,color: HexColor('#5E605E'),),
                                      SizedBox(width: 5),
                                      Icon(Icons.remove_red_eye,color: HexColor('#5E605E'),),
                                      SizedBox(width: 5),
                                      InkWell(
                                          onTap: () {
                                            Navigator.push(context, MaterialPageRoute(builder: (context) => EditAssets()));
                                          },
                                          child:Icon(Icons.edit,color: HexColor('#5E605E'),)),
                                      SizedBox(width: 5),
                                      Icon(Icons.delete,color: HexColor('#5E605E'),),
                                    ],
                                  ),

                                ],
                              ),

                            )

                        ),

                        Card(
                            color: Colors.white,
                            surfaceTintColor: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(),
                            child: Container(
                              color: Colors.white,
                              height: 248.ah,width: 156.aw,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [

                                  Image.asset('assets/image/unlock.png',height: 113.ah,
                                    width: MediaQuery.of(context).size.width,
                                    fit: BoxFit.fill,
                                  ),

                                  SizedBox(height: 10.ah),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                      SizedBox(width: 10.aw),
                                      Text('iPhone 15',
                                        style: TextStyle(fontFamily: 'Roboto',
                                            color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                        ),
                                      ),
                                    ],
                                  ),

                                  Text('UIC: 6568520',
                                    style: TextStyle(fontFamily: 'Roboto',
                                        color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                    ),
                                  ),

                                  Text('This property is not available\nfor sale. Kindly...',
                                    style: TextStyle(fontFamily: 'Roboto',
                                        color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                    ),
                                  ),

                                  SizedBox(height:10.ah),
                                  Row(
                                    mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Icon(Icons.lock,color: HexColor('#5E605E'),),
                                      SizedBox(width: 5),
                                      Icon(Icons.remove_red_eye,color: HexColor('#5E605E'),),
                                      SizedBox(width: 5),
                                      InkWell(
                                          onTap: () {
                                            Navigator.push(context, MaterialPageRoute(builder: (context) => EditAssets()));
                                          },
                                          child: Icon(Icons.edit,color: HexColor('#5E605E'),)),
                                      SizedBox(width: 5),
                                      Icon(Icons.delete,color: HexColor('#5E605E'),),
                                    ],
                                  ),

                                ],
                              ),

                            )

                        )
                      ],
                    ),

                    Row(
                      // mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Card(
                            color: Colors.white,
                            surfaceTintColor: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(),
                            child: Container(
                              color: Colors.white,
                              height: 248.ah,width: 156.aw,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [

                                  Image.asset('assets/image/unlock.png',height: 113.ah,
                                    width: MediaQuery.of(context).size.width,
                                    fit: BoxFit.fill,
                                  ),

                                  SizedBox(height: 10.ah),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                      SizedBox(width: 10.aw),
                                      Text('iPhone 15',
                                        style: TextStyle(fontFamily: 'Roboto',
                                            color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                        ),
                                      ),
                                    ],
                                  ),

                                  Text('UIC: 6568520',
                                    style: TextStyle(fontFamily: 'Roboto',
                                        color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                    ),
                                  ),

                                  Text('This property is not available\nfor sale. Kindly...',
                                    style: TextStyle(fontFamily: 'Roboto',
                                        color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                    ),
                                  ),

                                  SizedBox(height:10.ah),
                                  Row(
                                    mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Icon(Icons.lock,color: HexColor('#5E605E'),),
                                      SizedBox(width: 5),
                                      Icon(Icons.remove_red_eye,color: HexColor('#5E605E'),),
                                      SizedBox(width: 5),
                                      InkWell(
                                          onTap: () {
                                            Navigator.push(context, MaterialPageRoute(builder: (context) => EditAssets()));
                                          },
                                          child:Icon(Icons.edit,color: HexColor('#5E605E'),)),
                                      SizedBox(width: 5),
                                      Icon(Icons.delete,color: HexColor('#5E605E'),),
                                    ],
                                  ),

                                ],
                              ),

                            )

                        ),

                        Card(
                            color: Colors.white,
                            surfaceTintColor: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(),
                            child: Container(
                              color: Colors.white,
                              height: 248.ah,width: 156.aw,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [

                                  Image.asset('assets/image/unlock.png',height: 113.ah,
                                    width: MediaQuery.of(context).size.width,
                                    fit: BoxFit.fill,
                                  ),

                                  SizedBox(height: 10.ah),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                      SizedBox(width: 10.aw),
                                      Text('iPhone 15',
                                        style: TextStyle(fontFamily: 'Roboto',
                                            color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                        ),
                                      ),
                                    ],
                                  ),

                                  Text('UIC: 6568520',
                                    style: TextStyle(fontFamily: 'Roboto',
                                        color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                    ),
                                  ),

                                  Text('This property is not available\nfor sale. Kindly...',
                                    style: TextStyle(fontFamily: 'Roboto',
                                        color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                    ),
                                  ),

                                  SizedBox(height:10.ah),
                                  Row(
                                    mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Icon(Icons.lock,color: HexColor('#5E605E'),),
                                      SizedBox(width: 5),
                                      Icon(Icons.remove_red_eye,color: HexColor('#5E605E'),),
                                      SizedBox(width: 5),
                                      InkWell(
                                          onTap: () {
                                            Navigator.push(context, MaterialPageRoute(builder: (context) => EditAssets()));
                                          },
                                          child:Icon(Icons.edit,color: HexColor('#5E605E'),)),
                                      SizedBox(width: 5),
                                      Icon(Icons.delete,color: HexColor('#5E605E'),),
                                    ],
                                  ),

                                ],
                              ),

                            )

                        )
                      ],
                    ),

                    Row(
                      // mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Card(
                            color: Colors.white,
                            surfaceTintColor: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(),
                            child: Container(
                              color: Colors.white,
                              height: 248.ah,width: 156.aw,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [

                                  Image.asset('assets/image/unlock.png',height: 113.ah,
                                    width: MediaQuery.of(context).size.width,
                                    fit: BoxFit.fill,
                                  ),

                                  SizedBox(height: 10.ah),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                      SizedBox(width: 10.aw),
                                      Text('iPhone 15',
                                        style: TextStyle(fontFamily: 'Roboto',
                                            color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                        ),
                                      ),
                                    ],
                                  ),

                                  Text('UIC: 6568520',
                                    style: TextStyle(fontFamily: 'Roboto',
                                        color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                    ),
                                  ),

                                  Text('This property is not available\nfor sale. Kindly...',
                                    style: TextStyle(fontFamily: 'Roboto',
                                        color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                    ),
                                  ),

                                  SizedBox(height:10.ah),
                                  Row(
                                    mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Icon(Icons.lock,color: HexColor('#5E605E'),),
                                      SizedBox(width: 5),
                                      Icon(Icons.remove_red_eye,color: HexColor('#5E605E'),),
                                      SizedBox(width: 5),
                                      InkWell(
                                          onTap: () {
                                            Navigator.push(context, MaterialPageRoute(builder: (context) => EditAssets()));
                                          },
                                          child:Icon(Icons.edit,color: HexColor('#5E605E'),)),
                                      SizedBox(width: 5),
                                      Icon(Icons.delete,color: HexColor('#5E605E'),),
                                    ],
                                  ),

                                ],
                              ),

                            )

                        ),

                        Card(
                            color: Colors.white,
                            surfaceTintColor: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(),
                            child: Container(
                              color: Colors.white,
                              height: 248.ah,width: 156.aw,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [

                                  Image.asset('assets/image/unlock.png',height: 113.ah,
                                    width: MediaQuery.of(context).size.width,
                                    fit: BoxFit.fill,
                                  ),

                                  SizedBox(height: 10.ah),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                      SizedBox(width: 10.aw),
                                      Text('iPhone 15',
                                        style: TextStyle(fontFamily: 'Roboto',
                                            color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                        ),
                                      ),
                                    ],
                                  ),

                                  Text('UIC: 6568520',
                                    style: TextStyle(fontFamily: 'Roboto',
                                        color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                    ),
                                  ),

                                  Text('This property is not available\nfor sale. Kindly...',
                                    style: TextStyle(fontFamily: 'Roboto',
                                        color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                    ),
                                  ),

                                  SizedBox(height:10.ah),
                                  Row(
                                    mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Icon(Icons.lock,color: HexColor('#5E605E'),),
                                      SizedBox(width: 5),
                                      Icon(Icons.remove_red_eye,color: HexColor('#5E605E'),),
                                      SizedBox(width: 5),
                                      InkWell(
                                          onTap: () {
                                            Navigator.push(context, MaterialPageRoute(builder: (context) => EditAssets()));
                                          },
                                          child:Icon(Icons.edit,color: HexColor('#5E605E'),)),
                                      SizedBox(width: 5),
                                      Icon(Icons.delete,color: HexColor('#5E605E'),),
                                    ],
                                  ),
                                ],
                              ),
                            )
                        )
                      ],
                    ),

                  ],
                ),
              ],
            ),
          ),
        ),
        floatingActionButton: InkWell(
          onTap: () {
            // Get.to(AddAssets_Screen());
            Navigator.push(context, MaterialPageRoute(builder: (context) => AddAssets_Screen()));

          },
          child: Card(
            surfaceTintColor: Colors.black,
            color: Colors.white,
            shadowColor: Colors.black,
            shape:RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(40),
            ) ,
            elevation: 5,
            child: Container(
              height: 58.ah,width:134.aw,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(40)
              ),
              child: Row(
                // mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text('Add assets', style: TextStyle(
                      color: Color(0xff6A6A6A),fontWeight: FontWeight.w500,fontSize:13
                  ),),
                  SizedBox(width: 5.aw,),
                  Container(
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: Color(0xFF32CD30),width:3
                        )
                    ),
                    height: 48.ah,width: 48.aw,
                    child: Icon(Icons.add,color: Color(0xFF32CD30)),
                  )
                ],
              ),
            ),
          ),
        )
    );
  }
}
