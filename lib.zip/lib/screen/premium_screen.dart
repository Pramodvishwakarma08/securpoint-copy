import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:securepoint/screen/size.dart';

import 'const_iteam/custom_button.dart';

class PremiumScreen extends StatefulWidget {
  const PremiumScreen({super.key});

  @override
  State<PremiumScreen> createState() => _PremiumScreenState();
}

class _PremiumScreenState extends State<PremiumScreen> {

  final List<String> _options = ['Option 1', 'Option 2', 'Option 3'];
  String? _selectedOption;

  int _selectedValue = 1;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(Icons.arrow_back_outlined,color: Color(0xFF6A6A6A))),
        title: Text('Premium',
          style: TextStyle(fontFamily: 'Inter',
              color: Color(0xFF6A6A6A),fontWeight: FontWeight.w600,fontSize:20
          ),
        ),
        centerTitle: true,

        backgroundColor: Colors.white,surfaceTintColor: Colors.white,shadowColor: Colors.black26,
        elevation: 3,
      ),
      body: Padding(
        padding:  EdgeInsets.only(left: 20.h,right: 20.h),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          //mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(height:20.ah),
            Center(child: SvgPicture.asset('assets/icon/ic_security_24px.svg',height: 78.ah,width:58.aw,)),
            Center(
               child: RichText(
                 text: TextSpan(
                     text: 'Secur',
                     style:TextStyle(fontFamily: 'Times New Roman',
                       fontSize:30.fSize,fontWeight: FontWeight.w400,color: Color(0xFF2B2C2B),
                     ),
                     children: [
                       TextSpan(
                         text: 'Point+',
                         style: TextStyle(fontFamily: 'Times New Roman',
                           fontSize: 30.fSize,fontWeight: FontWeight.w400,color:Color(0xFF525452),
                         ),)]),),
               //Text('SecurPoint +',
              //   style: TextStyle(fontFamily: 'Times New Roman',
              //       color: Colors.black,fontWeight: FontWeight.w400,fontSize:30
              //   ),
              // ),
            ),

            SizedBox(height:50.ah),
            Center(
              child: Container(
                width: 327.aw,height: 276.ah,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(13),
                    border: Border.all(
                        color: Colors.black,width: 0.5
                    )
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(height: 20.ah,),
                    Text('Benefits',
                      style: TextStyle(
                          color: Colors.green,fontWeight: FontWeight.w600,fontSize: 14.fSize
                      ),
                    ),

                    SizedBox(height: 20.ah,),

                    /* Row(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Column(
                          children: [
                            Container(
                              height: 46.ah,width: 46.aw,
                              decoration: BoxDecoration(
                                  color: Colors.green,
                                  shape: BoxShape.circle
                              ),
                              child: Icon(Icons.edit,color: Colors.white,),
                            ),
                            Text('In-app mess/\ncontact owner',
                              style: TextStyle(
                                  color: Colors.black,fontWeight: FontWeight.w400,fontSize: 12.fSize
                              ),
                            ),
                          ],
                        ),
                        //SizedBox(width: 50.aw),
                       Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(width:45.aw),
                            Container(
                              height: 46.ah,width: 46.aw,
                              decoration: BoxDecoration(
                                  color: Colors.green,
                                  shape: BoxShape.circle
                              ),
                              child: Center(child: SvgPicture.asset('assets/icon/Report asset.svg',height:24.ah,width: 24.aw,)),

                            ),
                            Text('Report\nassets',
                              style: TextStyle(
                                  color: Colors.black,fontWeight: FontWeight.w400,fontSize: 12.fSize
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),*/

                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Column(
                              children: [
                                Container(
                                  height: 46.ah,width: 46.aw,
                                  decoration: BoxDecoration(
                                      color: Colors.green,
                                      shape: BoxShape.circle
                                  ),
                                  child:Center(child: SvgPicture.asset('assets/icon/Vector (3).svg',height:17.ah,width: 17.aw,fit: BoxFit.fill,)),
                                ),
                                Text('In-app mess/\ncontact owner',
                                  style: TextStyle(
                                      color: Colors.black,fontWeight: FontWeight.w400,fontSize: 12.fSize
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 20.ah),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(width:45.aw),
                                Container(
                                  height: 46.ah,width: 46.aw,
                                  decoration: BoxDecoration(
                                      color: Colors.green,
                                      shape: BoxShape.circle
                                  ),
                                  child: Center(
                                      child:
                                      SvgPicture.asset('assets/icon/Report asset.svg',height:24.ah,width: 24.aw,)
                                  ),

                                ),
                                Text('Report\nassets',
                                  style: TextStyle(
                                      color: Colors.black,fontWeight: FontWeight.w400,fontSize: 12.fSize
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),

                        Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Column(
                              children: [
                                Container(
                                  height: 46.ah,width: 46.aw,
                                  decoration: BoxDecoration(
                                      color: Colors.green,
                                      shape: BoxShape.circle
                                  ),
                                  child:Center(child: SvgPicture.asset('assets/icon/Vector (4).svg',height:17.ah,width: 17.aw,fit: BoxFit.fill,)),
                                ),
                                Text('Initiate chats/\n    contacts',
                                  style: TextStyle(
                                      color: Colors.black,fontWeight: FontWeight.w400,fontSize: 12.fSize
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 20.ah),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(width:45.aw),
                                Container(
                                  height: 46.ah,width: 46.aw,
                                  decoration: BoxDecoration(
                                      color: Colors.green,
                                      shape: BoxShape.circle
                                  ),
                                  child:Center(child: SvgPicture.asset('assets/icon/Unlimited assets listings.svg',height:24.ah,width:24.aw,fit: BoxFit.fill,)),
                                ),

                                Text('Unlimited assets\n      listings',
                                  style: TextStyle(
                                      color: Colors.black,fontWeight: FontWeight.w400,fontSize: 12.fSize
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),




                    SizedBox(height: 20.ah,),
                    /* Row(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(width:45.aw),
                            Container(
                              height: 46.ah,width: 46.aw,
                              decoration: BoxDecoration(
                                  color: Colors.green,
                                  shape: BoxShape.circle
                              ),
                              child: Center(child: SvgPicture.asset('assets/icon/Report asset.svg',height:24.ah,width: 24.aw,)),

                            ),
                            Text('Report\nassets',
                              style: TextStyle(
                                  color: Colors.black,fontWeight: FontWeight.w400,fontSize: 12.fSize
                              ),
                            ),
                          ],
                        ),

                        SizedBox(width:60.aw),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              height: 46.ah,width: 46.aw,
                              decoration: BoxDecoration(
                                  color: Colors.green,
                                  shape: BoxShape.circle
                              ),
                              child: Center(child: SvgPicture.asset('assets/icon/ic_playlist_add_24px.svg',height:14.ah,width: 14.aw,)),

                            ),
                            Text('Unlimited assets \n     listings',
                              style: TextStyle(
                                  color: Colors.black,fontWeight: FontWeight.w400,fontSize: 12.fSize
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),*/

                  ],
                ),
              ),
            ),

            SizedBox(height:20.ah),
            Text('Choose subscription plan for',
              style: TextStyle(fontFamily: 'Roboto',
                color: Colors.black,fontWeight: FontWeight.w500,fontSize:13,
              ),
            ),

            SizedBox(height:20.ah),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [

                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _selectedOption,
                    items: _options.map((String option) {
                      return DropdownMenuItem<String>(
                        value: option,
                        child: Text(option),
                      );
                    }).toList(),
                    onChanged: (String? value) {
                      setState(() {
                        _selectedOption = value;
                      });
                    },
                    decoration: InputDecoration(
                      contentPadding: EdgeInsets.all(12),
                      // labelText: 'Select an option',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(11.h),
                        borderSide: BorderSide(
                          color: Color(0xFFB5B5B5),
                          width: 1,
                        ),
                      ),
                      errorStyle: TextStyle(color: Colors.red),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(11.h),
                        borderSide: BorderSide(
                          color: Colors.red,
                          width: 1,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(11.h),
                        borderSide: BorderSide(
                          color: Colors.grey, width: 1,),),
                    ),
                  ),
                ),
                SizedBox(width:47.aw),
                Text('\$19.99',
                  style: TextStyle(fontFamily: 'Roboto',
                      color: Colors.black,fontWeight: FontWeight.w700,fontSize:20.fSize
                  ),
                ),

              ],
            ),

            Spacer(),

            Center(
              child: CustomPrimaryBtn1(
                title: 'Pay',
                isLoading: false,
                onTap: () {
                  // Navigator.push(context, MaterialPageRoute(builder: (context) => SignUp_Screen()));
                },
              ),
            ),

            SizedBox(height:50.ah),
          ],
        ),
      ),
    );
  }
}
