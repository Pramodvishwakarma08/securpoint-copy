import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:securepoint/screen/size.dart';


class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 20),
            child: InkWell(
              /* onTap: () {
                  showModalBottomSheet(
                      context: context,
                      backgroundColor: Colors.white,
                      builder: (context) {
                        return Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            SizedBox(height: 15.ah),
                            ListTile(
                              leading: Image.asset('assets/image/Frame 21142 (2).png',height:38.ah,width:38.aw,fit: BoxFit.fill,),
                              title: Text('Clearchat',
                                style: TextStyle(
                                    color: Colors.black,fontWeight: FontWeight.w600,fontSize:16
                                ),),
                              onTap: () {
                                Navigator.pop(context);
                              },
                            ),

                            ListTile(
                              leading: Image.asset('assets/image/delete (1).png',height:38.ah,width:38.aw,fit: BoxFit.fill,),
                              title: Text('Deletecht',
                                style: TextStyle(
                                    color: Colors.black,fontWeight: FontWeight.w600,fontSize:16
                                ),),
                              onTap: () {
                                Navigator.pop(context);
                              },
                            ),

                            ListTile(
                              leading: Image.asset('assets/image/delete (1).png',height:38.ah,width:38.aw,fit: BoxFit.fill,),
                              title: Text('Block',
                                style: TextStyle(
                                    color: Colors.black,fontWeight: FontWeight.w600,fontSize:16
                                ),),
                              onTap: () {
                                Navigator.pop(context);
                              },
                            ),

                            ListTile(
                              leading: Image.asset('assets/image/share (1).png',height:38.ah,width:38.aw,fit: BoxFit.fill,),
                              title: Text('Share',
                                style: TextStyle(
                                    color: Colors.black,fontWeight: FontWeight.w600,fontSize:16
                                ),),
                              onTap: () {
                                //Navigator.push(context, MaterialPageRoute(builder: (context) => Share_Screen()));
                              },
                            ),
                          ],
                        );
                      }
                  );
                },*/
                child: Container(
                  width: 30.aw,
                  height: 20.ah,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      image: DecorationImage(
                          image: AssetImage('assets/image/Union (6).png'),
                          fit: BoxFit.contain
                      )
                  ),
                  // child: Image.asset('assets/image/more option.png',height: 16.ah,width: 15.aw,)
                )
            ),
          ),
        ],
        title: Row(
          children: [
            Container(
              height: 36.ah,
              width: 36.aw,
              decoration: BoxDecoration(
                // borderRadius: BorderRadius.all(Radius.circular(35)),
                  color: Color(0x305B5B5B),
                  shape: BoxShape.circle,
                  border: Border.all(
                      color: Colors.black,
                      width: 1.5
                  ),
                  image: DecorationImage(
                    fit: BoxFit.fill,
                    image: AssetImage('assets/image/Frame 21142 (2).png'),
                  )),
              // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
            ),
            SizedBox(width: 5.aw),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text('Ed***** ***itz ',
                  style: TextStyle(
                    color: Colors.black,fontWeight: FontWeight.w600,fontSize:14.fSize,
                  ),),
                Text('Online',
                  style: TextStyle(
                    color: Colors.black,fontWeight: FontWeight.w500,fontSize:12.fSize,
                  ),),
              ],
            ),

          ],
        ),
        leading: Padding(
          padding:  EdgeInsets.only(left: 20.h),
          child: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Icon(Icons.arrow_back_sharp)),
        ),
        backgroundColor: Colors.white,
        shadowColor: Colors.white,
        surfaceTintColor: Colors.white,

        elevation:3,
      ),

      body: Padding(
        padding: const EdgeInsets.only(left: 15,right: 15,top:35),
        child: Column(
          // crossAxisAlignment: CrossAxisAlignment.start,
          // mainAxisSize: MainAxisSize.min,
          // mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 296.aw, height: 50.ah,
                      decoration: BoxDecoration(
                          color: HexColor("#32CD30"),
                          borderRadius: BorderRadius.only(
                            bottomRight: Radius.circular(20),
                            topLeft: Radius.circular(20), topRight: Radius.circular(20),
                          )
                      ),
                      child: Center(
                        child: Text('I want to buy this phone ASAP.....',
                          style: TextStyle(
                              color: Colors.white,fontWeight: FontWeight.w400,fontSize:16.fSize
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 10.ah),
                    Text('4.30 AM',
                      style: TextStyle(
                          color: Colors.grey,fontWeight: FontWeight.w400,fontSize:12.fSize
                      ),
                    ),
                  ],
                ),
              ],
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  // mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      // alignment: Alignment.centerLeft,
                      width: 125.aw, height: 50.ah,
                      decoration: BoxDecoration(
                          color: HexColor("#EDEDED"),
                          borderRadius: BorderRadius.only(
                            bottomRight: Radius.circular(20),bottomLeft: Radius.circular(20),
                            topLeft: Radius.circular(20),
                          )
                      ),
                      child: Center(
                        child: Text('Okay Let \nMe know',
                          style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w400,fontSize:16.fSize
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 10.ah),
                    Text('4.30 AM',
                      style: TextStyle(
                          color: Colors.grey,fontWeight: FontWeight.w400,fontSize:12.fSize
                      ),
                    ),
                  ],
                ),
              ],
            ),

            SizedBox(height: 20.ah),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 296.aw, height: 50.ah,
                      decoration: BoxDecoration(
                          color: HexColor("#32CD30"),
                          borderRadius: BorderRadius.only(
                            bottomRight: Radius.circular(20),
                            topLeft: Radius.circular(20), topRight: Radius.circular(20),
                          )
                      ),
                      child: Center(
                        child: Text('its is phone has warranty and box',
                          style: TextStyle(
                              color: Colors.white,fontWeight: FontWeight.w400,fontSize:16.fSize
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 10.ah),
                    Text('4.30 AM',
                      style: TextStyle(
                          color: Colors.grey,fontWeight: FontWeight.w400,fontSize:12.fSize
                      ),
                    ),
                  ],
                ),
              ],
            ),

            SizedBox(height: 20.ah),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  // mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      // alignment: Alignment.centerLeft,
                      width: 125.aw, height: 50.ah,
                      decoration: BoxDecoration(
                          color: HexColor("#EDEDED"),
                          borderRadius: BorderRadius.only(
                            bottomRight: Radius.circular(20),bottomLeft: Radius.circular(20),
                            topLeft: Radius.circular(20),
                          )
                      ),
                      child: Center(
                        child: Text('No.. not have',
                          style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w400,fontSize:16.fSize
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 10.ah),
                    Text('4.30 AM',
                      style: TextStyle(
                          color: Colors.grey,fontWeight: FontWeight.w400,fontSize:12.fSize
                      ),
                    ),
                  ],
                ),
              ],
            ),

            SizedBox(height: 20.ah),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 296.aw, height: 50.ah,
                      decoration: BoxDecoration(
                          color: HexColor("#32CD30"),
                          borderRadius: BorderRadius.only(
                            bottomRight: Radius.circular(20),
                            topLeft: Radius.circular(20), topRight: Radius.circular(20),
                          )
                      ),
                      child: Center(
                        child: Text('Where we can meet to buy this...',
                          style: TextStyle(
                              color: Colors.white,fontWeight: FontWeight.w400,fontSize:16.fSize
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 10.ah),
                    Text('4.30 AM',
                      style: TextStyle(
                          color: Colors.grey,fontWeight: FontWeight.w400,fontSize:12.fSize
                      ),
                    ),
                  ],
                ),
              ],
            ),

            SizedBox(height: 20.ah),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  // mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      // alignment: Alignment.centerLeft,
                      width: 125.aw, height: 50.ah,
                      decoration: BoxDecoration(
                          color: HexColor("#EDEDED"),
                          borderRadius: BorderRadius.only(
                            bottomRight: Radius.circular(20),bottomLeft: Radius.circular(20),
                            topLeft: Radius.circular(20),
                          )
                      ),
                      child: Center(
                        child: Text('At railway \nStation',
                          style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w400,fontSize:16.fSize
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 10.ah),
                    Text('4.30 AM',
                      style: TextStyle(
                          color: Colors.grey,fontWeight: FontWeight.w400,fontSize:12.fSize
                      ),
                    ),


                  ],
                ),
              ],
            ),

            Spacer(),
            Padding(
              padding: const EdgeInsets.only(left: 5,right: 5,bottom: 20),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [

                  /* Container(
            height:45.ah,width:316.aw,
            decoration: BoxDecoration(
              border: Border.all(
                color: Colors.black,width: 1,
              ),
              borderRadius: BorderRadius.circular(39),
            ),
            child: Padding(
              padding: const EdgeInsets.all(5.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      SizedBox(width: 7.aw),
                      Image.asset('assets/image/Union (7).png',width: 21.aw,height: 21.ah,fit: BoxFit.contain,),
                      SizedBox(width: 10.aw),
                      Text('Message',
                        style: TextStyle(
                            color: Colors.grey,fontWeight: FontWeight.w500,fontSize:20.fSize
                        ),
                      ),],
                  ),

                ],
              ),
            ),
          ),*/

                  Expanded(
                    child: TextField(
                      cursorColor: Color(0xFF000000),
                      style: TextStyle(color: Colors.black),
                      decoration: InputDecoration(
                        contentPadding: EdgeInsets.all(10),
                        isDense: true,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(43.h),
                          borderSide: BorderSide(
                            color: Color(0xFFB5B5B5),
                            width: 1,
                          ),
                        ),
                        errorStyle: TextStyle(color: Colors.red),
                        errorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(43.h),
                          borderSide: BorderSide(
                            color: Colors.red,
                            width: 1,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(43.h),
                          borderSide: BorderSide(
                            color: Color(0xFF32CD30), width: 1,),),

                        prefixIcon: //Image.asset('assets/images/seearch.png',),
                        InkWell(
                            onTap: () {
                              // Navigator.push(context, MaterialPageRoute(builder: (context) => SearcScreen()));
                            },
                            child: Icon(Icons.emoji_emotions_outlined, color: Colors.grey,size:30)),

                        // SvgPicture.asset('assets/icon/smily.svg',fit: BoxFit.fill,),

                        // Image.asset('assets/image/Union (8).png',fit: BoxFit.contain,),

                        prefixStyle: TextStyle(

                        ),

                        hintText:"Message",
                        hintStyle: TextStyle(color:Colors.grey,fontSize:20.fSize,fontWeight: FontWeight.w500),

                      ),

                    ),
                  ),

                  SizedBox(width: 2.aw),
                  Image.asset('assets/image/Frame 1799.png',height: 42.ah,width: 42.aw,fit: BoxFit.contain,),


                ],
              ),
            ),
          ],
        ),
      ),

      //  bottomNavigationBar:
    );
  }
}
