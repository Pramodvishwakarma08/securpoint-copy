
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:securepoint/screen/size.dart';

import 'add_assets.dart';
import 'all_assets.dart';
import 'all_categories.dart';
import 'map_screen.dart';
import 'navigation_screen.dart';
import 'notification_screen.dart';


class My_Home extends StatefulWidget {
  const My_Home({super.key});

  @override
  State<My_Home> createState() => _My_HomeState();
}

class _My_HomeState extends State<My_Home> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {

      _counter++;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          surfaceTintColor: Colors.white,
          backgroundColor: Colors.white,
          leading: InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => NavigationScreen(),));
              },
              child: Icon(Icons.menu)),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 25),
              child: InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => Notification_Screen()));
                  },
                  child: SvgPicture.asset('assets/icon/Icon.svg',height: 22.ah,width:22.aw,)),
            )
          ],
        ),

        body: SingleChildScrollView(
          //physics: NeverScrollableScrollPhysics(),
          child: Padding(
            padding:  EdgeInsets.only(left: 15.h,right: 15.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                SizedBox(height: 20.ah),
                Center(child: SvgPicture.asset('assets/icon/ic_security_24px.svg',height: 35.ah,width:29.aw,)),
                SizedBox(height: 10.ah),
                Center(
                   child: RichText(
                     text: TextSpan(
                         text: 'Secur',
                         style:TextStyle(fontFamily: 'Times New Roman',
                           fontSize:18.fSize,fontWeight: FontWeight.w400,color: Color(0xFF2B2C2B),
                         ),
                         children: [
                           TextSpan(
                             text: 'Point',
                             style: TextStyle(fontFamily: 'Times New Roman',
                               fontSize: 18.fSize,fontWeight: FontWeight.w400,color:Color(0xFF525452),
                             ),)]),),
                  // Text('SecurPoint',
                  //   style: TextStyle(fontFamily: 'Times New Roman',
                  //       color: Colors.black.withOpacity(0.50),fontWeight: FontWeight.w600,fontSize:18
                  //   ),
                  // ),
                ),

                SizedBox(height: 30.ah),


                Center(
                  child: Card(
                    color: Colors.white70,
                    shadowColor: Colors.black,
                    surfaceTintColor: Colors.white70,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(43),
                        side: BorderSide(
                            color: Colors.black12,width: 1
                        )
                    ),
                    elevation: 10,
                    child: Container(
                      // width: 293,
                      width: MediaQuery.of(context).size.width,
                      height:52,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: Colors.white70,
                        borderRadius: BorderRadius.circular(43),

                      ),
                      child: TextField(
                        cursorColor: Color(0xFF000000),
                        style: TextStyle(color: Colors.black),
                        decoration: InputDecoration(
                            prefixIcon: //Image.asset('assets/images/seearch.png',),
                            Icon(Icons.search, color: Colors.grey,),
                            hintText:"Search Assets",
                            hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),
                            border: InputBorder.none),

                      ),
                    ),
                  ),
                ),

                /////////////////////////

                /* Padding(
                padding:  EdgeInsets.only(left: 2.aw,right: 2.aw),
                child: Expanded(
                  child: Card(
                    child: Container(
                      // width: 293,
                      width: MediaQuery.of(context).size.width,
                      height:45,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(color: Color(0xFFe9eaec),
                          borderRadius: BorderRadius.circular(43)),
                      child: TextField(

                        cursorColor: Color(0xFF000000),
                        style: TextStyle(color: Colors.black),
                        decoration: InputDecoration(

                            prefixIcon:
                            //Image.asset('assets/images/seearch.png',),
                            Icon(Icons.search, color: Colors.grey),
                            hintText: "Search Assets",
                            hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),
                            border: InputBorder.none),

                      ),
                    ),
                  ),
                ),
              ),*/


                /* TextField(
                cursorColor: Color(0xFF000000),
                style: TextStyle(color: Colors.black),
                decoration: InputDecoration(
                  isDense: true,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(43.h),
                    borderSide: BorderSide(
                      color: Color(0xFFB5B5B5),
                      width: 1,
                    ),
                  ),
                  errorStyle: TextStyle(color: Colors.red),
                  errorBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(43.h),
                    borderSide: BorderSide(
                      color: Colors.red,
                      width: 1,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(43.h),
                    borderSide: BorderSide(
                      color: Color(0xFF32CD30), width: 1,),),
                  prefixIcon: //Image.asset('assets/images/seearch.png',),
                  InkWell(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => SearcScreen()));
                      },
                      child: Icon(Icons.search, color: Colors.grey,size:30)),
                  hintText:"Search Assets",
                  hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),

                ),

              ),*/



                SizedBox(height: 20.ah),
                Row(
                  // mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('  Categories',
                      style: TextStyle(
                          color: Colors.black,fontWeight: FontWeight.w500,fontSize:14
                      ),
                    ),

                    InkWell(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => All_Categories()));
                      },
                      child: Container(
                        alignment: Alignment.topRight,
                        color: Colors.white,
                        height: 30.ah,width: 50.aw,
                        child: Text('View all',
                          style: TextStyle(
                              color: HexColor('#AAAAAA'),fontWeight: FontWeight.w400,fontSize:13.fSize,
                            decoration: TextDecoration.underline,decorationColor: Colors.black
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

                SizedBox(height: 10.ah),
                Categories(),


                SizedBox(height: 20.ah),
                Row(
                  // mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('  Featured Assets',
                      style: TextStyle(
                          color: Colors.black,fontWeight: FontWeight.w500,fontSize:14
                      ),
                    ),


                    InkWell(
                      onTap: () {
                        //Navigator.push(context, MaterialPageRoute(builder: (context) => Fillterd_assets()));
                        Navigator.push(context, MaterialPageRoute(builder: (context) => All_Assets_Screen()));
                      },
                      child: Container(
                        alignment: Alignment.topRight,
                        color: Colors.white,
                        height: 30.ah,width:63.aw,
                        child: Text('View More',
                          style: TextStyle(
                              color: HexColor('#AAAAAA'),fontWeight: FontWeight.w400,fontSize:13.fSize,
                              decoration: TextDecoration.underline,decorationColor: Colors.black
                          ),
                        ),
                      ),
                    ),
                  ],
                ),


                SizedBox(height: 10.ah),
                //FeaturedAssets(),

                Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    crossAxisAlignment: CrossAxisAlignment.center,
                   // mainAxisSize: MainAxisSize.min,
                    children: [
                      Card(
                          color: Colors.white,
                          surfaceTintColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(),
                          child: Container(
                            color: Colors.white,
                            height: 248.ah,width: 156.aw,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                Image.asset('assets/image/image_2024_03_19T09_15_46_504Z.png',height: 113.ah,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.fill,
                                ),

                                // Stack(
                                //   alignment: Alignment.topRight,
                                //   children: [
                                //     Container(
                                //       height: 113.ah,
                                //       width: 156.aw,
                                //       decoration: BoxDecoration(
                                //           color: Colors.white,
                                //           borderRadius: BorderRadius.circular(15),
                                //           image: DecorationImage(
                                //               fit: BoxFit.fill,
                                //               image: AssetImage('assets/image/image_2024_03_19T09_15_46_504Z.png')
                                //           )
                                //       ),
                                //     ),
                                //     // Positioned(
                                //     //   bottom: 80.2,
                                //     //   child:Align(
                                //     //   alignment: Alignment.topRight,
                                //     //   child: Container(
                                //     //     color: Colors.black,
                                //     //     height: 80.ah,
                                //     //     width: 80.aw,
                                //     //   ),
                                //     //   )
                                //     // ),
                                //
                                //     Positioned(
                                //       bottom: 75.2,right: 10,
                                //       child: Align(
                                //         alignment: Alignment.topRight,
                                //         child:Container(
                                //         //alignment: Alignment.topLeft,
                                //         height: 40.ah,
                                //         width: 40.aw,
                                //         decoration: BoxDecoration(
                                //             color: Colors.redAccent,
                                //             //borderRadius: BorderRadius.circular(15),
                                //             shape: BoxShape.circle
                                //             // image: DecorationImage(
                                //             //     fit: BoxFit.fill,
                                //             //     image: AssetImage('assets/image/Frame 1 (3).png')
                                //             // )
                                //         ),
                                //       ),
                                //       ),
                                //     )
                                //   ],
                                //
                                // ),

                                SizedBox(height: 10.ah),
                                Text('iPhone 15',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                  ),
                                ),

                                Text('UIC: 6568520',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                  ),
                                ),

                                Text('This property is not available\nfor sale. Kindly...',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                  ),
                                ),

                                SizedBox(height:10.ah),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      width: 96.aw,height: 27.ah,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(40),
                                        color: Color(0xFF32CD30),
                                      ),
                                      child:  Center(
                                        child: Text('View Asset',
                                          style: TextStyle(fontFamily: 'Roboto',
                                              color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                          ),
                                        ),
                                      ),
                                    ),

                                    InkWell(
                                        onTap: () {
                                          Navigator.push(context, MaterialPageRoute(builder: (context) => MapScreen()));
                                        },
                                        child: Icon(Icons.location_on,size: 25,))
                                  ],
                                ),


                              ],
                            ),

                          )

                      ),
                      //SizedBox(width: 20.aw),
                      Card(
                          color: Colors.white,
                          surfaceTintColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(),
                          child: Container(
                            color: Colors.white,
                            height: 248.ah,width: 156.aw,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                Image.asset('assets/image/image_2024_03_19T09_15_46_504Z.png',height: 113.ah,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.fill,
                                ),

                                /*Stack(
                                  children: [
                                    Container(
                                      height: 113.ah,
                                      width: 156.aw,
                                      decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.circular(15),
                                          image: DecorationImage(
                                              fit: BoxFit.fill,
                                              image: AssetImage('assets/image/Frame 1 (3).png')
                                          )
                                      ),
                                    ),
                                    Positioned(
                                      left: 130,bottom:80,
                                      child: Container(
                                        height: 40.ah,
                                        width: 40.aw,
                                        decoration: BoxDecoration(
                                            color: Colors.redAccent,
                                            //borderRadius: BorderRadius.circular(15),
                                            shape: BoxShape.circle
                                          // image: DecorationImage(
                                          //     fit: BoxFit.fill,
                                          //     image: AssetImage('assets/image/Frame 1 (3).png')
                                          // )
                                        ),
                                      ),
                                    ),
                                  ],

                                ),*/

                                SizedBox(height: 10.ah),
                                Text('iPhone 15',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                  ),
                                ),

                                Text('UIC: 6568520',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                  ),
                                ),

                                Text('This property is not available\nfor sale. Kindly...',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                  ),
                                ),

                                SizedBox(height:10.ah),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      width: 96.aw,height: 27.ah,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(40),
                                        color: Color(0xFF32CD30),
                                      ),
                                      child:  Center(
                                        child: Text('View Asset',
                                          style: TextStyle(fontFamily: 'Roboto',
                                              color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                          ),
                                        ),
                                      ),
                                    ),

                                    InkWell(
                                        onTap: () {
                                          Navigator.push(context, MaterialPageRoute(builder: (context) => MapScreen()));
                                        },
                                        child: Icon(Icons.location_on,size: 25,))
                                  ],
                                ),


                              ],
                            ),

                          )

                      ),
                    ],
                  ),
                ),

                Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    //mainAxisSize: MainAxisSize.min,
                    children: [
                      Card(
                          color: Colors.white,
                          surfaceTintColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(),
                          child: Container(
                            color: Colors.white,
                            height: 248.ah,width: 156.aw,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                Image.asset('assets/image/image_2024_03_19T09_15_46_504Z.png',height: 113.ah,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.fill,
                                ),

                                SizedBox(height: 10.ah),
                                Text('iPhone 15',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                  ),
                                ),

                                Text('UIC: 6568520',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                  ),
                                ),

                                Text('This property is not available\nfor sale. Kindly...',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                  ),
                                ),

                                SizedBox(height:10.ah),
                                Container(
                                  width: 96.aw,height: 27.ah,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(40),
                                    color: Color(0xFF32CD30),
                                  ),
                                  child:  Center(
                                    child: Text('View Asset',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                      ),
                                    ),
                                  ),
                                ),


                              ],
                            ),

                          )

                      ),

                      //SizedBox(width: 20.aw),
                      Card(
                          color: Colors.white,
                          surfaceTintColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(),
                          child: Container(
                            color: Colors.white,
                            height: 248.ah,width: 156.aw,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                Image.asset('assets/image/image_2024_03_19T09_15_46_504Z.png',height: 113.ah,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.fill,
                                ),

                                SizedBox(height: 10.ah),
                                Text('iPhone 15',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                  ),
                                ),

                                Text('UIC: 6568520',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                  ),
                                ),

                                Text('This property is not available\nfor sale. Kindly...',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                  ),
                                ),

                                SizedBox(height:10.ah),
                                Container(
                                  width: 96.aw,height: 27.ah,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(40),
                                    color: Color(0xFF32CD30),
                                  ),
                                  child:  Center(
                                    child: Text('View Asset',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                      ),
                                    ),
                                  ),
                                ),


                              ],
                            ),

                          )

                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        floatingActionButton: InkWell(
          onTap: () {
            //Get.to(AddAssets_Screen());
            Navigator.push(context, MaterialPageRoute(builder: (context) => AddAssets_Screen()));

          },
          child: Card(
            surfaceTintColor: Colors.black,
            color: Colors.white,
            shadowColor: Colors.black,
            shape:RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(40),
            ) ,
            elevation: 5,
            child: Container(
              height: 58.ah,width:134.aw,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(40)
              ),
              child: Row(
                // mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text('Add assets', style: TextStyle(
                      color: Color(0xff6A6A6A),fontWeight: FontWeight.w500,fontSize:13
                  ),),
                  SizedBox(width: 5.aw,),
                  Container(
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: Color(0xFF32CD30),width:3
                        )
                    ),
                    height: 48.ah,width: 48.aw,
                    child: Icon(Icons.add,color: Color(0xFF32CD30)),
                  )
                ],
              ),
            ),
          ),
        )
    );
  }
}



class Categories extends StatelessWidget {
  const Categories({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: 179.ah,
      child: ListView.builder(
        shrinkWrap: true,
        scrollDirection: Axis.horizontal,
        itemCount: 10,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Card(
                  color: Colors.white,shadowColor: Colors.white70,
                  child: Container(
                    width: 127.aw,
                    height: 100.ah,
                    decoration: ShapeDecoration(
                        image: DecorationImage(
                            image: AssetImage('assets/image/Frame 1 (2).png'),
                            fit: BoxFit.fill
                        ), shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10)),)
                    ),


                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('Landed Properties',
                        style: TextStyle(
                          color: Color(0xFF3F423F),fontWeight: FontWeight.w600,fontSize:14.fSize,
                        ),
                      ),
                      Text('5,000 items',
                        style: TextStyle(
                          color: Color(0xFF3F423F),fontWeight: FontWeight.w400,fontSize:12.fSize,
                        ),
                      ),
                    ],
                  ),
                ),


              ],
            ),
          );
        },
      ),
    );
  }
}


class FeaturedAssets extends StatelessWidget {
  const FeaturedAssets({super.key});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        shrinkWrap: true,
        itemCount: 6,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,mainAxisExtent:248,
            mainAxisSpacing:15,crossAxisSpacing: 9
        ),
        itemBuilder: (context, index) {
          return  Card(
              color: Colors.white,
              surfaceTintColor: Colors.white,
              elevation: 0,
              shape: RoundedRectangleBorder(),
              child: Container(
                color: Colors.white,
                height: 248.ah,width: 156.aw,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [

                    Image.asset('assets/image/image_2024_03_19T09_15_46_504Z.png',height: 113.ah,
                      width: MediaQuery.of(context).size.width,
                      fit: BoxFit.fill,
                    ),

                    SizedBox(height: 10.ah),
                    Text('iPhone 15',
                      style: TextStyle(fontFamily: 'Roboto',
                          color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                      ),
                    ),

                    Text('UIC: 6568520',
                      style: TextStyle(fontFamily: 'Roboto',
                          color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                      ),
                    ),

                    Text('This property is not available\nfor sale. Kindly...',
                      style: TextStyle(fontFamily: 'Roboto',
                          color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                      ),
                    ),

                    SizedBox(height:10.ah),
                    Container(
                      width: 96.aw,height: 27.ah,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(40),
                        color: Color(0xFF32CD30),
                      ),
                      child:  Center(
                        child: Text('View Asset',
                          style: TextStyle(fontFamily: 'Roboto',
                              color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                          ),
                        ),
                      ),
                    ),


                  ],
                ),

              )

          );
        });
  }
}
