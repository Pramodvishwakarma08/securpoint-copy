import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:securepoint/screen/size.dart';

class SavedAssets extends StatefulWidget {
  const SavedAssets({super.key});

  @override
  State<SavedAssets> createState() => _SavedAssetsState();
}

class _SavedAssetsState extends State<SavedAssets> {
  final List<String> _options = ['Pr 1', 'fg 2', 'Gh 3'];
  String? _selectedOption;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Icon(Icons.arrow_back_outlined,color: Color(0xFF6A6A6A))),
          title: Text('Saved Assets',
            style: TextStyle(fontFamily: 'Inter',
                color: Colors.black,fontWeight: FontWeight.w600,fontSize:20
            ),
          ),
          centerTitle: true,

          backgroundColor: Colors.white,surfaceTintColor: Colors.white,shadowColor: Colors.black26,
          elevation: 3,
        ),

        body: Padding(
          padding:  EdgeInsets.only(left: 20.h,right: 20.h),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [

                SizedBox(height: 30.ah),
                /*Card(
                  color: Colors.white70,
                  shadowColor: Colors.black,
                  surfaceTintColor: Colors.white70,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(43),
                      side: BorderSide(
                          color: Colors.black12,width: 1
                      )
                  ),
                  elevation: 10,
                  child: Container(
                    // width: 293,
                    width: MediaQuery.of(context).size.width,
                    height:45,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: Colors.white70,
                      borderRadius: BorderRadius.circular(43),

                    ),
                    child: TextField(
                      cursorColor: Color(0xFF000000),
                      style: TextStyle(color: Colors.black),
                      decoration: InputDecoration(
                          prefixIcon: //Image.asset('assets/images/seearch.png',),
                          Icon(Icons.search, color: Colors.grey,),
                          hintText:"Search Assets",
                          hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),
                          border: InputBorder.none),

                    ),
                  ),
                ),*/

                /* TextField(
                  cursorColor: Color(0xFF000000),
                  style: TextStyle(color: Colors.black),
                  decoration: InputDecoration(
                    isDense: true,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(43.h),
                      borderSide: BorderSide(
                        color: Color(0xFFB5B5B5),
                        width: 1,
                      ),
                    ),
                    errorStyle: TextStyle(color: Colors.red),
                    errorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(43.h),
                      borderSide: BorderSide(
                        color: Colors.red,
                        width: 1,
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(43.h),
                      borderSide: BorderSide(
                        color: Color(0xFF32CD30), width: 1,),),
                    prefixIcon: //Image.asset('assets/images/seearch.png',),
                    InkWell(
                        onTap: () {
                       //   Navigator.push(context, MaterialPageRoute(builder: (context) => SearcScreen()));
                        },
                        child: Icon(Icons.search, color: Colors.grey,size:30)),
                    hintText:"Search Assets",
                    hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),

                  ),

                ),*/

                Card(
                  color: Colors.white70,
                  shadowColor: Colors.black,
                  surfaceTintColor: Colors.white70,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(43),
                      side: BorderSide(
                          color: Colors.black12,width: 1
                      )
                  ),
                  elevation: 10,
                  child: Container(
                    // width: 293,
                    width: MediaQuery.of(context).size.width,
                    height:52,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: Colors.white70,
                      borderRadius: BorderRadius.circular(43),

                    ),
                    child: TextField(
                      cursorColor: Color(0xFF000000),
                      style: TextStyle(color: Colors.black),
                      decoration: InputDecoration(
                          prefixIcon: //Image.asset('assets/images/seearch.png',),
                          Icon(Icons.search, color: Colors.grey,),
                          hintText:"Search Assets",
                          hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),
                          border: InputBorder.none),

                    ),
                  ),
                ),

                SizedBox(height: 20),

                Text('17 Iteam',
                  style: TextStyle(fontFamily: 'Roboto',
                      decoration: TextDecoration.underline,
                      color: Colors.black,fontWeight: FontWeight.w500,fontSize:13
                  ),
                ),

                SizedBox(height: 10),
                Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    //mainAxisSize: MainAxisSize.min,
                    children: [
                      Card(
                          color: Colors.white,
                          surfaceTintColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(),
                          child: Container(
                            color: Colors.white,
                            height: 248.ah,width: 156.aw,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                Image.asset('assets/image/image_2024_03_19T09_15_46_504Z.png',height: 113.ah,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.fill,
                                ),

                                SizedBox(height: 10.ah),
                                Text('iPhone 15',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                  ),
                                ),

                                Text('UIC: 6568520',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                  ),
                                ),

                                Text('This property is not available\nfor sale. Kindly...',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                  ),
                                ),

                                SizedBox(height:10.ah),
                                Container(
                                  width: 96.aw,height: 27.ah,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(40),
                                    color: Color(0xFF32CD30),
                                  ),
                                  child:  Center(
                                    child: Text('View Asset',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                      ),
                                    ),
                                  ),
                                ),


                              ],
                            ),

                          )

                      ),
                      Card(
                          color: Colors.white,
                          surfaceTintColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(),
                          child: Container(
                            color: Colors.white,
                            height: 248.ah,width: 156.aw,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                Image.asset('assets/image/image_2024_03_19T09_15_46_504Z.png',height: 113.ah,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.fill,
                                ),

                                SizedBox(height: 10.ah),
                                Text('iPhone 15',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                  ),
                                ),

                                Text('UIC: 6568520',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                  ),
                                ),

                                Text('This property is not available\nfor sale. Kindly...',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                  ),
                                ),

                                SizedBox(height:10.ah),
                                Container(
                                  width: 96.aw,height: 27.ah,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(40),
                                    color: Color(0xFF32CD30),
                                  ),
                                  child:  Center(
                                    child: Text('View Asset',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                      ),
                                    ),
                                  ),
                                ),


                              ],
                            ),

                          )

                      ),
                    ],
                  ),
                ),
                //SearchResult()

                Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    crossAxisAlignment: CrossAxisAlignment.center,
                   // mainAxisSize: MainAxisSize.min,
                    children: [
                      Card(
                          color: Colors.white,
                          surfaceTintColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(),
                          child: Container(
                            color: Colors.white,
                            height: 248.ah,width: 156.aw,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                Image.asset('assets/image/image_2024_03_19T09_15_46_504Z.png',height: 113.ah,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.fill,
                                ),

                                SizedBox(height: 10.ah),
                                Text('iPhone 15',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                  ),
                                ),

                                Text('UIC: 6568520',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                  ),
                                ),

                                Text('This property is not available\nfor sale. Kindly...',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                  ),
                                ),

                                SizedBox(height:10.ah),
                                Container(
                                  width: 96.aw,height: 27.ah,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(40),
                                    color: Color(0xFF32CD30),
                                  ),
                                  child:  Center(
                                    child: Text('View Asset',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                      ),
                                    ),
                                  ),
                                ),


                              ],
                            ),

                          )

                      ),

                      Card(
                          color: Colors.white,
                          surfaceTintColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(),
                          child: Container(
                            color: Colors.white,
                            height: 248.ah,width: 156.aw,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                Image.asset('assets/image/image_2024_03_19T09_15_46_504Z.png',height: 113.ah,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.fill,
                                ),

                                SizedBox(height: 10.ah),
                                Text('iPhone 15',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                  ),
                                ),

                                Text('UIC: 6568520',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                  ),
                                ),

                                Text('This property is not available\nfor sale. Kindly...',
                                  style: TextStyle(fontFamily: 'Roboto',
                                      color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                  ),
                                ),

                                SizedBox(height:10.ah),
                                Container(
                                  width: 96.aw,height: 27.ah,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(40),
                                    color: Color(0xFF32CD30),
                                  ),
                                  child:  Center(
                                    child: Text('View Asset',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                      ),
                                    ),
                                  ),
                                ),


                              ],
                            ),

                          )

                      ),
                    ],
                  ),
                ),

                // Center(
                //   child: Row(
                //     mainAxisAlignment: MainAxisAlignment.start,
                //     crossAxisAlignment: CrossAxisAlignment.center,
                //     mainAxisSize: MainAxisSize.min,
                //     children: [
                //
                //       Card(
                //           color: Colors.white,
                //           surfaceTintColor: Colors.white,
                //           elevation: 0,
                //           shape: RoundedRectangleBorder(),
                //           child: Container(
                //             color: Colors.white,
                //             height: 248.ah,width: 156.aw,
                //             child: Column(
                //               crossAxisAlignment: CrossAxisAlignment.start,
                //               mainAxisAlignment: MainAxisAlignment.start,
                //               children: [
                //
                //                 Image.asset('assets/image/image_2024_03_19T09_15_46_504Z.png',height: 113.ah,
                //                   width: MediaQuery.of(context).size.width,
                //                   fit: BoxFit.fill,
                //                 ),
                //
                //                 SizedBox(height: 10.ah),
                //                 Text('iPhone 15',
                //                   style: TextStyle(fontFamily: 'Roboto',
                //                       color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                //                   ),
                //                 ),
                //
                //                 Text('UIC: 6568520',
                //                   style: TextStyle(fontFamily: 'Roboto',
                //                       color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                //                   ),
                //                 ),
                //
                //                 Text('This property is not available\nfor sale. Kindly...',
                //                   style: TextStyle(fontFamily: 'Roboto',
                //                       color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                //                   ),
                //                 ),
                //
                //                 SizedBox(height:10.ah),
                //                 Container(
                //                   width: 96.aw,height: 27.ah,
                //                   decoration: BoxDecoration(
                //                     borderRadius: BorderRadius.circular(40),
                //                     color: Color(0xFF32CD30),
                //                   ),
                //                   child:  Center(
                //                     child: Text('View Asset',
                //                       style: TextStyle(fontFamily: 'Roboto',
                //                           color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                //                       ),
                //                     ),
                //                   ),
                //                 ),
                //
                //
                //               ],
                //             ),
                //
                //           )
                //
                //       ),
                //     ],
                //   ),
                // ),

              ],
            ),
          ),
        ),
        floatingActionButton: InkWell(
          onTap: () {
            //Get.to(AddAssets_Screen());
          },
          child: Card(
            surfaceTintColor: Colors.black,
            color: Colors.white,
            shadowColor: Colors.black,
            shape:RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(40),
            ) ,
            elevation: 5,
            child: Container(
              height: 58.ah,width:134.aw,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(40)
              ),
              child: Row(
                // mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text('Add assets', style: TextStyle(
                      color: Color(0xff6A6A6A),fontWeight: FontWeight.w500,fontSize:13
                  ),),
                  SizedBox(width: 5.aw,),
                  Container(
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: Color(0xFF32CD30),width:3
                        )
                    ),
                    height: 48.ah,width: 48.aw,
                    child: Icon(Icons.add,color: Color(0xFF32CD30)),
                  )
                ],
              ),
            ),
          ),
        )
    );
  }
}


class SearchResult extends StatelessWidget {
  const SearchResult({super.key});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        shrinkWrap: true,
        itemCount: 4,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,mainAxisExtent:248,
            mainAxisSpacing:2,crossAxisSpacing:2
        ),
        itemBuilder: (context, index) {
          return  Container(
            color: Colors.white,
            height: 248.ah,width: MediaQuery.of(context).size.width,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [

                Container(
                  width: MediaQuery.of(context).size.width,
                  height: 113.ah,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                          fit: BoxFit.fill,
                          image:AssetImage('assets/image/image_2024_03_19T09_15_46_504Z.png')
                      )
                  ),
                ),
                // Image.asset('assets/image/image_2024_03_19T08_10_10_398Z.png',height: 113.ah,
                //   width: MediaQuery.of(context).size.width,
                //   fit: BoxFit.fill,
                // ),

                SizedBox(height: 10.ah),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                    SizedBox(width: 10.aw),
                    Text('iPhone 15',
                      style: TextStyle(fontFamily: 'Roboto',
                          color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                      ),
                    ),
                  ],
                ),

                Text('UIC: 6568520',
                  style: TextStyle(fontFamily: 'Roboto',
                      color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                  ),
                ),

                Text('This property is not available\nfor sale. Kindly...',
                  style: TextStyle(fontFamily: 'Roboto',
                      color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                  ),
                ),

                SizedBox(height:10.ah),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      width: 96.aw,height: 27.ah,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(40),
                        color: Color(0xFF32CD30),
                      ),
                      child:  Center(
                        child: Text('View Asset',
                          style: TextStyle(fontFamily: 'Roboto',
                              color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width:30.aw),
                    Icon(Icons.location_on,size: 25,)
                  ],
                ),



              ],
            ),

          );
        });
  }
}
