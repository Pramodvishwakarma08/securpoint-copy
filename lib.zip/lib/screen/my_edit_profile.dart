
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:securepoint/screen/size.dart';

import 'const_iteam/const_textfile.dart';
import 'const_iteam/custom_button.dart';

class EditProfile_Screen extends StatefulWidget {
  const EditProfile_Screen({super.key});

  @override
  State<EditProfile_Screen> createState() => _EditProfile_ScreenState();
}

class _EditProfile_ScreenState extends State<EditProfile_Screen> {

  //File? image1 ;

/*  Future<void> _pickImageFromGallery() async {
    final picker = ImagePicker();
    final pickedImage = await picker.pickImage(source: ImageSource.gallery);

    if (pickedImage != null) {
      print('Image picked from gallery: ${pickedImage.path}');
    }
  }

  Future<void> _pickImageFromCamera() async {
    final picker = ImagePicker();
    final pickedImage = await picker.pickImage(source: ImageSource.camera);

    if (pickedImage != null) {
      print('Image picked from camera: ${pickedImage.path}');
    }
  }
  */

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(Icons.arrow_back_outlined,color: Color(0xFF6A6A6A))),
        title: Text('Edit Profile',
          style: TextStyle(fontFamily: 'Inter',
              color: Color(0xFF6A6A6A),fontWeight: FontWeight.w600,fontSize:20
          ),
        ),
        centerTitle: true,

        backgroundColor: Colors.white,surfaceTintColor: Colors.white,shadowColor: Colors.black26,
        elevation: 3,
      ),

      body: Padding(
        padding:  EdgeInsets.only(left: 20.h,right: 20.h),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [

            SizedBox(height: 80.ah),
            Center(
              child: Stack(
                children: [
                  Container(
                    height: 155.ah,width: 155.aw,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      image: DecorationImage(
                          fit: BoxFit.fill,
                          image: AssetImage('assets/image/75dc930fedff8c0a89c101576ace5fce.png')
                      ) ,

                    ),
                  ),

                  Positioned(
                      right: 0,top:80,
                      child: Container(
                        height: 44.ah,width: 44.aw,
                        decoration: BoxDecoration(
                            color: Colors.green,
                            shape: BoxShape.circle
                        ),
                        child: Icon(Icons.edit,color: Colors.white,),
                      )
                    //Image.asset('assets/image/edit.png',height:38.ah,width: 38.aw,fit: BoxFit.contain,)
                  ),

                ],

              ),
            ),

            SizedBox(height:30.ah),

            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left:10),
                  child: Text('Name',
                    style: TextStyle(
                        color: Colors.black,fontWeight: FontWeight.w700,fontSize: 15.fSize
                    ),
                  ),
                ),

                SizedBox(height: 10.ah,),
                primaryTextfield2(
                    hintText: 'Vishy Mpigo',
                    controller: null
                ),
                SizedBox(height: 10.ah,),
                Padding(
                  padding: const EdgeInsets.only(left:10),
                  child: Text('Phone/Email',
                    style: TextStyle(
                        color: Colors.black,fontWeight: FontWeight.w700,fontSize: 15.fSize
                    ),
                  ),
                ),

                SizedBox(height: 10.ah,),
                primaryTextfield2(
                    hintText: 'name@domain.com',
                    controller: null
                ),


                SizedBox(height:30.ah,),
                Center(
                  child: CustomPrimaryBtn1(
                    title: 'Save',
                    isLoading: false,
                    onTap: () {
                      // Navigator.push(context, MaterialPageRoute(builder: (context) => SignUp_Screen()));
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
