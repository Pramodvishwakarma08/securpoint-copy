import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:securepoint/screen/deshbord_screen.dart';
import 'package:securepoint/screen/size.dart';
import 'const_iteam/custom_button.dart';
import 'loginwithemail.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  String otp = '';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Stack(
            alignment: Alignment.centerLeft,
            children: [
              // Container(
              //   height:50.ah,
              //   width: MediaQuery.of(context).size.width,
              //   color: Color(0xFF32CD30),
              // ),
              // SizedBox(height: 20.ah,),
              Container(
                height: 185.ah,
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                  //color: Color(0xFF32CD30),
                  //borderRadius: BorderRadius.only(bottomRight: Radius.circular(151))
                    image: DecorationImage(
                        fit: BoxFit.fill,
                        image: AssetImage('assets/image/Rectangle 4.png',)
                    )
                ),
              ),

              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(width:20.aw),
                  Image.asset('assets/image/secur icon.png',height:53.ah,width: 40.aw,),
                  SizedBox(width:20.aw),
                  Text('SecurPoint', style:TextStyle(
                    color: Colors.white,fontSize: 35.7.fSize,fontFamily: 'Times New Roman',
                    fontWeight: FontWeight.w700,letterSpacing:1,
                  ))
                ],
              )
            ],
          ),

          Padding(
            padding: const EdgeInsets.only(left:30,right:30),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                SizedBox(height: 20.ah),
                Text('OTP Verification',
                  style: TextStyle(
                      color: Colors.black,fontWeight: FontWeight.w600,fontSize: 36.fSize
                  ),
                ),

                SizedBox(height:30.ah),
                Text('A 4-digit code has been sent to\nmail@yourdomain.com',
                  style: TextStyle(
                      color: Colors.grey,fontWeight: FontWeight.w600,fontSize:14.fSize
                  ),
                ),

                SizedBox(height:30.ah),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 30.h, vertical: 30.v),
                  child: PinCodeTextField(
                    keyboardType: TextInputType.number,
                    enablePinAutofill: true,
                    appContext: context,
                    length: 4,
                    onChanged: (value) {
                      setState(() {
                        otp = value;
                        print("$value");
                      });
                    },
                    pinTheme: PinTheme(
                      activeColor: Colors.green,
                      selectedColor: Colors.grey,
                      shape: PinCodeFieldShape.box,
                      inactiveColor: Colors.grey,
                      borderRadius: BorderRadius.circular(15),
                      fieldHeight: 65.ah,
                      fieldWidth: 62.aw,
                      disabledColor: Colors.black,
                      activeFillColor: Colors.purpleAccent,
                      inactiveFillColor: Colors.grey,
                      selectedFillColor: Colors.yellowAccent,
                    ),
                    animationType: AnimationType.fade,
                    cursorColor: Colors.black,
                    animationDuration: Duration(milliseconds: 300),
                    controller: null,
                  ),
                ),

                Center(
                  child: RichText(
                    text: TextSpan(
                        text: 'Didn’t receive OTP?',
                        style: TextStyle(
                          fontSize: 14.fSize,fontWeight: FontWeight.w500,color: Colors.black,
                        ),

                        children: [
                          TextSpan(
                            text: ' Please resend',
                            style: TextStyle(decoration: TextDecoration.underline,
                              fontSize: 14.fSize,fontWeight: FontWeight.w500,color:Color(0xFF32CD30),
                            ),)]),),
                ),

              ],
            ),
          ),

          //SizedBox(height:30.ah),
          Spacer(),
          CustomPrimaryBtn(
            title: 'Continue', isLoading: false,
            onTap: () {
              // Get.to(LoginWith_PhoneNumber());
              Navigator.push(context, MaterialPageRoute(builder: (context) => Demo_deshboardPage()));

            },),
          SizedBox(height:80.ah),
        ],
      ),
    );
  }
}

/*
class TextEditorForPhoneVerify extends StatelessWidget {
  final TextEditingController code;

  TextEditorForPhoneVerify(this.code);

  @override
  Widget build(BuildContext context) {
    return TextField(
        textAlign: TextAlign.center,
        keyboardType: TextInputType.number,
        controller: this.code,
        maxLength: 1,
        cursorColor: Theme.of(context).primaryColor,
        decoration: InputDecoration(
            hintText: "*",
            counterText: '',
            hintStyle: TextStyle(color: Colors.black, fontSize: 20.0)
        )
    );
  }
}*/

