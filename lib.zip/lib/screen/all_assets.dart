import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:securepoint/screen/size.dart';

import 'all_assets_detsils.dart';
import 'deshbord_screen.dart';
import 'navigation_screen.dart';
import 'notification_screen.dart';


class All_Assets_Screen extends StatefulWidget {
  const All_Assets_Screen({super.key});

  @override
  State<All_Assets_Screen> createState() => _All_Assets_ScreenState();
}

class _All_Assets_ScreenState extends State<All_Assets_Screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        surfaceTintColor: Colors.white,
        backgroundColor: Colors.white,
        leading: InkWell(
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => NavigationScreen(),));
              // Navigator.push(context, MaterialPageRoute(builder: (context) => UserProfileScreen(),));
              //Navigator.push(context, MaterialPageRoute(builder: (context) => MyProfile_Screen(),));
              //Navigator.push(context, MaterialPageRoute(builder: (context) => EditProfile_Screen(),));
              // Navigator.push(context, MaterialPageRoute(builder: (context) => PremiumScreen(),));
              // Navigator.push(context, MaterialPageRoute(builder: (context) => Fillterd_assets(),));
              //Navigator.push(context, MaterialPageRoute(builder: (context) => SearcScreen(),));
              // Navigator.push(context, MaterialPageRoute(builder: (context) => SavedAssets(),));
              // Navigator.push(context, MaterialPageRoute(builder: (context) => AboutScreen(),));
              //Navigator.push(context, MaterialPageRoute(builder: (context) => SearchNoData_screen(),));
              // Navigator.push(context, MaterialPageRoute(builder: (context) => Notification_Preference(),));
              // Navigator.push(context, MaterialPageRoute(builder: (context) => FAQ(),));
              //Navigator.push(context, MaterialPageRoute(builder: (context) => ExpansionPanelDemo(),));
              // Navigator.push(context, MaterialPageRoute(builder: (context) => Messages_Screen(),));
              // Navigator.push(context, MaterialPageRoute(builder: (context) => AssetsScreen(),));
              //Navigator.push(context, MaterialPageRoute(builder: (context) => DeleteAccount_Screen(),));
              // Navigator.push(context, MaterialPageRoute(builder: (context) => MapScreen(),));
              //Navigator.push(context, MaterialPageRoute(builder: (context) => MYAsset_Details(),));
              // Navigator.push(context, MaterialPageRoute(builder: (context) => Myy_Assets_Details(),));
              //Navigator.push(context, MaterialPageRoute(builder: (context) => EditAssets(),));
              //Navigator.push(context, MaterialPageRoute(builder: (context) => MapScreen(),));
              //Navigator.push(context, MaterialPageRoute(builder: (context) => Main_Assets(),));
            },
            child: Icon(Icons.menu)),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 25),
            child: InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => Notification_Screen(),));
                },
                child: SvgPicture.asset('assets/icon/Icon.svg',height: 22.ah,width:22.aw,)),
          )
        ],
      ),

      body: SingleChildScrollView(
        child: Padding(
          padding:  EdgeInsets.only(left: 20.h,right: 20.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              SizedBox(height: 20.ah),
              Center(child: SvgPicture.asset('assets/icon/ic_security_24px.svg',height: 35.ah,width:29.aw,)),
              SizedBox(height: 10.ah),
              Center(
                child: RichText(
                  text: TextSpan(
                      text: 'Secur',
                      style:TextStyle(fontFamily: 'Times New Roman',
                        fontSize:18.fSize,fontWeight: FontWeight.w400,color: Color(0xFF2B2C2B),
                      ),
                      children: [
                        TextSpan(
                          text: 'Point',
                          style: TextStyle(fontFamily: 'Times New Roman',
                            fontSize: 18.fSize,fontWeight: FontWeight.w400,color:Color(0xFF525452),
                          ),)]),),
              ),

              SizedBox(height: 30.ah),
              /*Card(
                color: Colors.white70,
                shadowColor: Colors.black,
                surfaceTintColor: Colors.white70,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(43),
                  side: BorderSide(
                    color: Colors.black12,width: 1
                  )
                ),
                elevation: 10,
                child: Container(
                  // width: 293,
                  width: MediaQuery.of(context).size.width,
                  height:45,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Colors.white70,
                    borderRadius: BorderRadius.circular(43),

                  ),
                  child: TextField(
                    cursorColor: Color(0xFF000000),
                    style: TextStyle(color: Colors.black),
                    decoration: InputDecoration(
                        prefixIcon: //Image.asset('assets/images/seearch.png',),
                        Icon(Icons.search, color: Colors.grey,),
                        hintText:"Search Assets",
                        hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),
                        border: InputBorder.none),

                  ),
                ),
              ),*/

              /*TextField(
                cursorColor: Color(0xFF000000),
                style: TextStyle(color: Colors.black),
                decoration: InputDecoration(
                  isDense: true,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(43.h),
                    borderSide: BorderSide(
                      color: Color(0xFFB5B5B5),
                      width: 1,
                    ),
                  ),
                  errorStyle: TextStyle(color: Colors.red),
                  errorBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(43.h),
                    borderSide: BorderSide(
                      color: Colors.red,
                      width: 1,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(43.h),
                    borderSide: BorderSide(
                      color: Color(0xFF32CD30), width: 1,),),
                  prefixIcon: //Image.asset('assets/images/seearch.png',),
                  InkWell(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => SearcScreen()));
                      },
                      child: Icon(Icons.search, color: Colors.grey,size:30)),
                  hintText:"Search Assets",
                  hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),

                ),

              ),*/

              Card(
                color: Colors.white70,
                shadowColor: Colors.black,
                surfaceTintColor: Colors.white70,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(43),
                    side: BorderSide(
                        color: Colors.black12,width: 1
                    )
                ),
                elevation: 10,
                child: Container(
                  // width: 293,
                  width: MediaQuery.of(context).size.width,
                  height:52,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Colors.white70,
                    borderRadius: BorderRadius.circular(43),

                  ),
                  child: TextField(
                    cursorColor: Color(0xFF000000),
                    style: TextStyle(color: Colors.black),
                    decoration: InputDecoration(
                        prefixIcon: //Image.asset('assets/images/seearch.png',),
                        Icon(Icons.search, color: Colors.grey,),
                        hintText:"Search Assets",
                        hintStyle: TextStyle(color:Colors.grey,fontSize:16.fSize,fontWeight: FontWeight.w400),
                        border: InputBorder.none),

                  ),
                ),
              ),


              SizedBox(height: 20.ah),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Row(
                    // mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('All Assets',
                        style: TextStyle(
                            color: Colors.black,fontWeight: FontWeight.w500,fontSize:14
                        ),
                      ),

                      /*InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => AssetsScreen()));

                        },
                        child: Text('View less',
                          style: TextStyle(
                              color: HexColor('#AAAAAA'),fontWeight: FontWeight.w400,fontSize:13.fSize
                          ),
                        ),
                      ),*/
                    ],
                  ),

                  // Expanded(
                  //     child: All_Assets()
                  // )


                  SizedBox(height: 20.ah),

                  /*Card(
                    color: Colors.white,
                    surfaceTintColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(),

                    child: Container(
                      color: Colors.white,
                      height: 248.ah,width: 156.aw,
                      child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [

                              Stack(
                                alignment: Alignment.bottomCenter,
                               children: [
                                Container(
                          height: 115,width: MediaQuery.of(context).size.width,

                          // decoration: BoxDecoration(
                          //   color: Colors.red,
                          //   borderRadius: BorderRadius.circular(15)
                              decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(15),
                              image: DecorationImage(
                                image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                                fit: BoxFit.fill,
                              )
                          ),
                          // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                          //   width: MediaQuery.of(context).size.width,
                          //   fit: BoxFit.fill,
                          //
                          // ),
                        ),

                                 Image.asset('assets/image/Frame 427320937.png'),
                                 SizedBox(height: 20.ah)
                          ]),

                              SizedBox(height: 10.ah),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                  SizedBox(width: 10.aw),
                                  Text('iPhone 15',
                                    style: TextStyle(fontFamily: 'Roboto',
                                        color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                    ),
                                  ),
                                ],
                              ),

                              Text('UIC: 6568520',
                                style: TextStyle(fontFamily: 'Roboto',
                                    color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                ),
                              ),

                              Text('This property is not available\nfor sale. Kindly...',
                                style: TextStyle(fontFamily: 'Roboto',
                                    color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                ),
                              ),

                              SizedBox(height:10.ah),
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    width: 96.aw,height: 27.ah,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(40),
                                      color: Color(0xFF32CD30),
                                    ),
                                    child:  Center(
                                      child: Text('View Asset',
                                        style: TextStyle(fontFamily: 'Roboto',
                                            color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(width:30.aw),
                                  Icon(Icons.location_on,size: 25,)
                                ],
                              ),

                              // Align(
                              //   alignment: Alignment.topRight,
                              //   child: Container(
                              //     height: 40.ah,width: 40.aw,
                              //     decoration: BoxDecoration(
                              //         color: Colors.white,
                              //         shape: BoxShape.circle
                              //       //borderRadius: BorderRadius.circular(20)
                              //     ),
                              //   ),
                              // ),

                            ],
                          ),

                    )

                      ),*/

                  Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      crossAxisAlignment: CrossAxisAlignment.center,
                     // mainAxisSize: MainAxisSize.min,
                      children: [
                        Card(
                            color: Colors.white,
                            surfaceTintColor: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(),
                            child: InkWell(
                              onTap: () {
                                Navigator.push(context, MaterialPageRoute(builder: (context) => All_Assets_Details()));
                              },
                              child: Container(
                                color: Colors.white,
                                height: 248.ah,width: 156.aw,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [

                                    /*Stack(
                                  alignment: Alignment.bottomCenter,
                                 children: [
                                  Container(
                                 height: 115,width: MediaQuery.of(context).size.width,

                            // decoration: BoxDecoration(
                            //   color: Colors.red,
                            //   borderRadius: BorderRadius.circular(15)
                                decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                image: DecorationImage(
                                  image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                                  fit: BoxFit.fill,
                                )
                            ),
                            // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                            //   width: MediaQuery.of(context).size.width,
                            //   fit: BoxFit.fill,
                            //
                            // ),
                          ),

                                   Image.asset('assets/image/Frame 427320937.png'),
                                   SizedBox(height: 20.ah)
                            ]),*/
                                    Image.asset('assets/image/image_2024_03_19T08_10_31_939Z.png',height: 113.ah,
                                      width: MediaQuery.of(context).size.width,
                                      fit: BoxFit.fill,
                                    ),

                                    SizedBox(height: 10.ah),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      //mainAxisSize: MainAxisSize.min,
                                      children: [
                                        SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                        SizedBox(width: 10.aw),
                                        Text('iPhone 15',
                                          style: TextStyle(fontFamily: 'Roboto',
                                              color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                          ),
                                        ),
                                      ],
                                    ),

                                    Text('UIC: 6568520',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                      ),
                                    ),

                                    Text('This property is not available\nfor sale. Kindly...',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                      ),
                                    ),

                                    SizedBox(height:10.ah),
                                    Row(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          width: 96.aw,height: 27.ah,
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(40),
                                            color: Color(0xFF32CD30),
                                          ),
                                          child:  Center(
                                            child: Text('View Asset',
                                              style: TextStyle(fontFamily: 'Roboto',
                                                  color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(width:30.aw),
                                        Icon(Icons.location_on,size: 25,)
                                      ],
                                    ),

                                    // Align(
                                    //   alignment: Alignment.topRight,
                                    //   child: Container(
                                    //     height: 40.ah,width: 40.aw,
                                    //     decoration: BoxDecoration(
                                    //         color: Colors.white,
                                    //         shape: BoxShape.circle
                                    //       //borderRadius: BorderRadius.circular(20)
                                    //     ),
                                    //   ),
                                    // ),

                                  ],
                                ),

                              ),
                            )

                        ),

                        Card(
                            color: Colors.white,
                            surfaceTintColor: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(),
                            child: InkWell(
                              onTap: () {
                                //Navigator.push(context, MaterialPageRoute(builder: (context) => AssetsScreen()));
                              },
                              child: Container(
                                color: Colors.white,
                                height: 248.ah,width: 156.aw,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [

                                    /*Stack(
                                  alignment: Alignment.bottomCenter,
                                 children: [
                                  Container(
                                 height: 115,width: MediaQuery.of(context).size.width,

                            // decoration: BoxDecoration(
                            //   color: Colors.red,
                            //   borderRadius: BorderRadius.circular(15)
                                decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                image: DecorationImage(
                                  image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                                  fit: BoxFit.fill,
                                )
                            ),
                            // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                            //   width: MediaQuery.of(context).size.width,
                            //   fit: BoxFit.fill,
                            //
                            // ),
                          ),

                                   Image.asset('assets/image/Frame 427320937.png'),
                                   SizedBox(height: 20.ah)
                            ]),*/
                                    Image.asset('assets/image/image_2024_03_19T08_10_31_939Z.png',height: 113.ah,
                                      width: MediaQuery.of(context).size.width,
                                      fit: BoxFit.fill,
                                    ),

                                    SizedBox(height: 10.ah),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                        SizedBox(width: 10.aw),
                                        Text('iPhone 15',
                                          style: TextStyle(fontFamily: 'Roboto',
                                              color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                          ),
                                        ),
                                      ],
                                    ),

                                    Text('UIC: 6568520',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                      ),
                                    ),

                                    Text('This property is not available\nfor sale. Kindly...',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                      ),
                                    ),

                                    SizedBox(height:10.ah),
                                    Row(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          width: 96.aw,height: 27.ah,
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(40),
                                            color: Color(0xFF32CD30),
                                          ),
                                          child:  Center(
                                            child: Text('View Asset',
                                              style: TextStyle(fontFamily: 'Roboto',
                                                  color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(width:30.aw),
                                        Icon(Icons.location_on,size: 25,)
                                      ],
                                    ),

                                    // Align(
                                    //   alignment: Alignment.topRight,
                                    //   child: Container(
                                    //     height: 40.ah,width: 40.aw,
                                    //     decoration: BoxDecoration(
                                    //         color: Colors.white,
                                    //         shape: BoxShape.circle
                                    //       //borderRadius: BorderRadius.circular(20)
                                    //     ),
                                    //   ),
                                    // ),

                                  ],
                                ),

                              ),
                            )

                        )
                      ],
                    ),
                  ),

                  Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      crossAxisAlignment: CrossAxisAlignment.center,
                     // mainAxisSize: MainAxisSize.min,
                      children: [
                        Card(
                            color: Colors.white,
                            surfaceTintColor: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(),
                            child: InkWell(
                              onTap: () {
                               // Navigator.push(context, MaterialPageRoute(builder: (context) => AssetsScreen()));
                              },
                              child: Container(
                                color: Colors.white,
                                height: 248.ah,width: 156.aw,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [

                                    /*Stack(
                                  alignment: Alignment.bottomCenter,
                                 children: [
                                  Container(
                                 height: 115,width: MediaQuery.of(context).size.width,

                            // decoration: BoxDecoration(
                            //   color: Colors.red,
                            //   borderRadius: BorderRadius.circular(15)
                                decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                image: DecorationImage(
                                  image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                                  fit: BoxFit.fill,
                                )
                            ),
                            // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                            //   width: MediaQuery.of(context).size.width,
                            //   fit: BoxFit.fill,
                            //
                            // ),
                          ),

                                   Image.asset('assets/image/Frame 427320937.png'),
                                   SizedBox(height: 20.ah)
                            ]),*/
                                    Image.asset('assets/image/image_2024_03_19T08_10_31_939Z.png',height: 113.ah,
                                      width: MediaQuery.of(context).size.width,
                                      fit: BoxFit.fill,
                                    ),

                                    SizedBox(height: 10.ah),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                        SizedBox(width: 10.aw),
                                        Text('iPhone 15',
                                          style: TextStyle(fontFamily: 'Roboto',
                                              color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                          ),
                                        ),
                                      ],
                                    ),

                                    Text('UIC: 6568520',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                      ),
                                    ),

                                    Text('This property is not available\nfor sale. Kindly...',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                      ),
                                    ),

                                    SizedBox(height:10.ah),
                                    Row(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          width: 96.aw,height: 27.ah,
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(40),
                                            color: Color(0xFF32CD30),
                                          ),
                                          child:  Center(
                                            child: Text('View Asset',
                                              style: TextStyle(fontFamily: 'Roboto',
                                                  color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(width:30.aw),
                                        Icon(Icons.location_on,size: 25,)
                                      ],
                                    ),

                                    // Align(
                                    //   alignment: Alignment.topRight,
                                    //   child: Container(
                                    //     height: 40.ah,width: 40.aw,
                                    //     decoration: BoxDecoration(
                                    //         color: Colors.white,
                                    //         shape: BoxShape.circle
                                    //       //borderRadius: BorderRadius.circular(20)
                                    //     ),
                                    //   ),
                                    // ),

                                  ],
                                ),

                              ),
                            )

                        ),
                        Card(
                            color: Colors.white,
                            surfaceTintColor: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(),
                            child: InkWell(
                              onTap: () {
                               // Navigator.push(context, MaterialPageRoute(builder: (context) => AssetsScreen()));
                              },
                              child: Container(
                                color: Colors.white,
                                height: 248.ah,width: 156.aw,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [

                                    /*Stack(
                                  alignment: Alignment.bottomCenter,
                                 children: [
                                  Container(
                                 height: 115,width: MediaQuery.of(context).size.width,

                            // decoration: BoxDecoration(
                            //   color: Colors.red,
                            //   borderRadius: BorderRadius.circular(15)
                                decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                image: DecorationImage(
                                  image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                                  fit: BoxFit.fill,
                                )
                            ),
                            // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                            //   width: MediaQuery.of(context).size.width,
                            //   fit: BoxFit.fill,
                            //
                            // ),
                          ),

                                   Image.asset('assets/image/Frame 427320937.png'),
                                   SizedBox(height: 20.ah)
                            ]),*/

                                    Image.asset('assets/image/image_2024_03_19T08_10_31_939Z.png',height: 113.ah,
                                      width: MediaQuery.of(context).size.width,
                                      fit: BoxFit.fill,
                                    ),

                                    SizedBox(height: 10.ah),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                        SizedBox(width: 10.aw),
                                        Text('iPhone 15',
                                          style: TextStyle(fontFamily: 'Roboto',
                                              color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                          ),
                                        ),
                                      ],
                                    ),

                                    Text('UIC: 6568520',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                      ),
                                    ),

                                    Text('This property is not available\nfor sale. Kindly...',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                      ),
                                    ),

                                    SizedBox(height:10.ah),
                                    Row(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          width: 96.aw,height: 27.ah,
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(40),
                                            color: Color(0xFF32CD30),
                                          ),
                                          child:  Center(
                                            child: Text('View Asset',
                                              style: TextStyle(fontFamily: 'Roboto',
                                                  color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(width:30.aw),
                                        Icon(Icons.location_on,size: 25,)
                                      ],
                                    ),

                                    // Align(
                                    //   alignment: Alignment.topRight,
                                    //   child: Container(
                                    //     height: 40.ah,width: 40.aw,
                                    //     decoration: BoxDecoration(
                                    //         color: Colors.white,
                                    //         shape: BoxShape.circle
                                    //       //borderRadius: BorderRadius.circular(20)
                                    //     ),
                                    //   ),
                                    // ),

                                  ],
                                ),

                              ),
                            )

                        )
                      ],
                    ),
                  ),

                  Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      crossAxisAlignment: CrossAxisAlignment.center,
                     // mainAxisSize: MainAxisSize.min,
                      children: [
                        Card(
                            color: Colors.white,
                            surfaceTintColor: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(),
                            child: InkWell(
                              onTap: () {
                                //Navigator.push(context, MaterialPageRoute(builder: (context) => AssetsScreen()));
                              },
                              child: Container(
                                color: Colors.white,
                                height: 248.ah,width: 156.aw,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [

                                    /*Stack(
                                  alignment: Alignment.bottomCenter,
                                 children: [
                                  Container(
                                 height: 115,width: MediaQuery.of(context).size.width,

                            // decoration: BoxDecoration(
                            //   color: Colors.red,
                            //   borderRadius: BorderRadius.circular(15)
                                decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                image: DecorationImage(
                                  image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                                  fit: BoxFit.fill,
                                )
                            ),
                            // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                            //   width: MediaQuery.of(context).size.width,
                            //   fit: BoxFit.fill,
                            //
                            // ),
                          ),

                                   Image.asset('assets/image/Frame 427320937.png'),
                                   SizedBox(height: 20.ah)
                            ]),*/
                                    Image.asset('assets/image/image_2024_03_19T08_10_31_939Z.png',height: 113.ah,
                                      width: MediaQuery.of(context).size.width,
                                      fit: BoxFit.fill,
                                    ),

                                    SizedBox(height: 10.ah),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                        SizedBox(width: 10.aw),
                                        Text('iPhone 15',
                                          style: TextStyle(fontFamily: 'Roboto',
                                              color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                          ),
                                        ),
                                      ],
                                    ),

                                    Text('UIC: 6568520',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                      ),
                                    ),

                                    Text('This property is not available\nfor sale. Kindly...',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                      ),
                                    ),

                                    SizedBox(height:10.ah),
                                    Row(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          width: 96.aw,height: 27.ah,
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(40),
                                            color: Color(0xFF32CD30),
                                          ),
                                          child:  Center(
                                            child: Text('View Asset',
                                              style: TextStyle(fontFamily: 'Roboto',
                                                  color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(width:30.aw),
                                        Icon(Icons.location_on,size: 25,)
                                      ],
                                    ),

                                    // Align(
                                    //   alignment: Alignment.topRight,
                                    //   child: Container(
                                    //     height: 40.ah,width: 40.aw,
                                    //     decoration: BoxDecoration(
                                    //         color: Colors.white,
                                    //         shape: BoxShape.circle
                                    //       //borderRadius: BorderRadius.circular(20)
                                    //     ),
                                    //   ),
                                    // ),

                                  ],
                                ),

                              ),
                            )

                        ),
                        Card(
                            color: Colors.white,
                            surfaceTintColor: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(),
                            child: InkWell(
                              onTap: () {
                               // Navigator.push(context, MaterialPageRoute(builder: (context) => AssetsScreen()));
                              },
                              child: Container(
                                color: Colors.white,
                                height: 248.ah,width: 156.aw,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [

                                    /*Stack(
                                  alignment: Alignment.bottomCenter,
                                 children: [
                                  Container(
                                 height: 115,width: MediaQuery.of(context).size.width,

                            // decoration: BoxDecoration(
                            //   color: Colors.red,
                            //   borderRadius: BorderRadius.circular(15)
                                decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                image: DecorationImage(
                                  image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                                  fit: BoxFit.fill,
                                )
                            ),
                            // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                            //   width: MediaQuery.of(context).size.width,
                            //   fit: BoxFit.fill,
                            //
                            // ),
                          ),

                                   Image.asset('assets/image/Frame 427320937.png'),
                                   SizedBox(height: 20.ah)
                            ]),*/
                                    Image.asset('assets/image/image_2024_03_19T08_10_31_939Z.png',height: 113.ah,
                                      width: MediaQuery.of(context).size.width,
                                      fit: BoxFit.fill,
                                    ),

                                    SizedBox(height: 10.ah),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                                        SizedBox(width: 10.aw),
                                        Text('iPhone 15',
                                          style: TextStyle(fontFamily: 'Roboto',
                                              color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                                          ),
                                        ),
                                      ],
                                    ),

                                    Text('UIC: 6568520',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                                      ),
                                    ),

                                    Text('This property is not available\nfor sale. Kindly...',
                                      style: TextStyle(fontFamily: 'Roboto',
                                          color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                                      ),
                                    ),

                                    SizedBox(height:10.ah),
                                    Row(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          width: 96.aw,height: 27.ah,
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(40),
                                            color: Color(0xFF32CD30),
                                          ),
                                          child:  Center(
                                            child: Text('View Asset',
                                              style: TextStyle(fontFamily: 'Roboto',
                                                  color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(width:30.aw),
                                        Icon(Icons.location_on,size: 25,)
                                      ],
                                    ),

                                    // Align(
                                    //   alignment: Alignment.topRight,
                                    //   child: Container(
                                    //     height: 40.ah,width: 40.aw,
                                    //     decoration: BoxDecoration(
                                    //         color: Colors.white,
                                    //         shape: BoxShape.circle
                                    //       //borderRadius: BorderRadius.circular(20)
                                    //     ),
                                    //   ),
                                    // ),

                                  ],
                                ),

                              ),
                            )

                        )
                      ],
                    ),
                  ),

                  // All_Assets()

                ],
              ),
            ],
          ),
        ),
      ),

      bottomNavigationBar: BottomNavigationBar(
        iconSize:25,
        type: BottomNavigationBarType.fixed,
        // currentIndex: _selectedIndex,
        backgroundColor: Colors.white,
        selectedItemColor:Color(0XFF333333),
        unselectedItemColor: Colors.black.withOpacity(.60),
        // selectedLabelStyle: textTheme.caption,
        //unselectedLabelStyle: textTheme.caption,
        //onTap: _onItemTapped,
        elevation: 20,
        items: [
          BottomNavigationBarItem(
              label: 'Home',
              icon: Padding(
                  padding: const EdgeInsets.only(top : 8.0,bottom: 4),
                  child:
                  InkWell(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => Demo_deshboardPage()));
                      },
                      child:Image.asset('assets/image/Union (3).png',
                        // color:_selectedIndex==0? HexColor('#333333'):Colors.black,
                        height:20.ah,width:20.aw,)

                    // SvgPicture.asset('assets/icon/Union.svg',color:_selectedIndex==0? HexColor('#333333'):Colors.black))
                  ))),

          BottomNavigationBarItem(
              label: 'Assets',
              icon: Padding(
                  padding: const EdgeInsets.only(top : 8.0,bottom: 4),
                  child:
                  InkWell(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => Demo_deshboardPage()));
                    },
                    child: Image.asset('assets/image/Your Assets.png',
                      //color:_selectedIndex==1? HexColor('#333333'):Colors.black,
                      height:20.ah,width:20.aw,
                    ),
                  )

                // SvgPicture.asset('assets/icon/Union.svg',color:_selectedIndex==0? HexColor('#333333'):Colors.black))
              )),

          BottomNavigationBarItem(
              label: 'Messages',
              icon: Padding(
                  padding: const EdgeInsets.only(top : 8.0,bottom: 4),
                  child:
                  InkWell(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => Demo_deshboardPage()));
                      },
                      child:Image.asset('assets/image/Subtract.png',
                        //color:_selectedIndex==2? HexColor('#333333'):Colors.black,
                        height:20.ah,width:20.aw,
                      )

                    // SvgPicture.asset('assets/icon/Union.svg',color:_selectedIndex==0? HexColor('#333333'):Colors.black))
                  ))),

          /*BottomNavigationBarItem(
            label:'PRODUCT',
            icon: Padding(
                padding: const EdgeInsets.only(top : 8.0,bottom: 4),
                child:                   Image.asset('assets/image/Union (3).png',color:_selectedIndex==0? HexColor('#333333'):Colors.black,height:20.ah,width:20.aw,)

              //SvgPicture.asset('assets/icon/Your Assets.svg',color:_selectedIndex==1? HexColor('#756BFF'):Colors.black)),
            )),

          BottomNavigationBarItem(
            label:'COMMUNITY',
            icon: Padding(
                padding: const EdgeInsets.only(top : 8.0,bottom: 4),
                child: SvgPicture.asset('assets/icon/Subtract.svg',color:_selectedIndex==2? HexColor('#756BFF'):Colors.black)),
          ),*/


        ],
      ),
    );
  }
}


class All_Assets extends StatefulWidget {
  const All_Assets({super.key});

  @override
  State<All_Assets> createState() => _All_AssetsState();
}

class _All_AssetsState extends State<All_Assets> {
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        shrinkWrap: true,
        itemCount: 4,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,mainAxisExtent:248,
            mainAxisSpacing:15,crossAxisSpacing: 9
        ),
        itemBuilder: (context, index) {
          return  Card(
              color: Colors.white,
              surfaceTintColor: Colors.white,
              elevation: 0,
              shape: RoundedRectangleBorder(),
              child: InkWell(
                onTap: () {
                 // Navigator.push(context, MaterialPageRoute(builder: (context) => AssetsScreen()));
                },
                child: Container(
                  color: Colors.white,
                  height: 248.ah,width: 156.aw,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [

                      /*Stack(
                                alignment: Alignment.bottomCenter,
                               children: [
                                Container(
                               height: 115,width: MediaQuery.of(context).size.width,

                          // decoration: BoxDecoration(
                          //   color: Colors.red,
                          //   borderRadius: BorderRadius.circular(15)
                              decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(15),
                              image: DecorationImage(
                                image: AssetImage('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg'),
                                fit: BoxFit.fill,
                              )
                          ),
                          // child: Image.asset('assets/image/ben-kolde-cpLsWmMEa1Q-unsplash.jpg',height: 115,
                          //   width: MediaQuery.of(context).size.width,
                          //   fit: BoxFit.fill,
                          //
                          // ),
                        ),

                                 Image.asset('assets/image/Frame 427320937.png'),
                                 SizedBox(height: 20.ah)
                          ]),*/
                      Image.asset('assets/image/image_2024_03_19T08_10_31_939Z.png',height: 113.ah,
                        width: MediaQuery.of(context).size.width,
                        fit: BoxFit.fill,
                      ),

                      SizedBox(height: 10.ah),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SvgPicture.asset('assets/icon/icon _warning_.svg',fit: BoxFit.fill,),
                          SizedBox(width: 10.aw),
                          Text('iPhone 15',
                            style: TextStyle(fontFamily: 'Roboto',
                                color: HexColor('#5E605E'),fontWeight: FontWeight.w600,fontSize:15.fSize
                            ),
                          ),
                        ],
                      ),

                      Text('UIC: 6568520',
                        style: TextStyle(fontFamily: 'Roboto',
                            color: HexColor('#32CD30'),fontWeight: FontWeight.w500,fontSize:15.fSize
                        ),
                      ),

                      Text('This property is not available\nfor sale. Kindly...',
                        style: TextStyle(fontFamily: 'Roboto',
                            color: HexColor('#000000'),fontWeight: FontWeight.w400,fontSize:12.fSize
                        ),
                      ),

                      SizedBox(height:10.ah),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            width: 96.aw,height: 27.ah,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(40),
                              color: Color(0xFF32CD30),
                            ),
                            child:  Center(
                              child: Text('View Asset',
                                style: TextStyle(fontFamily: 'Roboto',
                                    color: Colors.white,fontWeight: FontWeight.w600,fontSize:14.fSize
                                ),
                              ),
                            ),
                          ),
                          SizedBox(width:30.aw),
                          Icon(Icons.location_on,size: 25,)
                        ],
                      ),

                      // Align(
                      //   alignment: Alignment.topRight,
                      //   child: Container(
                      //     height: 40.ah,width: 40.aw,
                      //     decoration: BoxDecoration(
                      //         color: Colors.white,
                      //         shape: BoxShape.circle
                      //       //borderRadius: BorderRadius.circular(20)
                      //     ),
                      //   ),
                      // ),

                    ],
                  ),

                ),
              )

          );
        });

    /*GridView.builder(
        itemCount: 18,
        padding: EdgeInsets.only(bottom: 10,top: 10),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,mainAxisExtent: 273,
          mainAxisSpacing: 7,crossAxisSpacing: 7,),
        itemBuilder: (context, index) {
          return Expanded(
            child: Card(
                surfaceTintColor: Colors.black,
                color: Colors.white,shadowColor: Colors.black,
                elevation: 3,
                child: Column(
                  children: [
                    Stack(
                      children: [
                        Container(
                          width: 219.aw,
                          height: 156.ah,
                          decoration: ShapeDecoration(
                            image: DecorationImage(
                              image: AssetImage('assets/images/Youth-to-the-people-Kale-Green-Tea-Spinach-vitamins-Superfood-Cleanser-1-von-1-scaled 1 (1).png'),
                              fit: BoxFit.fill,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(4),
                                topRight: Radius.circular(4),
                              ),
                            ),
                          ),
                          child: Align(
                            alignment: Alignment.bottomLeft,
                            child: Container(
                              width: 71.aw,
                              height: 16.ah,
                              decoration: BoxDecoration(color: Color(0xFF797979)),
                              child: Center(
                                child: Text(
                                  'On Sale Now   ',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 9.fSize,
                                    fontFamily: 'Inter',
                                    fontWeight: FontWeight.w400,
                                    height: 0.15,
                                    letterSpacing: 0.45,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                    Container(
                        width: 219.aw,
                        decoration: ShapeDecoration(
                          color: Color(0x8EEAEAEA),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(3)),),
                        child:Padding(
                          padding: const EdgeInsets.all(9.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              SizedBox(height: 5.ah),
                              Text(
                                'Youth To The People',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 9,
                                  fontFamily: 'Inter',
                                  fontWeight: FontWeight.w700,
                                  height: 1,
                                  letterSpacing: 0.45,
                                ),
                              ),
                              SizedBox(height: 5.ah),
                              Text(
                                'On Sale Today: Superfood Cleanser, starting\nat only \$30 at select stores.',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 8,
                                  fontFamily: 'Inter',
                                  fontWeight: FontWeight.w500,
                                  height: 1,
                                  letterSpacing: 0.40,
                                ),
                              ),
                              SizedBox(height: 7.ah),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    width: 64,
                                    height: 17,
                                    decoration: ShapeDecoration(
                                      color: Color(0xFFA19ECA),
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                    ),
                                    child: Center(
                                      child: Text(
                                        '95% match ',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 8.50,
                                          fontFamily: 'Inter',
                                          fontWeight: FontWeight.w500,
                                          height: 0.15,
                                          letterSpacing: 0.42,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Text('SHOW >',
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 9,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w700,
                                      height:1,
                                      letterSpacing: 0.45,
                                    ),
                                  )

                                ],
                              )
                            ],
                          ),
                        )
                    )

                  ],
                )
            ),
          );
        });*/
  }
}
