import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/svg.dart';
import 'package:securepoint/screen/size.dart';

import 'add_assets.dart';
import 'fillter_assets.dart';
import 'notification_screen.dart';


class All_Categories extends StatefulWidget {
  const All_Categories({super.key});

  @override
  State<All_Categories> createState() => _All_CategoriesState();
}

class _All_CategoriesState extends State<All_Categories> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Icon(Icons.arrow_back_outlined,color: Color(0xFF6A6A6A))),
          title: Text('All Categories',
            style: TextStyle(fontFamily: 'Inter',
                color: Colors.black,fontWeight: FontWeight.w600,fontSize:20
            ),
          ),
          centerTitle: true,
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 25),
              child: InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => Notification_Screen()));
                  },
                  child: SvgPicture.asset('assets/icon/Icon.svg',height: 22.ah,width:22.aw,)),
            )
          ],
          backgroundColor: Colors.white,surfaceTintColor: Colors.white,shadowColor: Colors.black26,
          elevation: 3,
        ),

        body: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [

            Expanded(child: AllCatg())
          ],
        ),
        floatingActionButton: InkWell(
          onTap: () {
            //Get.to(AddAssets_Screen());
            Navigator.push(context, MaterialPageRoute(builder: (context) => AddAssets_Screen()));

          },
          child: Card(
            surfaceTintColor: Colors.black,
            color: Colors.white,
            shadowColor: Colors.black,
            shape:RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(40),
            ) ,
            elevation: 5,
            child: Container(
              height: 58.ah,width:134.aw,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(40)
              ),
              child: Row(
                // mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text('Add assets', style: TextStyle(
                      color: Color(0xff6A6A6A),fontWeight: FontWeight.w500,fontSize:13
                  ),),
                  SizedBox(width: 5.aw,),
                  Container(
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: Color(0xFF32CD30),width:3
                        )
                    ),
                    height: 48.ah,width: 48.aw,
                    child: Icon(Icons.add,color: Color(0xFF32CD30)),
                  )
                ],
              ),
            ),
          ),
        )
    );
  }
}



class AllCatg extends StatelessWidget {
  const AllCatg({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: Container(
        width: MediaQuery.of(context).size.width,
        height: 179.ah,
        child: ListView.builder(
          shrinkWrap: true,
          scrollDirection: Axis.vertical,
          itemCount: 5,
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.all(12.0),
              child: InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => Fillterd_assets()));
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 127.aw,
                      height: 100.ah,
                      decoration: ShapeDecoration(
                          image: DecorationImage(
                              image: AssetImage('assets/image/Frame 1 (2).png'),
                              fit: BoxFit.fill
                          ), shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10)),)
                      ),


                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text('Landed Properties',
                            style: TextStyle(
                              color: Color(0xFF3F423F),fontWeight: FontWeight.w600,fontSize:14.fSize,
                            ),
                          ),
                          Text('5,000 items',
                            style: TextStyle(
                              color: Color(0xFF3F423F),fontWeight: FontWeight.w400,fontSize:12.fSize,
                            ),
                          ),
                        ],
                      ),
                    ),


                  ],
                ),
              ),
            );
          },
        ),
      ),
    );

  }
}
