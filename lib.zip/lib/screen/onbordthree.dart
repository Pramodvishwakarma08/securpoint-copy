import 'package:flutter/cupertino.dart';
import 'package:securepoint/screen/size.dart';
import 'package:velocity_x/velocity_x.dart';

class OnBoardThird extends StatelessWidget {
  const OnBoardThird({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
          "assets/image/Location review-amico 1.png",
          height:376.ah,
          width: 376.ah,
          fit:BoxFit.fill ,
        ),

        SizedBox(height: 30.ah,),
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            // Image.asset('assets/image/image 1.png',height:48.ah,width: 48.aw,),
            Center(
              child: Text('Find Trusted Item\non Trusted Location',
                style: TextStyle(fontFamily: 'Roboto',height: 1.1,
                    color: Color(0xff000000),fontWeight: FontWeight.w700,fontSize:33.fSize
                ),
              ),
            ),
            SizedBox(height: 10.ah,),
            Center(
              child: Text('One place with the best secure Item. Apply \nto all of them with a single profile and get \nin touch with best seller directly.',
                style: TextStyle(fontFamily: 'Roboto',
                    color: Color(0xff000000),fontWeight: FontWeight.w500,fontSize:14.fSize,height: 1.6
                ),
              ),
            ),
          ],
        ),

        SizedBox(height: 20.ah,),
      ],
    );
  }
}
